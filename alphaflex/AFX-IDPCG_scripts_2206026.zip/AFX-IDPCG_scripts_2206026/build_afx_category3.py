"""
Generalized builder for Category 3 cases containing any combination of:
    * N-terminal IDR
    * C-terminal IDR
    * linker IDR between non-interacting folded domains
    * loop IDR between interacting adjacent folded domains

Supported topologies
--------------------
All ordered combinations are supported, for example:
    LOOP
    N-LOOP
    LOOP-C
    N-LOOP-C
    LINKER-LOOP
    LOOP-LINKER
    N-LINKER-LOOP-C
    LOOP-LINKER-LOOP
    N-LOOP-LINKER-LOOP-C
    any number of LINKER and LOOP IDRs, with optional N/C IDRs.

Important assumptions
---------------------
* Only adjacent folded-domain interactions define LOOP-IDRs.  Non-adjacent
  F_i/F_j interactions are reported but not used to close a single IDR loop.
* LOOP-IDR closure uses a 2-residue overhang on each side, matching the
  original single-loop hard script. Therefore the flanking folded domains must
  contain residues start-2/start-1 and end+1/end+2 around each loop.
* LINKER-IDRs are treated as flexible beads-on-a-string connectors.
* The AF2 PDB residue numbering is assumed to match the JSON residue numbering.

Requirements
------------
* IDPConformerGenerator >= 0.7.27
* OpenMM >= 8.2
* pdb-tools >= 2.5
* PDBFixer >= 1.9
"""
import json
import os
import random
import re
import shutil
import subprocess
import sys
import traceback

from dataclasses import dataclass
from functools import partial
from glob import glob
from pathlib import Path as StdPath
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from pdbfixer import PDBFixer

from openmm import CustomExternalForce, LangevinIntegrator
from openmm.app import ForceField, HBonds, NoCutoff, PDBFile, Simulation
from openmm.unit import angstrom, kilocalories_per_mole, kelvin, picosecond, picoseconds

from idpconfgen import Path as IDPPath
from idpconfgen.libs.libmulticore import pool_function
from idpconfgen.libs.libstructure import (
    Structure,
    col_chainID,
    col_name,
    col_resName,
    col_resSeq,
    col_segid,
    col_serial,
    cols_coords,
    parse_pdb_to_array,
    structure_to_pdb,
    write_PDB,
)
from idpconfgen.ldrs_helper import align_coords, count_clashes, next_seeker


# =============================================================================
# User-editable parameters
# =============================================================================

_match = re.search(r"\d+", StdPath(sys.argv[0]).name)
set_num = int(_match.group()) if _match else 0

nconfs = 100
ncores = 50
# Keep IDPCG/alignment parallel, but keep PDBFixer/OpenMM postprocessing
fix_ncores = 4
cc_ncores = 2

long_idr_threshold = 150

# Medium-style flexible IDR attempts.
max_attempts_per_fragment = 1000
build_batch_size = max(nconfs * 2, ncores)

# LOOP-IDR library construction.
# -----------------------------------------------------------------------------
# SPEED-FIRST MODE
# -----------------------------------------------------------------------------
# Hard cases are expensive because a loop has to bridge two fixed, interacting
# folded domains.  The previous script required roughly one unique loop closure
# per output conformer.  That is the main reason a single protein could burn
# through a 3-day job.
SPEED_FIRST_REUSE_MODE = True
fast_loop_unique_target = 3          # small true-IDPCG loop library; reuse cyclically
fast_terminal_unique_target = 24     # unique N/C terminal additions before cyclic reuse
fast_linker_unique_target = 32       # desired unique linker+block assemblies before cyclic reuse
min_loop_library_required = 1        # allow nconfs outputs even from one accepted loop closure

# Finish-if-doable mode: diversity targets are goals, not hard failure criteria.
# If at least the minimum below is built, the script cyclically reuses available
# fragments instead of discarding the whole protein.
min_terminal_unique_required = 1
min_linker_unique_required = 1
allow_partial_terminal_libraries = True
allow_partial_linker_libraries = True
allow_least_bad_loop_insert = True
loop_insert_fallback_score_cutoff = 500  # closed-IDPCG loop-vs-loop close-contact score allowed as last resort
openmm_minimize_max_iterations = 300
SKIP_ALREADY_FINISHED = True

loop_library_multiplier = 1          # used only if SPEED_FIRST_REUSE_MODE is False
loop_min_batch_size = max(ncores, nconfs)
loop_short_multiplier = 100          # <= 25 aa loop, very hard to close
loop_medium_multiplier = 50          # 26-60 aa loop
loop_long_multiplier = 20            # > 60 aa loop
loop_no_solution_batch_limit = 12    # fail only after this many zero-success batches; no AF2 fallback
loop_no_progress_patience = 6        # if partial library exists, return it after this many no-progress batches
loop_progress_report_every = 1       # print every batch in speed-first mode
loop_join_search_factor = 20         # scales with remaining target; see loop_join_cap_min below
loop_join_archive_factor = 20        # archive size relative to target_n for cross-batch joins
loop_join_adapt_trigger = 1          # widen join search quickly after no progress
loop_join_cap_max_multiplier = 3     # upper bound for adaptive join-cap growth

# In speed-first mode target_n is often 1, so target_n * archive_factor would
# otherwise cap the archive/join search at only ~100 candidates despite having
# thousands of lower/upper anchor candidates.  These minimums matter more than
# increasing raw IDPCG batch_nc.
loop_join_archive_min = 3000
loop_join_cap_min = 750

# No-AF2-loop mode: every LOOP-IDR inserted into the output must come from
# IDPConformerGenerator + next_seeker closure.  If no closed loop is found,
# the protein fails rather than using original AF2 loop coordinates.
allow_af2_loop_fallback = False

# Parameters inherited from the original single-loop hard script, relaxed for
# speed-first operation.  These values still require a closed bridge from
# next_seeker, but they are less aggressive about rejecting marginal contacts.
loop_anchor_max_clash = 160
loop_anchor_tolerance = 1.2
loop_join_max_clash = 120
loop_join_tolerance = 0.8

# Extra loop-vs-loop / loop-vs-block sanity check after extracting the accepted
# bridge.  In speed-first mode we allow a small number of very close contacts,
# since PDBFixer/OpenMM post-processing will do a restrained cleanup later.
loop_atom_clash_cutoff_angstrom = 1.35
loop_max_atom_clashes = 20

# Optional fallback: classify adjacent Fi-F(i+1) as LOOP if mean PAE is below
# this cutoff even if the pair is missing from "interactions".  Leave False to
# strictly obey the interactions list.
use_adjacent_pae_fallback_for_loops = False
adjacent_loop_pae_cutoff = 8.0

random_seed = 12345
random.seed(random_seed)

output_directory = f"../AFX-IDPCG_Category_3_ensembles/cat3_ens{set_num}"
hard_ids_file = f"../databases/category_3_ids/cat3_{set_num}.txt"
hard_ids_fallbacks = [
    hard_ids_file,
    f"../databases/category_3_ids/cat3f_{set_num}.txt",
    f"../databases/category_3_ids/cat3_{set_num}.txt",
    f"../databases/category_3_ids/cat3f_{set_num}.txt",
]
error_file = f"../databases/category_3_errors/cat3_{set_num}_errors.txt"

idpcg_database = "../databases/idpconfgen_database_2024.json"
master_db_file = "../databases/AlphaFlex_database_July2024_v2.json"
max_residues_file = "../databases/AF2_9606_HUMAN_v4_num_residues.json"
sequences_file = "../databases/AF2_9606_HUMAN_v4_sequences.json"  # optional fallback
af2_pdb_glob = "../databases/AF2_9606_PAE_PDB/*.pdb"
af2_pdbs = glob(af2_pdb_glob)

BACKBONE_ATOMS = {"N", "CA", "C", "O"}


# =============================================================================
# Data classes
# =============================================================================

@dataclass(frozen=True)
class IDRSegment:
    kind: str                      # "N", "C", "LINKER", or "LOOP"
    start: int
    end: int
    left_domain_idx: Optional[int] = None   # 0-based folded-domain index
    right_domain_idx: Optional[int] = None  # 0-based folded-domain index

    @property
    def length(self) -> int:
        return self.end - self.start + 1

    @property
    def label(self) -> str:
        if self.kind in {"N", "C"}:
            return self.kind
        assert self.left_domain_idx is not None
        assert self.right_domain_idx is not None
        return f"{self.kind}_F{self.left_domain_idx + 1}_F{self.right_domain_idx + 1}_{self.start}_{self.end}"


@dataclass(frozen=True)
class DomainBlock:
    block_idx: int
    domain_indices: Tuple[int, ...]         # 0-based folded-domain indices
    loop_segments: Tuple[IDRSegment, ...]


# =============================================================================
# Shell / filesystem utilities
# =============================================================================

def run_command(
    cmd: Sequence[str],
    *,
    quiet: bool = True,
    stdout_file: Optional[str] = None,
    ) -> subprocess.CompletedProcess:
        """Run a command list with shell=False and raise a useful error on failure."""
        if stdout_file is not None:
            with open(stdout_file, "w") as outf:
                result = subprocess.run(
                    list(cmd),
                    stdout=outf,
                    stderr=subprocess.PIPE,
                    text=True,
                )
        elif quiet:
            result = subprocess.run(
                list(cmd),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
            )
        else:
            result = subprocess.run(list(cmd), text=True)

        if result.returncode != 0:
            msg = "Command failed:\n" + " ".join(str(c) for c in cmd)
            stderr = (getattr(result, "stderr", None) or "").strip()
            if stderr:
                msg += f"\n\nSTDERR:\n{stderr}"
            raise RuntimeError(msg)

        return result


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def clear_dir(path: str) -> None:
    ensure_dir(path)
    for entry in os.listdir(path):
        full = os.path.join(path, entry)
        if os.path.isdir(full):
            shutil.rmtree(full)
        else:
            os.remove(full)


def remove_matching_files(folder: str, patterns: Sequence[str]) -> None:
    for pattern in patterns:
        for path in glob(os.path.join(folder, pattern)):
            if os.path.isdir(path):
                shutil.rmtree(path)
            elif os.path.exists(path):
                os.remove(path)


def sorted_pdbs(folder: str) -> List[str]:
    return sorted(glob(os.path.join(folder, "*.pdb")))


def output_ensemble_exists(path_final_ens: str, uniprot_id: str) -> bool:
    ensemble_path = os.path.join(path_final_ens, f"{uniprot_id}_idpcg_n{nconfs}.pdb")
    return os.path.isfile(ensemble_path) and os.path.getsize(ensemble_path) > 0


def expand_pdbs_cyclically_to_nconfs(src_paths: Sequence[str], outdir: str, prefix: str = "conformer") -> List[str]:
    """Fill ``outdir`` with nconfs PDBs by cyclically reusing src_paths.

    This is the central speed-first tradeoff: once a hard geometric operation
    succeeds a few times, reuse those successes instead of forcing 100 unique
    successes.
    """
    if not src_paths:
        raise RuntimeError("Cannot expand to nconfs because no source PDBs were provided.")

    tmp = os.path.join(os.path.dirname(outdir), f".{os.path.basename(outdir)}_reuse_tmp")
    clear_dir(tmp)
    for idx in range(1, nconfs + 1):
        src = src_paths[(idx - 1) % len(src_paths)]
        shutil.copy2(src, os.path.join(tmp, f"{prefix}_{idx}.pdb"))

    clear_dir(outdir)
    out_paths = []
    for pdb in sorted_pdbs(tmp):
        dst = os.path.join(outdir, os.path.basename(pdb))
        shutil.move(pdb, dst)
        out_paths.append(dst)
    clear_dir(tmp)
    return out_paths


def expand_folder_cyclically_to_nconfs(folder: str, prefix: str = "conformer") -> List[str]:
    return expand_pdbs_cyclically_to_nconfs(sorted_pdbs(folder), folder, prefix=prefix)


def archive_candidate_files(
    candidates: Sequence[str],
    archive_dir: str,
    archive_cap: int,
    ) -> List[str]:
        """Copy transient lower/upper anchor candidates into a persistent archive.

        The raw lower/upper folders are cleared every loop batch.  Keeping only the
        original paths makes the historical archive contain dangling file names.
        This helper stores stable copies and trims the archive to a bounded size.
        """
        ensure_dir(archive_dir)

        for src in candidates:
            if not os.path.isfile(src):
                continue
            dst = os.path.join(archive_dir, os.path.basename(src))
            if not os.path.exists(dst):
                shutil.copy2(src, dst)

        archived = sorted_pdbs(archive_dir)
        if len(archived) > archive_cap:
            keep = set(random.sample(archived, archive_cap))
            for path in archived:
                if path not in keep and os.path.exists(path):
                    os.remove(path)
            archived = sorted_pdbs(archive_dir)

        return archived


def load_json(path: str, required: bool = True) -> dict:
    if not os.path.exists(path):
        if required:
            raise FileNotFoundError(path)
        return {}
    with open(path, "r") as handle:
        return json.load(handle)


def resolve_ids_file(paths: Sequence[str]) -> str:
    """Return the first existing hard-ID text file, never a directory.

    The previous version used ``os.path.exists()``, which also returns True
    for directories. If ``.`` or another directory accidentally appears in
    the candidate list, that can produce: IsADirectoryError: [Errno 21].
    """
    tried = []
    for path in paths:
        if path is None:
            continue
        path = str(path).strip()
        if not path:
            continue
        tried.append(path)
        if os.path.isfile(path):
            return path

    raise FileNotFoundError(
        "Could not find a hard IDs text file. Tried:\n" + "\n".join(tried)
    )


def load_ids(path: str) -> List[str]:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Hard IDs path is not a file: {path}")
    with open(path, "r") as handle:
        return [line.strip() for line in handle if line.strip()]


def find_template_path(uniprot_id: str) -> str:
    exact = []
    fuzzy = []
    for p in af2_pdbs:
        name = os.path.basename(p)
        if uniprot_id not in name:
            continue
        if name.startswith(f"AF-{uniprot_id}-"):
            exact.append(p)
        else:
            fuzzy.append(p)

    candidates = exact or fuzzy
    if not candidates:
        raise FileNotFoundError(f"Could not find AF2 template PDB for {uniprot_id}.")
    return sorted(candidates)[0]


# =============================================================================
# OpenMM post-processing
# =============================================================================

def resolve_clash(pdb_file: str) -> None:
    """Resolve side-chain clashes by minimizing while restraining backbone atoms."""
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))

    pdb = PDBFile(pdb_file)
    forcefield = ForceField("amber99sb.xml")
    system = forcefield.createSystem(
        pdb.topology,
        constraints=HBonds,
        nonbondedMethod=NoCutoff,
    )

    sidechain_atoms = {
        atom.index
        for atom in pdb.topology.atoms()
        if atom.name not in BACKBONE_ATOMS
    }

    k = 10.0 * kilocalories_per_mole / angstrom**2
    constraint_force = CustomExternalForce(
        "0.5 * k * ((x - x0)^2 + (y - y0)^2 + (z - z0)^2)"
    )
    constraint_force.addPerParticleParameter("x0")
    constraint_force.addPerParticleParameter("y0")
    constraint_force.addPerParticleParameter("z0")
    constraint_force.addGlobalParameter("k", k)

    for atom in pdb.topology.atoms():
        if atom.index not in sidechain_atoms:
            position = pdb.positions[atom.index]
            constraint_force.addParticle(atom.index, [position.x, position.y, position.z])

    system.addForce(constraint_force)

    integrator = LangevinIntegrator(
        300 * kelvin,
        1 / picosecond,
        0.002 * picoseconds,  # type: ignore
    )
    simulation = Simulation(pdb.topology, system, integrator)
    simulation.context.setPositions(pdb.positions)
    simulation.minimizeEnergy(maxIterations=openmm_minimize_max_iterations)

    positions = simulation.context.getState(getPositions=True).getPositions()
    with open(os.path.join(folder, f"{name}_cr.pdb"), "w") as handle:
        PDBFile.writeFile(simulation.topology, positions, handle)

    os.remove(pdb_file)


def add_hydrogens(pdb_file: str, pH: float = 7.4) -> None:
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))

    fixer = PDBFixer(filename=pdb_file)
    fixer.findMissingResidues()
    fixer.findMissingAtoms()
    fixer.addMissingHydrogens(pH=pH)

    with open(os.path.join(folder, f"{name}_pro.pdb"), "w") as handle:
        PDBFile.writeFile(fixer.topology, fixer.positions, handle)

    os.remove(pdb_file)


def postprocess_ensemble(path_final_ens: str, uniprot_id: str) -> None:
    print("  Adding hydrogens...")
    raw_files = sorted(glob(os.path.join(path_final_ens, "conformer_*.pdb")))
    raw_files = [p for p in raw_files if "_pro" not in p and "_cr" not in p]
    if len(raw_files) != nconfs:
        raise RuntimeError(
            f"{uniprot_id}: expected {nconfs} conformers before protonation, found {len(raw_files)}."
        )

    fix_pool = pool_function(add_hydrogens, raw_files, ncores=fix_ncores)
    for _ in fix_pool:
        pass

    print("  Resolving side-chain clashes...")
    hydrogenated_files = sorted(glob(os.path.join(path_final_ens, "conformer_*_pro.pdb")))
    cc_pool = pool_function(resolve_clash, hydrogenated_files, ncores=cc_ncores)
    for _ in cc_pool:
        pass

    minimized_files = sorted(glob(os.path.join(path_final_ens, "conformer_*_cr.pdb")))
    if len(minimized_files) != nconfs:
        raise RuntimeError(
            f"{uniprot_id}: expected {nconfs} minimized conformers, found {len(minimized_files)}."
        )

    ensemble_path = os.path.join(path_final_ens, f"{uniprot_id}_idpcg_n{nconfs}.pdb")
    run_command(["pdb_mkensemble"] + minimized_files, stdout_file=ensemble_path)

    remove_matching_files(path_final_ens, ["conformer*.pdb", "temp*", "energies.log"])


# =============================================================================
# Structure helpers
# =============================================================================

def load_structure(pdb_path: str) -> Tuple[Structure, np.ndarray]:
    struc = Structure(IDPPath(pdb_path))
    struc.build()
    return struc, np.array(struc.data_array, copy=True)


def parse_candidate_array(candidate_pdb: str) -> Optional[np.ndarray]:
    with open(candidate_pdb) as handle:
        pdb_data = handle.read()
    try:
        return np.array(parse_pdb_to_array(pdb_data), copy=True)
    except AssertionError:
        return None


def normalize_structure_array(arr: np.ndarray) -> np.ndarray:
    arr = np.array(arr, copy=True)
    if len(arr) == 0:
        return arr

    arr[:, col_serial] = [str(i) for i in range(1, len(arr) + 1)]
    arr[:, col_segid] = ""
    arr[arr[:, col_resName] == "HIP", col_resName] = "HIS"
    return arr


def save_structure_array(arr: np.ndarray, outpath: str) -> None:
    out = structure_to_pdb(normalize_structure_array(arr))
    write_PDB(out, outpath)


def first_resseq(arr: np.ndarray) -> int:
    return int(arr[0][col_resSeq])


def last_resseq(arr: np.ndarray) -> int:
    return int(arr[-1][col_resSeq])


def remove_first_residue(arr: np.ndarray) -> np.ndarray:
    arr = np.array(arr, copy=True)
    first = first_resseq(arr)
    idx = 0
    while idx < len(arr) and int(arr[idx][col_resSeq]) == first:
        idx += 1
    return arr[idx:]


def remove_last_residue(arr: np.ndarray) -> np.ndarray:
    arr = np.array(arr, copy=True)
    last = last_resseq(arr)
    idx = len(arr)
    while idx > 0 and int(arr[idx - 1][col_resSeq]) == last:
        idx -= 1
    return arr[:idx]


def get_atom_index(arr: np.ndarray, resseq: int, atom_name: str) -> int:
    resnums = arr[:, col_resSeq].astype(int)
    names = arr[:, col_name]
    hits = np.where((resnums == resseq) & (names == atom_name))[0]
    if len(hits) == 0:
        raise ValueError(f"Could not find atom {atom_name} in residue {resseq}.")
    return int(hits[0])


def get_nterm_anchor_coords(target_arr: np.ndarray) -> np.ndarray:
    names = target_arr[:, col_name]
    resnums = target_arr[:, col_resSeq].astype(int)
    first = int(resnums[0])

    idx = {}
    for j, atom in enumerate(names):
        curr = int(resnums[j])
        if curr == first + 1 and atom == "N":
            idx["N"] = j
        elif curr == first + 1 and atom == "CA":
            idx["CA"] = j
        elif curr == first and atom == "C":
            idx["C"] = j
        elif curr > first + 2:
            break

    if set(idx) != {"C", "N", "CA"}:
        raise ValueError("Could not determine N-terminal anchor coordinates.")

    return np.array(
        [
            target_arr[idx["C"]][cols_coords].astype(float),
            target_arr[idx["N"]][cols_coords].astype(float),
            target_arr[idx["CA"]][cols_coords].astype(float),
        ]
    )


def get_cterm_anchor_coords(target_arr: np.ndarray) -> np.ndarray:
    names = target_arr[:, col_name]
    resnums = target_arr[:, col_resSeq].astype(int)
    last = int(resnums[-1])

    idx = {}
    for off in range(len(names)):
        j = len(names) - 1 - off
        curr = int(resnums[j])
        atom = names[j]
        if curr == last and atom == "N":
            idx["N"] = j
        elif curr == last and atom == "CA":
            idx["CA"] = j
        elif curr == last - 1 and atom == "C":
            idx["C"] = j
        elif curr < last - 2:
            break

    if set(idx) != {"C", "N", "CA"}:
        raise ValueError("Could not determine C-terminal anchor coordinates.")

    return np.array(
        [
            target_arr[idx["C"]][cols_coords].astype(float),
            target_arr[idx["N"]][cols_coords].astype(float),
            target_arr[idx["CA"]][cols_coords].astype(float),
        ]
    )


def get_loop_anchor_coords(scaffold_arr: np.ndarray, start: int, end: int) -> Tuple[np.ndarray, np.ndarray]:
    """Return lower and upper 3-atom anchors for a LOOP-IDR.

    The generated loop sequence is residues start-2 ... end+2.
    Lower anchor matches residues start-2/start-1.
    Upper anchor matches residues end+1/end+2.
    """
    lower = start - 1
    upper = end + 1

    lower_coords = np.array(
        [
            scaffold_arr[get_atom_index(scaffold_arr, lower - 1, "C")][cols_coords].astype(float),
            scaffold_arr[get_atom_index(scaffold_arr, lower, "N")][cols_coords].astype(float),
            scaffold_arr[get_atom_index(scaffold_arr, lower, "CA")][cols_coords].astype(float),
        ]
    )
    upper_coords = np.array(
        [
            scaffold_arr[get_atom_index(scaffold_arr, upper, "C")][cols_coords].astype(float),
            scaffold_arr[get_atom_index(scaffold_arr, upper + 1, "N")][cols_coords].astype(float),
            scaffold_arr[get_atom_index(scaffold_arr, upper + 1, "CA")][cols_coords].astype(float),
        ]
    )
    return lower_coords, upper_coords


def atom_clash_count(
    arr_a: np.ndarray,
    arr_b: np.ndarray,
    *,
    cutoff: float = loop_atom_clash_cutoff_angstrom,
    ignore_adjacent_residues: bool = True,
    chunk_size: int = 256,
    ) -> int:
        """Small vectorized heavy-atom clash counter.

        This complements IDPCG's `count_clashes` after LOOP-IDR extraction.  It
        ignores same/adjacent residue contacts so normal peptide-bond neighbors do
        not trigger false positives.
        """
        if len(arr_a) == 0 or len(arr_b) == 0:
            return 0

        coords_a = arr_a[:, cols_coords].astype(float)
        coords_b = arr_b[:, cols_coords].astype(float)
        res_a = arr_a[:, col_resSeq].astype(int)
        res_b = arr_b[:, col_resSeq].astype(int)
        cutoff2 = cutoff * cutoff
        count = 0

        for start in range(0, len(coords_a), chunk_size):
            end = min(start + chunk_size, len(coords_a))
            diff = coords_a[start:end, None, :] - coords_b[None, :, :]
            d2 = np.sum(diff * diff, axis=2)
            mask = d2 < cutoff2
            if ignore_adjacent_residues:
                sep = np.abs(res_a[start:end, None] - res_b[None, :])
                mask &= sep > 1
            count += int(np.count_nonzero(mask))
            if count > loop_max_atom_clashes:
                return count

        return count


def has_bad_contacts(arr_a: np.ndarray, arr_b: np.ndarray) -> bool:
    return atom_clash_count(arr_a, arr_b) > loop_max_atom_clashes


def atom_clash_score_limited(
    arr_a: np.ndarray,
    arr_b: np.ndarray,
    *,
    cutoff: float = loop_atom_clash_cutoff_angstrom,
    ignore_adjacent_residues: bool = True,
    chunk_size: int = 256,
    stop_after: int = loop_insert_fallback_score_cutoff + 1,
    ) -> int:
        """Return a capped heavy-atom close-contact score for fallback ranking.

        Unlike atom_clash_count(), this is used to rank candidate loop inserts when
        every candidate fails the strict screen.  It still ignores same/adjacent
        residue contacts, so normal peptide-bond neighbors do not dominate.
        """
        if len(arr_a) == 0 or len(arr_b) == 0:
            return 0

        coords_a = arr_a[:, cols_coords].astype(float)
        coords_b = arr_b[:, cols_coords].astype(float)
        res_a = arr_a[:, col_resSeq].astype(int)
        res_b = arr_b[:, col_resSeq].astype(int)
        cutoff2 = cutoff * cutoff
        count = 0

        for start in range(0, len(coords_a), chunk_size):
            end = min(start + chunk_size, len(coords_a))
            diff = coords_a[start:end, None, :] - coords_b[None, :, :]
            d2 = np.sum(diff * diff, axis=2)
            mask = d2 < cutoff2
            if ignore_adjacent_residues:
                sep = np.abs(res_a[start:end, None] - res_b[None, :])
                mask &= sep > 1
            count += int(np.count_nonzero(mask))
            if count > stop_after:
                return count
        return count


def insert_idr_by_resseq(base_arr: np.ndarray, idr_arr: np.ndarray, start: int, end: int) -> np.ndarray:
    """Insert/replace residues start..end in a residue-numbered structure array."""
    base = np.array(base_arr, copy=True)
    insert = np.array(idr_arr, copy=True)

    base_res = base[:, col_resSeq].astype(int)
    prefix = base[base_res < start]
    suffix = base[base_res > end]

    out = np.array(prefix.tolist() + insert.tolist() + suffix.tolist(), dtype=object)
    return normalize_structure_array(out)


# =============================================================================
# Domain / IDR topology classification
# =============================================================================

def normalize_ranges(ranges: Sequence[Sequence[int]]) -> List[List[int]]:
    return sorted([[int(s), int(e)] for s, e in ranges], key=lambda x: (x[0], x[1]))


def find_fld_domains(idrs: Sequence[Sequence[int]], max_res: int) -> List[List[int]]:
    domains: List[List[int]] = []

    if not idrs:
        domains.append([1, max_res])
        return domains

    if idrs[0][0] > 1:
        domains.append([1, idrs[0][0] - 1])

    for i in range(len(idrs) - 1):
        start = idrs[i][1] + 1
        end = idrs[i + 1][0] - 1
        if start <= end:
            domains.append([start, end])

    if idrs[-1][1] < max_res:
        domains.append([idrs[-1][1] + 1, max_res])

    return domains


def interaction_set(interactions: Sequence[Sequence[str]]) -> set:
    pairs = set()
    for pair in interactions:
        if len(pair) != 2:
            continue
        a, b = pair
        pairs.add(tuple(sorted((str(a), str(b)))))
    return pairs


def find_flanking_domain_indices(
    idr: Sequence[int],
    domains: Sequence[Sequence[int]],
    ) -> Tuple[int, int]:
        start, end = int(idr[0]), int(idr[1])
        left = None
        right = None
        for idx, (dstart, dend) in enumerate(domains):
            if int(dend) == start - 1:
                left = idx
            if int(dstart) == end + 1:
                right = idx
        if left is None or right is None:
            raise ValueError(f"Could not find flanking folded domains for internal IDR {start}-{end}.")
        return left, right


def adjacent_pair_is_loop(
    left_idx: int,
    right_idx: int,
    interactions: set,
    mean_pae: dict,
    ) -> bool:
        left_label = f"F{left_idx + 1}"
        right_label = f"F{right_idx + 1}"
        if tuple(sorted((left_label, right_label))) in interactions:
            return True

        if use_adjacent_pae_fallback_for_loops:
            key1 = f"{left_label}-{right_label}"
            key2 = f"{right_label}-{left_label}"
            pae = mean_pae.get(key1, mean_pae.get(key2, None))
            if pae is not None and float(pae) <= adjacent_loop_pae_cutoff:
                return True

        return False


def classify_segments(
    idrs: Sequence[Sequence[int]],
    domains: Sequence[Sequence[int]],
    num_res: int,
    interactions_raw: Sequence[Sequence[str]],
    mean_pae: dict,
    ) -> Tuple[Optional[IDRSegment], List[IDRSegment], Optional[IDRSegment]]:
        interactions = interaction_set(interactions_raw)
        n_term = None
        c_term = None
        internal: List[IDRSegment] = []

        for start, end in normalize_ranges(idrs):
            if start == 1:
                n_term = IDRSegment("N", start, end)
                continue
            if end == num_res:
                c_term = IDRSegment("C", start, end)
                continue

            left_idx, right_idx = find_flanking_domain_indices([start, end], domains)
            if right_idx != left_idx + 1:
                raise ValueError(
                    f"Unexpected non-adjacent flanking domains for IDR {start}-{end}: "
                    f"F{left_idx + 1}, F{right_idx + 1}."
                )
            kind = "LOOP" if adjacent_pair_is_loop(left_idx, right_idx, interactions, mean_pae) else "LINKER"
            internal.append(IDRSegment(kind, start, end, left_idx, right_idx))

        return n_term, internal, c_term


def build_domain_blocks(internal_segments: Sequence[IDRSegment], n_domains: int) -> Tuple[List[DomainBlock], List[IDRSegment]]:
    """Partition folded domains into rigid LOOP blocks separated by LINKERs."""
    if n_domains == 0:
        raise ValueError("No folded domains were found. This is not a hard case.")

    linkers: List[IDRSegment] = []
    blocks: List[DomainBlock] = []
    current_domains = [0]
    current_loops: List[IDRSegment] = []

    for seg in sorted(internal_segments, key=lambda x: x.start):
        if seg.left_domain_idx is None or seg.right_domain_idx is None:
            raise ValueError(f"Internal segment lacks flanking domains: {seg}")

        expected_left = current_domains[-1]
        if seg.left_domain_idx != expected_left:
            raise ValueError(
                f"Topology discontinuity at {seg.label}: expected left domain "
                f"F{expected_left + 1}, got F{seg.left_domain_idx + 1}."
            )

        if seg.kind == "LOOP":
            current_loops.append(seg)
            current_domains.append(seg.right_domain_idx)
        elif seg.kind == "LINKER":
            blocks.append(
                DomainBlock(
                    block_idx=len(blocks),
                    domain_indices=tuple(current_domains),
                    loop_segments=tuple(current_loops),
                )
            )
            linkers.append(seg)
            current_domains = [seg.right_domain_idx]
            current_loops = []
        else:
            raise ValueError(f"Unsupported internal segment kind: {seg.kind}")

    blocks.append(
        DomainBlock(
            block_idx=len(blocks),
            domain_indices=tuple(current_domains),
            loop_segments=tuple(current_loops),
        )
    )

    return blocks, linkers


def describe_topology(
    n_term: Optional[IDRSegment],
    internal_segments: Sequence[IDRSegment],
    c_term: Optional[IDRSegment],
    ) -> str:
        parts = []
        if n_term is not None:
            parts.append(f"N({n_term.start}-{n_term.end})")
        for seg in sorted(internal_segments, key=lambda x: x.start):
            prefix = "O" if seg.kind == "LOOP" else "L"
            parts.append(f"{prefix}({seg.start}-{seg.end})")
        if c_term is not None:
            parts.append(f"C({c_term.start}-{c_term.end})")
        return "-".join(parts) if parts else "folded-only"


# =============================================================================
# Template extraction
# =============================================================================

def extract_residue_ranges(struc_arr: np.ndarray, ranges: Sequence[Sequence[int]]) -> np.ndarray:
    res = struc_arr[:, col_resSeq].astype(int)
    mask = np.zeros(res.shape, dtype=bool)
    for start, end in ranges:
        mask |= (res >= int(start)) & (res <= int(end))
    out = np.array(struc_arr[mask], copy=True)
    if len(out) == 0:
        raise ValueError(f"Empty extraction for ranges: {ranges}")
    return normalize_structure_array(out)


def make_block_base_template(
    uniprot_id: str,
    struc_arr: np.ndarray,
    domains: Sequence[Sequence[int]],
    block: DomainBlock,
    path_templates: str,
    ) -> str:
        ranges = [domains[i] for i in block.domain_indices]
        arr = extract_residue_ranges(struc_arr, ranges)
        outpath = os.path.join(path_templates, f"{uniprot_id}_block{block.block_idx + 1}_base.pdb")
        save_structure_array(arr, outpath)
        return outpath


# =============================================================================
# IDPCG build and alignment
# =============================================================================

def is_long_idr(start: int, end: int) -> bool:
    return (end - start + 1) >= long_idr_threshold


def build_range_seq(sequence: str, start: int, end: int, kind: str) -> str:
    """Return sequence with 2-residue overhangs where needed.

    start/end are 1-based original residue numbers for the actual IDR.
    """
    if kind == "N":
        return sequence[: min(len(sequence), end + 2)]
    if kind == "C":
        return sequence[max(0, start - 3):]
    # LINKER and LOOP
    seq_start = start - 2
    seq_end = end + 2
    if seq_start < 1 or seq_end > len(sequence):
        raise ValueError(
            f"Cannot build {kind} {start}-{end} with 2-residue overhangs "
            f"for sequence length {len(sequence)}."
        )
    return sequence[seq_start - 1: seq_end]


def loop_sequence_with_offset(sequence: str, start: int, end: int) -> Tuple[str, int]:
    """Return LOOP build sequence and offset for local->original residue numbers.

    local residue 1 maps to original residue local_offset + 1.
    """
    seq_start = start - 2
    seq_end = end + 2
    if seq_start < 1 or seq_end > len(sequence):
        raise ValueError(
            f"LOOP {start}-{end} cannot use required 2-residue overhangs "
            f"with sequence length {len(sequence)}."
        )
    return sequence[seq_start - 1: seq_end], seq_start - 1


def run_build(seq: str, rs: int, nc: int, n: int, outdir: str, use_long: bool = False) -> None:
    cmd = [
        "idpconfgen",
        "build",
        "-seq",
        seq,
        "-db",
        idpcg_database,
        "--dloop-off",
        "--dany",
        "-rs",
        str(rs),
        "-nc",
        str(nc),
        "-n",
        str(n),
        "-of",
        outdir,
    ]
    if use_long:
        cmd.extend(["--long", "--force-long"])
    run_command(cmd)


def align_idr_to_target(
    candidate_pdb: str,
    target_pdb: str,
    case: str,
    max_clash: int = 80,
    tolerance: float = 0.4,
    ) -> Tuple[Optional[np.ndarray], np.ndarray]:
        target_struc, target_arr = load_structure(target_pdb)
        candidate_arr = parse_candidate_array(candidate_pdb)
        if candidate_arr is None:
            return None, target_arr

        if case == "N-IDR":
            target_coords = get_nterm_anchor_coords(target_arr)
        elif case == "C-IDR":
            target_coords = get_cterm_anchor_coords(target_arr)
        else:
            raise ValueError(f"Unsupported IDR alignment case: {case}")

        aligned_candidate = align_coords(candidate_arr, target_coords, case)
        clashes, fragment = count_clashes(
            aligned_candidate,
            target_struc,
            case,
            max_clash=max_clash,
            tolerance=tolerance,
        )
        if type(clashes) is int:
            return np.array(fragment, copy=True), target_arr
        return None, target_arr


def align_fragment_to_target(
    next_fragment_pdb: str,
    target_pdb: str,
    max_clash: int = 100,
    tolerance: float = 0.4,
    ) -> Tuple[Optional[np.ndarray], np.ndarray]:
        target_struc, target_arr = load_structure(target_pdb)
        fragment_arr = parse_candidate_array(next_fragment_pdb)
        if fragment_arr is None:
            return None, target_arr

        target_coords = get_cterm_anchor_coords(target_arr)
        aligned_fragment = align_coords(fragment_arr, target_coords, "C-IDR")
        clashes, fragment = count_clashes(
            aligned_fragment,
            target_struc,
            "C-IDR",
            max_clash=max_clash,
            tolerance=tolerance,
        )
        if type(clashes) is int:
            return np.array(fragment, copy=True), target_arr
        return None, target_arr


# =============================================================================
# Stitching for N/C/LINKER and block appending
# =============================================================================

def stitch_prepend_nidr(aligned_idr_arr: np.ndarray, target_arr: np.ndarray) -> np.ndarray:
    aligned_idr_arr = np.array(aligned_idr_arr, copy=True)
    target_arr = np.array(target_arr, copy=True)

    chain = target_arr[:, col_chainID][0]
    aligned_idr_arr[:, col_chainID] = chain

    stitched_idr = remove_last_residue(aligned_idr_arr)
    stitched_target = remove_first_residue(target_arr)
    return normalize_structure_array(
        np.array(stitched_idr.tolist() + stitched_target.tolist(), dtype=object)
    )


def stitch_append_idr(target_arr: np.ndarray, aligned_idr_arr: np.ndarray) -> np.ndarray:
    target_arr = np.array(target_arr, copy=True)
    aligned_idr_arr = np.array(aligned_idr_arr, copy=True)

    chain = target_arr[:, col_chainID][0]
    aligned_idr_arr[:, col_chainID] = chain

    last_target = last_resseq(target_arr)
    stitched_target = remove_last_residue(target_arr)
    stitched_idr = remove_first_residue(aligned_idr_arr)

    stitched_idr[:, col_resSeq] = (
        stitched_idr[:, col_resSeq].astype(int) + (last_target - 2)
    ).astype(str)

    return normalize_structure_array(
        np.array(stitched_target.tolist() + stitched_idr.tolist(), dtype=object)
    )


def stitch_append_fragment(target_arr: np.ndarray, aligned_fragment_arr: np.ndarray) -> np.ndarray:
    target_arr = np.array(target_arr, copy=True)
    aligned_fragment_arr = np.array(aligned_fragment_arr, copy=True)

    chain = target_arr[:, col_chainID][0]
    aligned_fragment_arr[:, col_chainID] = chain

    stitched_target = remove_last_residue(target_arr)
    stitched_fragment = remove_first_residue(aligned_fragment_arr)

    return normalize_structure_array(
        np.array(stitched_target.tolist() + stitched_fragment.tolist(), dtype=object)
    )


# =============================================================================
# LOOP-IDR library generation
# =============================================================================

def loop_build_batch_size(loop_len: int) -> int:
    if loop_len <= 25:
        mult = loop_short_multiplier
    elif loop_len <= 60:
        mult = loop_medium_multiplier
    else:
        mult = loop_long_multiplier
    return max(loop_min_batch_size, nconfs * mult)


def loop_break_attach(
    candidate_pdb: str,
    scaffold_pdb: str,
    start: int,
    end: int,
    run_tag: str,
    output_lower: Optional[str] = None,
    output_upper: Optional[str] = None,
    ) -> None:
        """Align one built LOOP candidate to the lower or upper anchor.

        This is the generalized version of the original hard-single `break_idr_attach`,
        but it preserves original residue numbering in block templates instead of
        normalizing residue numbers to 1.
        """
        if output_lower is None and output_upper is None:
            return

        scaffold_struc, scaffold_arr = load_structure(scaffold_pdb)
        lower_coords, upper_coords = get_loop_anchor_coords(scaffold_arr, start, end)

        candidate_arr = parse_candidate_array(candidate_pdb)
        if candidate_arr is None:
            return

        stem = StdPath(candidate_pdb).stem

        if output_lower is not None:
            aligned_lower = align_coords(candidate_arr, lower_coords, "C-IDR")
            clashes_lower, fragment_lower = count_clashes(
                aligned_lower,
                scaffold_struc,
                "C-IDR",
                max_clash=loop_anchor_max_clash,
                tolerance=loop_anchor_tolerance,
            )
            if type(clashes_lower) is int:
                write_PDB(
                    structure_to_pdb(fragment_lower),
                    os.path.join(output_lower, f"{run_tag}_L_{stem}.pdb"),
                )

        if output_upper is not None:
            aligned_upper = align_coords(candidate_arr, upper_coords, "N-IDR")
            clashes_upper, fragment_upper = count_clashes(
                aligned_upper,
                scaffold_struc,
                "N-IDR",
                max_clash=loop_anchor_max_clash,
                tolerance=loop_anchor_tolerance,
            )
            if type(clashes_upper) is int:
                write_PDB(
                    structure_to_pdb(fragment_upper),
                    os.path.join(output_upper, f"{run_tag}_U_{stem}.pdb"),
                )


def extract_loop_insert_arr(
    loop_candidate_pdb: str,
    start: int,
    end: int,
    local_offset: int,
    chain_id: str,
    ) -> Optional[np.ndarray]:
        """Extract only residues start..end from a LOOP bridge candidate.

        The accepted candidate normally has local residue numbering from the IDPCG
        build sequence.  We map local residue numbers back to original residue
        numbers using local_offset.  A fallback accepts already-original numbering.
        """
        arr = parse_candidate_array(loop_candidate_pdb)
        if arr is None or len(arr) == 0:
            return None

        local_res = arr[:, col_resSeq].astype(int)
        orig_res = local_res + local_offset
        mask = (orig_res >= start) & (orig_res <= end)

        if not np.any(mask):
            # Fallback in case a helper function already wrote original numbering.
            orig_res = local_res
            mask = (orig_res >= start) & (orig_res <= end)

        if not np.any(mask):
            return None

        insert = np.array(arr[mask], copy=True)
        insert[:, col_resSeq] = orig_res[mask].astype(str)
        insert[:, col_chainID] = chain_id
        return normalize_structure_array(insert)


def build_loop_library(
    *,
    sequence: str,
    seg: IDRSegment,
    scaffold_pdb: str,
    path_loop_root: str,
    target_n: int,
    ) -> List[str]:
        """Build a reusable library of accepted LOOP-IDR inserts."""
        ensure_dir(path_loop_root)
        path_raw = os.path.join(path_loop_root, "raw")
        path_lower = os.path.join(path_loop_root, "lower")
        path_upper = os.path.join(path_loop_root, "upper")
        path_joined = os.path.join(path_loop_root, "joined")
        path_lower_archive = os.path.join(path_loop_root, "lower_archive")
        path_upper_archive = os.path.join(path_loop_root, "upper_archive")
        path_library = os.path.join(path_loop_root, "library")
        for folder in (
            path_raw,
            path_lower,
            path_upper,
            path_joined,
            path_lower_archive,
            path_upper_archive,
            path_library,
        ):
            clear_dir(folder)

        loop_seq, local_offset = loop_sequence_with_offset(sequence, seg.start, seg.end)
        use_long = is_long_idr(seg.start, seg.end)
        batch_n = loop_build_batch_size(seg.length)

        _, scaffold_arr = load_structure(scaffold_pdb)
        chain_id = scaffold_arr[:, col_chainID][0]

        library_paths: List[str] = []
        lower_archive: List[str] = []
        upper_archive: List[str] = []
        archive_cap = max(loop_join_archive_min, nconfs, target_n * loop_join_archive_factor)
        rs = 0

        print(
            f"    Building LOOP library for {seg.label}: target={target_n}, "
            f"loop_len={seg.length}, batch_nc={batch_n}"
        )

        batch_idx = 0
        no_progress_batches = 0
        while len(library_paths) < target_n:

            for folder in (path_raw, path_lower, path_upper, path_joined):
                clear_dir(folder)

            # Keep idpconfgen build serial at the script level. It already
            # parallelizes internally via -n {ncores}.
            run_build(
                seq=loop_seq,
                rs=rs,
                nc=batch_n,
                n=ncores,
                outdir=path_raw,
                use_long=use_long,
            )

            raw_candidates = sorted_pdbs(path_raw)
            if not raw_candidates:
                rs += batch_n + 17
                continue

            run_tag = f"b{batch_idx:03d}"

            lower_exec = partial(
                loop_break_attach,
                scaffold_pdb=scaffold_pdb,
                start=seg.start,
                end=seg.end,
                run_tag=run_tag,
                output_lower=path_lower,
                output_upper=None,
            )
            lower_pool = pool_function(lower_exec, raw_candidates, ncores=ncores)
            for _ in lower_pool:
                pass

            upper_exec = partial(
                loop_break_attach,
                scaffold_pdb=scaffold_pdb,
                start=seg.start,
                end=seg.end,
                run_tag=run_tag,
                output_lower=None,
                output_upper=path_upper,
            )
            upper_pool = pool_function(upper_exec, raw_candidates, ncores=ncores)
            for _ in upper_pool:
                pass

            lower_candidates = sorted_pdbs(path_lower)
            upper_candidates = sorted_pdbs(path_upper)

            lower_archive = archive_candidate_files(
                lower_candidates,
                path_lower_archive,
                archive_cap,
            )
            upper_archive = archive_candidate_files(
                upper_candidates,
                path_upper_archive,
                archive_cap,
            )

            remaining = max(1, target_n - len(library_paths))
            base_join_cap = max(loop_join_cap_min, nconfs, remaining * loop_join_search_factor)
            if no_progress_batches >= loop_join_adapt_trigger:
                boost = min(
                    loop_join_cap_max_multiplier,
                    1 + (no_progress_batches - loop_join_adapt_trigger + 1),
                )
            else:
                boost = 1

            join_cap = min(archive_cap, base_join_cap * boost)

            # Select from persistent archives only.  The per-batch lower/upper
            # folders are transient and are cleared at the start of each batch.
            lower_for_join = (
                random.sample(lower_archive, min(join_cap, len(lower_archive)))
                if lower_archive else []
            )
            upper_for_join = (
                random.sample(upper_archive, min(join_cap, len(upper_archive)))
                if upper_archive else []
            )

            if lower_for_join and upper_for_join:
                join_exec = partial(
                    next_seeker,
                    nterm_idr_lib=upper_for_join,
                    max_clash=loop_join_max_clash,
                    tolerance=loop_join_tolerance,
                    output_folder=path_joined,
                )
                join_pool = pool_function(join_exec, lower_for_join, ncores=ncores)
                for _ in join_pool:
                    pass

            joined = sorted_pdbs(path_joined)
            random.shuffle(joined)

            eval_exec = partial(
                evaluate_joined_candidate,
                start=seg.start,
                end=seg.end,
                local_offset=local_offset,
                chain_id=chain_id,
                scaffold_arr=scaffold_arr,
            )
            eval_pool = pool_function(eval_exec, joined, ncores=ncores)
            accepted_inserts = [arr for arr in eval_pool if arr is not None]

            prev_count = len(library_paths)
            for insert_arr in accepted_inserts:
                if len(library_paths) >= target_n:
                    break
                lib_path = os.path.join(
                    path_library,
                    f"loop_{seg.start}_{seg.end}_candidate_{len(library_paths) + 1:05d}.pdb",
                )
                save_structure_array(insert_arr, lib_path)
                library_paths.append(lib_path)

            if len(library_paths) == prev_count:
                no_progress_batches += 1
            else:
                no_progress_batches = 0

            print(
                f"      batch {batch_idx + 1}: lower={len(lower_candidates)}, "
                f"upper={len(upper_candidates)}, joined={len(joined)}, "
                f"library={len(library_paths)}/{target_n}, "
                f"join_cap={join_cap}, boost={boost}, "
                f"archive=({len(lower_archive)},{len(upper_archive)})"
            )

            batches_done = batch_idx + 1
            if batches_done % loop_progress_report_every == 0:
                print(
                    f"      progress {seg.label}: {len(library_paths)}/{target_n} "
                    f"accepted after {batches_done} batches"
                )

            if batches_done >= loop_no_solution_batch_limit and len(library_paths) == 0:
                raise RuntimeError(
                    f"No LOOP candidates found for {seg.label} after "
                    f"{loop_no_solution_batch_limit} batches."
                )

            if no_progress_batches >= loop_no_progress_patience:
                raise RuntimeError(
                    f"LOOP library stalled for {seg.label}: no new accepted candidates in "
                    f"{loop_no_progress_patience} consecutive batches "
                    f"(current={len(library_paths)}/{target_n})."
                )

            rs += batch_n + 17
            batch_idx += 1

        if len(library_paths) < target_n:
            raise RuntimeError(
                f"Could not collect {target_n} LOOP candidates for {seg.label}; "
                f"collected {len(library_paths)}."
            )

        # Drop bulky raw/intermediate dirs but keep the final library until the
        # protein finishes, so failed reruns can be inspected.
        for folder in (path_raw, path_lower, path_upper, path_joined, path_lower_archive, path_upper_archive):
            clear_dir(folder)

        return library_paths[:target_n]


def load_loop_library_arrays(paths: Sequence[str]) -> List[np.ndarray]:
    arrays = []
    for path in paths:
        arr = parse_candidate_array(path)
        if arr is None:
            continue
        arrays.append(normalize_structure_array(arr))
    return arrays


def evaluate_joined_candidate(
    joined_pdb: str,
    *,
    start: int,
    end: int,
    local_offset: int,
    chain_id: str,
    scaffold_arr: np.ndarray,
    ) -> Optional[np.ndarray]:
        """Extract and validate one joined LOOP candidate for library insertion."""
        insert_arr = extract_loop_insert_arr(
            joined_pdb,
            start,
            end,
            local_offset,
            chain_id,
        )
        if insert_arr is None:
            return None
        if has_bad_contacts(insert_arr, scaffold_arr):
            return None
        return insert_arr


def choose_loop_insert(
    candidates: Sequence[np.ndarray],
    current_arr: np.ndarray,
    used_indices: set,
    *,
    seg_label: str = "LOOP",
    conf_idx: Optional[int] = None,
    ) -> Tuple[int, np.ndarray]:
        """Choose a loop insert, preferring strict no-clash but finishing if possible.

        The previous behavior failed the whole protein if every candidate in a small
        loop library made a close contact with a previously inserted loop.  That is
        too brittle for multi-loop hard cases.  Here the priority order is:

          1. unused candidate with no bad contacts,
          2. reused candidate with no bad contacts,
          3. least-bad candidate if allow_least_bad_loop_insert is enabled.

        The least-bad fallback still uses a true IDPCG/next_seeker closed loop; it
        does not use AF2 loop coordinates.
        """
        if not candidates:
            raise RuntimeError(f"No LOOP candidates available for {seg_label}.")

        unused = [i for i in range(len(candidates)) if i not in used_indices]
        random.shuffle(unused)

        for idx in unused:
            cand = candidates[idx]
            if not has_bad_contacts(cand, current_arr):
                return idx, cand

        all_indices = list(range(len(candidates)))
        random.shuffle(all_indices)
        for idx in all_indices:
            cand = candidates[idx]
            if not has_bad_contacts(cand, current_arr):
                return idx, cand

        if allow_least_bad_loop_insert:
            scored = []
            for idx, cand in enumerate(candidates):
                score = atom_clash_score_limited(cand, current_arr)
                scored.append((score, idx, cand))
            score, idx, cand = min(scored, key=lambda x: x[0])
            where = f" conformer {conf_idx}" if conf_idx is not None else ""
            if score <= loop_insert_fallback_score_cutoff:
                print(
                    f"    WARNING: using least-bad closed IDPCG insert for {seg_label}{where}; "
                    f"close-contact score={score} <= {loop_insert_fallback_score_cutoff}."
                )
                return idx, cand
            raise RuntimeError(
                f"No LOOP candidate for {seg_label} could be inserted without bad contacts; "
                f"best close-contact score={score} > {loop_insert_fallback_score_cutoff}."
            )

        raise RuntimeError(f"No LOOP candidate could be inserted without bad contacts for {seg_label}.")


def make_af2_loop_fallback_insert(
    full_template_arr: np.ndarray,
    seg: IDRSegment,
    chain_id: str,
    ) -> np.ndarray:
        """Use original AF2 coordinates for a LOOP-IDR as a closure fallback.

        This is intentionally low-diversity, but it gives a chemically continuous
        loop in the same coordinate frame as the block template.  It is much safer
        than inserting a lower-anchor-only IDPCG fragment that does not meet the
        upper anchor.
        """
        loop_arr = extract_residue_ranges(full_template_arr, [[seg.start, seg.end]])
        loop_arr = np.array(loop_arr, copy=True)
        loop_arr[:, col_chainID] = chain_id
        return normalize_structure_array(loop_arr)


def build_block_ensemble(
    *,
    uniprot_id: str,
    sequence: str,
    block: DomainBlock,
    base_template_pdb: str,
    path_block_dir: str,
    path_loop_root: str,
    full_template_arr: Optional[np.ndarray] = None,
    ) -> List[str]:
        """Build nconfs conformers for one rigid interaction block."""
        clear_dir(path_block_dir)
        ensure_dir(path_loop_root)

        _, base_arr = load_structure(base_template_pdb)

        if not block.loop_segments:
            out_paths = []
            for idx in range(1, nconfs + 1):
                out = os.path.join(path_block_dir, f"block{block.block_idx + 1}_conformer_{idx}.pdb")
                shutil.copy2(base_template_pdb, out)
                out_paths.append(out)
            return out_paths

        if SPEED_FIRST_REUSE_MODE:
            loop_target = max(min_loop_library_required, int(fast_loop_unique_target))
            print(
                f"  SPEED-FIRST: building only {loop_target} unique LOOP candidate(s) "
                f"per loop, then reusing them cyclically for {nconfs} outputs."
            )
        else:
            loop_target = nconfs * loop_library_multiplier
        loop_libraries: Dict[str, List[np.ndarray]] = {}

        for seg in block.loop_segments:
            seg_root = os.path.join(path_loop_root, f"block{block.block_idx + 1}_{seg.label}")
            lib_arrays: List[np.ndarray] = []
            try:
                lib_paths = build_loop_library(
                    sequence=sequence,
                    seg=seg,
                    scaffold_pdb=base_template_pdb,
                    path_loop_root=seg_root,
                    target_n=loop_target,
                )
                lib_arrays = load_loop_library_arrays(lib_paths)
            except Exception as exc:
                if not allow_af2_loop_fallback or full_template_arr is None:
                    raise
                print(
                    f"    WARNING: IDPCG loop closure failed for {seg.label}: {exc}\n"
                    f"    Falling back to original AF2 loop coordinates for this LOOP-IDR."
                )

            if len(lib_arrays) < min_loop_library_required:
                if allow_af2_loop_fallback and full_template_arr is not None:
                    chain_id = base_arr[:, col_chainID][0]
                    fallback = make_af2_loop_fallback_insert(full_template_arr, seg, chain_id)
                    lib_arrays = [fallback]
                    print(
                        f"    AF2 LOOP fallback for {seg.label}: "
                        f"1 unique insert -> {nconfs} output conformers."
                    )
                else:
                    raise RuntimeError(
                        f"{uniprot_id}: LOOP library for {seg.label} has only {len(lib_arrays)} usable arrays "
                        f"(minimum required={min_loop_library_required})."
                    )

            if len(lib_arrays) < nconfs:
                print(
                    f"    Reusing LOOP library for {seg.label}: "
                    f"{len(lib_arrays)} unique insert(s) -> {nconfs} output conformers."
                )
            loop_libraries[seg.label] = lib_arrays

        used_by_loop: Dict[str, set] = {seg.label: set() for seg in block.loop_segments}
        out_paths = []

        for conf_idx in range(1, nconfs + 1):
            current_arr = np.array(base_arr, copy=True)

            for seg in sorted(block.loop_segments, key=lambda x: x.start):
                lib = loop_libraries[seg.label]
                chosen_idx, insert_arr = choose_loop_insert(
                    lib,
                    current_arr,
                    used_by_loop[seg.label],
                    seg_label=seg.label,
                    conf_idx=conf_idx,
                )
                used_by_loop[seg.label].add(chosen_idx)
                current_arr = insert_idr_by_resseq(current_arr, insert_arr, seg.start, seg.end)

            out = os.path.join(path_block_dir, f"block{block.block_idx + 1}_conformer_{conf_idx}.pdb")
            save_structure_array(current_arr, out)
            out_paths.append(out)

        return out_paths


# =============================================================================
# Flexible assembly stages
# =============================================================================

def seed_without_nidr(first_block_paths: Sequence[str], path_current: str) -> None:
    clear_dir(path_current)
    if len(first_block_paths) < nconfs:
        raise RuntimeError(f"First block has {len(first_block_paths)} conformers, expected {nconfs}.")

    for idx, src in enumerate(first_block_paths[:nconfs], start=1):
        shutil.copy2(src, os.path.join(path_current, f"conformer_{idx}.pdb"))


def seed_with_nidr(
    first_block_paths: Sequence[str],
    nidr_seq: str,
    nidr_is_long: bool,
    path_build: str,
    path_current: str,
    ) -> None:
        clear_dir(path_current)

        target_unique = nconfs
        if SPEED_FIRST_REUSE_MODE:
            target_unique = min(nconfs, max(1, int(fast_terminal_unique_target)))
            print(f"  SPEED-FIRST: building up to {target_unique} unique N-IDR seed(s), then cyclic reuse.")

        built = 0
        failures = 0
        for source_idx, target in enumerate(first_block_paths[:nconfs], start=1):
            if built >= target_unique:
                break
            passed = False
            for attempt in range(max_attempts_per_fragment):
                candidate_dir = os.path.join(path_build, f"nterm_{source_idx}")
                clear_dir(candidate_dir)

                run_build(
                    seq=nidr_seq,
                    rs=(source_idx * 100000) + attempt,
                    nc=1,
                    n=ncores,
                    outdir=candidate_dir,
                    use_long=nidr_is_long,
                )

                candidates = sorted_pdbs(candidate_dir)
                if not candidates:
                    continue

                aligned_idr_arr, target_arr = align_idr_to_target(
                    candidates[0],
                    target,
                    case="N-IDR",
                    max_clash=120 if SPEED_FIRST_REUSE_MODE else 80,
                    tolerance=0.7 if SPEED_FIRST_REUSE_MODE else 0.4,
                )
                if aligned_idr_arr is None:
                    continue

                stitched = stitch_prepend_nidr(aligned_idr_arr, target_arr)
                built += 1
                save_structure_array(
                    stitched,
                    os.path.join(path_current, f"conformer_{built}.pdb"),
                )
                passed = True
                break

            if not passed:
                failures += 1
                print(f"    WARNING: N-IDR seed source {source_idx} failed; trying another block conformer.")

        if built < min_terminal_unique_required:
            raise RuntimeError(
                f"Failed to build minimum N-IDR seeds: built={built}, "
                f"minimum={min_terminal_unique_required}, failures={failures}."
            )
        if built < target_unique:
            print(
                f"    Partial N-IDR library accepted: {built}/{target_unique} unique seed(s); "
                f"cyclic reuse will fill {nconfs} outputs."
            )

        if SPEED_FIRST_REUSE_MODE and built < nconfs:
            expand_folder_cyclically_to_nconfs(path_current, prefix="conformer")


def extend_with_linker_and_block(
    current_fragments: Sequence[str],
    linker_seq: str,
    linker_is_long: bool,
    next_block_paths: Sequence[str],
    path_build: str,
    path_work: str,
    path_next: str,
    ) -> None:
        """Append LINKER-IDR plus the next prebuilt interaction block.

        In finish-if-doable mode, the unique-linker target is a diversity goal.  If
        some source fragments fail, the function keeps trying other source fragments
        and cyclically reuses any successful LINKER+block assemblies.
        """
        clear_dir(path_next)
        clear_dir(path_work)

        target_unique = nconfs
        if SPEED_FIRST_REUSE_MODE:
            target_unique = min(nconfs, max(1, int(fast_linker_unique_target)))
            print(f"  SPEED-FIRST: building up to {target_unique} unique LINKER+block extension(s), then cyclic reuse.")

        built = 0
        failures = 0
        for source_idx, frag in enumerate(current_fragments[:nconfs], start=1):
            if built >= target_unique:
                break
            next_block = next_block_paths[(source_idx - 1) % len(next_block_paths)]
            passed = False

            for attempt in range(max_attempts_per_fragment):
                candidate_dir = os.path.join(path_build, f"linker_{source_idx}")
                clear_dir(candidate_dir)

                run_build(
                    seq=linker_seq,
                    rs=(source_idx * 100000) + attempt,
                    nc=1,
                    n=ncores,
                    outdir=candidate_dir,
                    use_long=linker_is_long,
                )

                candidates = sorted_pdbs(candidate_dir)
                if not candidates:
                    continue

                aligned_linker_arr, frag_arr = align_idr_to_target(
                    candidates[0],
                    frag,
                    case="C-IDR",
                    max_clash=120 if SPEED_FIRST_REUSE_MODE else 80,
                    tolerance=0.7 if SPEED_FIRST_REUSE_MODE else 0.4,
                )
                if aligned_linker_arr is None:
                    continue

                frag_plus_linker = stitch_append_idr(frag_arr, aligned_linker_arr)
                frag_plus_linker_path = os.path.join(path_work, f"frag_plus_linker_{source_idx}.pdb")
                save_structure_array(frag_plus_linker, frag_plus_linker_path)

                aligned_block_arr, linked_arr = align_fragment_to_target(
                    next_block,
                    frag_plus_linker_path,
                    max_clash=180 if SPEED_FIRST_REUSE_MODE else 120,
                    tolerance=0.7 if SPEED_FIRST_REUSE_MODE else 0.4,
                )
                if aligned_block_arr is None:
                    continue

                extended = stitch_append_fragment(linked_arr, aligned_block_arr)
                built += 1
                save_structure_array(
                    extended,
                    os.path.join(path_next, f"conformer_{built}.pdb"),
                )
                passed = True
                break

            if not passed:
                failures += 1
                print(f"    WARNING: LINKER source conformer {source_idx} failed; trying another source conformer.")

        if built < min_linker_unique_required:
            raise RuntimeError(
                f"Failed to build minimum LINKER+block extensions: built={built}, "
                f"minimum={min_linker_unique_required}, failures={failures}."
            )
        if built < target_unique:
            print(
                f"    Partial LINKER library accepted: {built}/{target_unique} unique extension(s); "
                f"cyclic reuse will fill {nconfs} outputs."
            )

        if SPEED_FIRST_REUSE_MODE and built < nconfs:
            expand_folder_cyclically_to_nconfs(path_next, prefix="conformer")


def append_cterm_idr(
    current_fragments: Sequence[str],
    cidr_seq: str,
    cidr_is_long: bool,
    path_build: str,
    path_next: str,
    ) -> None:
        clear_dir(path_next)

        target_unique = nconfs
        if SPEED_FIRST_REUSE_MODE:
            target_unique = min(nconfs, max(1, int(fast_terminal_unique_target)))
            print(f"  SPEED-FIRST: building up to {target_unique} unique C-IDR append(s), then cyclic reuse.")

        built = 0
        failures = 0
        for source_idx, frag in enumerate(current_fragments[:nconfs], start=1):
            if built >= target_unique:
                break
            passed = False

            for attempt in range(max_attempts_per_fragment):
                candidate_dir = os.path.join(path_build, f"cterm_{source_idx}")
                clear_dir(candidate_dir)

                run_build(
                    seq=cidr_seq,
                    rs=(source_idx * 100000) + attempt,
                    nc=1,
                    n=ncores,
                    outdir=candidate_dir,
                    use_long=cidr_is_long,
                )

                candidates = sorted_pdbs(candidate_dir)
                if not candidates:
                    continue

                aligned_cidr_arr, frag_arr = align_idr_to_target(
                    candidates[0],
                    frag,
                    case="C-IDR",
                    max_clash=120 if SPEED_FIRST_REUSE_MODE else 80,
                    tolerance=0.7 if SPEED_FIRST_REUSE_MODE else 0.4,
                )
                if aligned_cidr_arr is None:
                    continue

                appended = stitch_append_idr(frag_arr, aligned_cidr_arr)
                built += 1
                save_structure_array(
                    appended,
                    os.path.join(path_next, f"conformer_{built}.pdb"),
                )
                passed = True
                break

            if not passed:
                failures += 1
                print(f"    WARNING: C-IDR source conformer {source_idx} failed; trying another source conformer.")

        if built < min_terminal_unique_required:
            raise RuntimeError(
                f"Failed to build minimum C-IDR appends: built={built}, "
                f"minimum={min_terminal_unique_required}, failures={failures}."
            )
        if built < target_unique:
            print(
                f"    Partial C-IDR library accepted: {built}/{target_unique} unique append(s); "
                f"cyclic reuse will fill {nconfs} outputs."
            )

        if SPEED_FIRST_REUSE_MODE and built < nconfs:
            expand_folder_cyclically_to_nconfs(path_next, prefix="conformer")


def swap_stage_dirs(path_from: str, path_to: str) -> None:
    clear_dir(path_to)
    for pdb in sorted_pdbs(path_from):
        shutil.move(pdb, os.path.join(path_to, os.path.basename(pdb)))
    clear_dir(path_from)


# =============================================================================
# Main per-protein driver
# =============================================================================

def get_sequence_for_id(uniprot_id: str, struc: Structure, sequence_db: dict) -> str:
    if uniprot_id in sequence_db:
        return str(sequence_db[uniprot_id])
    return str(next(iter(struc.fasta.values())))


def warn_non_adjacent_interactions(uniprot_id: str, interactions: Sequence[Sequence[str]]) -> None:
    non_adjacent = []
    for pair in interactions:
        if len(pair) != 2:
            continue
        a, b = pair
        try:
            ia = int(str(a).replace("F", ""))
            ib = int(str(b).replace("F", ""))
        except ValueError:
            continue
        if abs(ia - ib) > 1:
            non_adjacent.append((a, b))
    if non_adjacent:
        print(
            f"  Note: {uniprot_id} has non-adjacent folded-domain interactions "
            f"{non_adjacent}; these are not used as single LOOP-IDR closures."
        )


def process_one_id(
    uniprot_id: str,
    master_db: dict,
    max_residues: dict,
    sequence_db: dict,
    ) -> None:
        path_final_ens = os.path.join(output_directory, uniprot_id)
        path_templates = os.path.join(path_final_ens, "temp_templates")
        path_blocks = os.path.join(path_final_ens, "temp_blocks")
        path_loops = os.path.join(path_final_ens, "temp_loops")
        path_build = os.path.join(path_final_ens, "temp_build")
        path_work = os.path.join(path_final_ens, "temp_work")
        path_current = os.path.join(path_final_ens, "temp_current")
        path_next = os.path.join(path_final_ens, "temp_next")
    
        if SKIP_ALREADY_FINISHED and output_ensemble_exists(path_final_ens, uniprot_id):
            print(f"Skipping {uniprot_id}: existing final ensemble found.")
            return
    
        ensure_dir(path_final_ens)
        for folder in (
            path_templates,
            path_blocks,
            path_loops,
            path_build,
            path_work,
            path_current,
            path_next,
        ):
            clear_dir(folder)
        remove_matching_files(path_final_ens, ["conformer*.pdb", "*_idpcg_n*.pdb", "energies.log"])
    
        pdb_path = find_template_path(uniprot_id)
        struc = Structure(IDPPath(pdb_path))
        struc.build()
        struc_arr = np.array(struc.data_array, copy=True)
        sequence = get_sequence_for_id(uniprot_id, struc, sequence_db)
    
        details_all = normalize_ranges(master_db[uniprot_id]["idrs"])
        num_res = int(max_residues.get(uniprot_id, len(sequence)))
        interactions = master_db[uniprot_id].get("interactions", [])
        mean_pae = master_db[uniprot_id].get("mean_pae", {})
    
        if len(sequence) < num_res:
            raise ValueError(
                f"{uniprot_id}: sequence length ({len(sequence)}) is shorter than num_res ({num_res})."
            )
    
        domains = find_fld_domains(details_all, num_res)
        n_term, internal_segments, c_term = classify_segments(
            details_all,
            domains,
            num_res,
            interactions,
            mean_pae,
        )
    
        if not any(seg.kind == "LOOP" for seg in internal_segments):
            print(
                f"No LOOP-IDR after classification for {uniprot_id}; "
                f"treating as terminal/linker fallback case "
                f"({describe_topology(n_term, internal_segments, c_term)})."
            )
    
        blocks, linkers = build_domain_blocks(internal_segments, len(domains))
        if len(linkers) != max(0, len(blocks) - 1):
            raise RuntimeError(
                f"{uniprot_id}: expected {len(blocks) - 1} linkers between blocks, found {len(linkers)}."
            )
    
        print(f"\n=== {uniprot_id} ===")
        print(f"  Topology: {describe_topology(n_term, internal_segments, c_term)}")
        print(f"  Folded domains: {domains}")
        print(f"  Blocks: {[tuple(i + 1 for i in b.domain_indices) for b in blocks]}")
        warn_non_adjacent_interactions(uniprot_id, interactions)
    
        # Build each rigid loop-containing block first.
        block_conformers: List[List[str]] = []
        for block in blocks:
            block_base = make_block_base_template(
                uniprot_id,
                struc_arr,
                domains,
                block,
                path_templates,
            )
            block_dir = os.path.join(path_blocks, f"block{block.block_idx + 1}")
            loop_root = os.path.join(path_loops, f"block{block.block_idx + 1}")
            paths = build_block_ensemble(
                uniprot_id=uniprot_id,
                sequence=sequence,
                block=block,
                base_template_pdb=block_base,
                path_block_dir=block_dir,
                path_loop_root=loop_root,
                full_template_arr=struc_arr,
            )
            if len(paths) != nconfs:
                raise RuntimeError(
                    f"{uniprot_id}: block {block.block_idx + 1} produced {len(paths)} conformers."
                )
            block_conformers.append(paths)
    
        # Seed with first block, optionally prepending N-IDR.
        if n_term is not None:
            nidr_seq = build_range_seq(sequence, n_term.start, n_term.end, "N")
            seed_with_nidr(
                first_block_paths=block_conformers[0],
                nidr_seq=nidr_seq,
                nidr_is_long=is_long_idr(n_term.start, n_term.end),
                path_build=path_build,
                path_current=path_current,
            )
        else:
            seed_without_nidr(block_conformers[0], path_current)
    
        current_fragments = sorted_pdbs(path_current)
        if len(current_fragments) != nconfs:
            raise RuntimeError(
                f"{uniprot_id}: seed stage produced {len(current_fragments)} conformers."
            )
    
        # Connect subsequent blocks with LINKER-IDRs.
        for block_idx, linker in enumerate(linkers, start=1):
            linker_seq = build_range_seq(sequence, linker.start, linker.end, "LINKER")
            extend_with_linker_and_block(
                current_fragments=sorted_pdbs(path_current),
                linker_seq=linker_seq,
                linker_is_long=is_long_idr(linker.start, linker.end),
                next_block_paths=block_conformers[block_idx],
                path_build=path_build,
                path_work=path_work,
                path_next=path_next,
            )
            swap_stage_dirs(path_next, path_current)
    
        # Optionally append C-IDR.
        if c_term is not None:
            cidr_seq = build_range_seq(sequence, c_term.start, c_term.end, "C")
            append_cterm_idr(
                current_fragments=sorted_pdbs(path_current),
                cidr_seq=cidr_seq,
                cidr_is_long=is_long_idr(c_term.start, c_term.end),
                path_build=path_build,
                path_next=path_next,
            )
            swap_stage_dirs(path_next, path_current)
    
        final_stage = sorted_pdbs(path_current)
        if len(final_stage) != nconfs:
            raise RuntimeError(
                f"{uniprot_id}: final assembly produced {len(final_stage)} conformers."
            )
    
        remove_matching_files(path_final_ens, ["conformer*.pdb"])
        for idx, src in enumerate(final_stage, start=1):
            shutil.move(src, os.path.join(path_final_ens, f"conformer_{idx}.pdb"))
    
        postprocess_ensemble(path_final_ens, uniprot_id)
        remove_matching_files(path_final_ens, ["temp*", "energies.log"])
        print(f"Finished: {uniprot_id}.")


def main() -> None:
    ensure_dir(output_directory)
    ensure_dir(os.path.dirname(error_file))

    ids_path = resolve_ids_file(hard_ids_fallbacks)
    print(f"Using hard IDs file: {ids_path}")

    master_db = load_json(master_db_file)
    max_residues = load_json(max_residues_file)
    sequence_db = load_json(sequences_file, required=False)
    hard_ids = load_ids(ids_path)

    for uniprot_id in hard_ids:
        try:
            if uniprot_id not in master_db:
                raise KeyError(f"{uniprot_id} not found in master database.")
            process_one_id(uniprot_id, master_db, max_residues, sequence_db)
        except Exception as exc:
            print(f"ERROR for {uniprot_id}: {exc}")
            with open(error_file, "a") as logf:
                logf.write(f"{uniprot_id}: {exc}\n")
                logf.write(traceback.format_exc())
                logf.write("\n\n")
            continue


if __name__ == "__main__":
    main()
