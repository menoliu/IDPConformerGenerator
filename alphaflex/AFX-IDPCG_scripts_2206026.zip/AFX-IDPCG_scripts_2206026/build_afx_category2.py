'''
Main builder function for generalized category 2 (beads-on-a-string) cases.

Supported patterns include for example:
    N-L-C
    N-L-L-C
    N-L-L-L-C
    N-L-L
    L-L-C
    L-L
    L-C
    N-L

Topology assumption
-------------------
The target must have the form:
    [N?] D0 L1 D1 L2 D2 ... Lk Dk [C?]
where:
    * D are folded domains (treated as rigid beads)
    * L are internal linker IDRs
    * N and C are optional terminal IDRs
    * there is at least one linker (k >= 1)

Requirements
------------
* IDPConformerGenerator >= 0.7.27
* OpenMM >= 8.2
* pdb-tools >= 2.5
* PDBFixer >= 1.9
'''
import re
import sys
import json
import os
import shutil
import subprocess
import random

import numpy as np

from glob import glob
from pathlib import Path as StdPath
from pdbfixer import PDBFixer

from openmm.app import (
    PDBFile,
    ForceField,
    Simulation,
    HBonds,
    NoCutoff,
)
from openmm import LangevinIntegrator, CustomExternalForce
from openmm.unit import (
    angstrom,
    kilocalories_per_mole,
    kelvin,
    picosecond,
    picoseconds,
)

from idpconfgen import Path
from idpconfgen.libs.libstructure import (
    Structure,
    col_resSeq,
    col_resName,
    col_name,
    cols_coords,
    col_chainID,
    col_segid,
    col_serial,
    structure_to_pdb,
    write_PDB,
    parse_pdb_to_array,
)
from idpconfgen.ldrs_helper import (
    align_coords,
    count_clashes,
)
from idpconfgen.libs.libmulticore import pool_function


# =============================================================================
# User-editable parameters
# =============================================================================

set_num = int(re.search(r'\d+', sys.argv[0]).group())
nconfs = 100
ncores = 50
# Keep IDPCG/alignment parallel, but keep PDBFixer/OpenMM postprocessing
# memory-safe on 96 GB nodes.
fix_ncores = 10
cc_ncores = 2
long_idr_threshold = 150
max_attempts_per_fragment = 1000
build_batch_size = max(nconfs * 5, ncores)
seed_no_solution_batch_limit = 10
seed_no_progress_batch_limit = 20
progress_report_every = 5
stage_no_solution_batch_limit = 8
stage_no_progress_batch_limit = 20

output_directory = f"../AFX-IDPCG_Category_2_ensembles/cat2_ens{set_num}"
medium_ids_file = f"../databases/category_2_ids/cat2_{set_num}.txt"
idpcg_database = "../databases/idpconfgen_database_2024.json"
master_db_file = "../databases/AlphaFlex_database_July2024_v2.json"
max_residues_file = "../databases/AF2_9606_HUMAN_v4_num_residues.json"
af2_pdbs = glob("../databases/AF2_9606_PAE_PDB/*.pdb")

BACKBONE_ATOMS = {"N", "CA", "C", "O"}


class ProgressStalledError(RuntimeError):
    """Raised when sampling/build attempts stall with no useful progress."""
    def __init__(self, stage: str, details: str):
        self.stage = stage
        self.details = details
        super().__init__(f"[{stage}] {details}")


# =============================================================================
# Shell / I/O utilities
# =============================================================================

def run_command(
    cmd: list,
    *,
    quiet: bool = True,
    stdout_file=None,
    ) -> subprocess.CompletedProcess:
        """Run a command list (shell=False) and raise a helpful error on failure.

        When ``quiet`` is True, stdout is discarded rather than buffered in memory;
        only stderr is captured for error reporting.  Pass ``stdout_file`` (a path
        or file-like object) to redirect stdout to a file instead of discarding it
        (used for pdb_mkensemble).
        """
        if stdout_file is not None:
            # Accept both a path string/Path and an already-opened file object.
            if isinstance(stdout_file, (str, StdPath)):
                with open(stdout_file, "w") as outf:
                    result = subprocess.run(
                        cmd, stdout=outf, stderr=subprocess.PIPE, text=True
                    )
            else:
                result = subprocess.run(
                    cmd, stdout=stdout_file, stderr=subprocess.PIPE, text=True
                )
        elif quiet:
            result = subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
            )
        else:
            result = subprocess.run(cmd, text=True)

        if result.returncode != 0:
            msg = "Command failed:\n" + " ".join(str(c) for c in cmd)
            if quiet or stdout_file is not None:
                stderr = (getattr(result, "stderr", None) or "").strip()
                if stderr:
                    msg += f"\n\nSTDERR:\n{stderr}"
            raise RuntimeError(msg)
        return result


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)


def clear_dir(path):
    ensure_dir(path)
    for entry in os.listdir(path):
        full = os.path.join(path, entry)
        if os.path.isdir(full):
            shutil.rmtree(full)
        else:
            os.remove(full)


def remove_matching_files(folder, patterns):
    for pattern in patterns:
        for path in glob(os.path.join(folder, pattern)):
            if os.path.isdir(path):
                shutil.rmtree(path)
            elif os.path.exists(path):
                os.remove(path)


def sorted_pdbs(folder):
    return sorted(glob(os.path.join(folder, "*.pdb")))


def mark_build_problem(path_final_ens, uniprot_id, message):
    marker_path = os.path.join(path_final_ens, f"BUILD_PROBLEM_{uniprot_id}.txt")
    with open(marker_path, "w") as handle:
        handle.write(message.rstrip() + "\n")


def find_template_path(uniprot_id):
    exact = []
    fuzzy = []
    for p in af2_pdbs:
        name = os.path.basename(p)
        if uniprot_id not in name:
            continue
        if name.startswith(f"AF-{uniprot_id}-"):
            exact.append(p)
        else:
            fuzzy.append(p)
    candidates = exact or fuzzy
    if not candidates:
        raise FileNotFoundError(f"Could not find AF2 template PDB for {uniprot_id}.")
    return sorted(candidates)[0]


# =============================================================================
# Structure utilities
# =============================================================================

def resolve_clash(pdb_file):
    """
    Resolve clashes by minimizing while keeping the protein backbone restrained.
    """
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))

    pdb = PDBFile(pdb_file)
    forcefield = ForceField("amber99sb.xml")

    system = forcefield.createSystem(
        pdb.topology, constraints=HBonds, nonbondedMethod=NoCutoff
    )

    # Use a set for O(1) membership tests instead of a list.
    sidechain_atoms = {
        atom.index
        for atom in pdb.topology.atoms()
        if atom.name not in BACKBONE_ATOMS
    }

    k = 10.0 * kilocalories_per_mole / angstrom**2
    constraint_force = CustomExternalForce(
        "0.5 * k * ((x - x0)^2 + (y - y0)^2 + (z - z0)^2)"
    )
    constraint_force.addPerParticleParameter("x0")
    constraint_force.addPerParticleParameter("y0")
    constraint_force.addPerParticleParameter("z0")
    constraint_force.addGlobalParameter("k", k)

    for atom in pdb.topology.atoms():
        if atom.index not in sidechain_atoms:
            position = pdb.positions[atom.index]
            constraint_force.addParticle(atom.index, [position.x, position.y, position.z])

    system.addForce(constraint_force)

    integrator = LangevinIntegrator(300 * kelvin, 1 / picosecond, 0.002 * picoseconds)  # type: ignore
    simulation = Simulation(pdb.topology, system, integrator)
    simulation.context.setPositions(pdb.positions)
    simulation.minimizeEnergy(maxIterations=1000)

    positions = simulation.context.getState(getPositions=True).getPositions()
    with open(f"{folder}/{name}_cr.pdb", "w") as f:
        PDBFile.writeFile(simulation.topology, positions, f)

    os.remove(pdb_file)


def add_hydrogens(pdb_file, pH=7.4):
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))

    fixer = PDBFixer(filename=pdb_file)
    fixer.findMissingResidues()
    fixer.findMissingAtoms()
    fixer.addMissingHydrogens(pH=pH)

    with open(f"{folder}/{name}_pro.pdb", "w") as handle:
        PDBFile.writeFile(fixer.topology, fixer.positions, handle)

    os.remove(pdb_file)


def find_fld_domains(idrs, max_res):
    domains = []

    if idrs[0][0] > 1:
        domains.append([1, idrs[0][0] - 1])

    for i in range(len(idrs) - 1):
        domains.append([idrs[i][1] + 1, idrs[i + 1][0] - 1])

    if idrs[-1][1] < max_res:
        domains.append([idrs[-1][1] + 1, max_res])

    return domains


def first_resseq(arr):
    return int(arr[0][col_resSeq])


def last_resseq(arr):
    return int(arr[-1][col_resSeq])


def remove_first_residue(arr):
    arr = np.array(arr, copy=True)
    first = first_resseq(arr)
    idx = 0
    while idx < len(arr) and int(arr[idx][col_resSeq]) == first:
        idx += 1
    return arr[idx:]


def remove_last_residue(arr):
    arr = np.array(arr, copy=True)
    last = last_resseq(arr)
    idx = len(arr)
    while idx > 0 and int(arr[idx - 1][col_resSeq]) == last:
        idx -= 1
    return arr[:idx]


def normalize_structure_array(arr):
    arr = np.array(arr, copy=True)
    new_serial = [str(i) for i in range(1, len(arr) + 1)]
    arr[:, col_serial] = new_serial
    arr[:, col_segid] = ""
    # Vectorized HIP → HIS replacement.
    mask = arr[:, col_resName] == "HIP"
    arr[mask, col_resName] = "HIS"
    return arr


def load_structure(pdb_path):
    struc = Structure(Path(pdb_path))
    struc.build()
    arr = np.array(struc.data_array, copy=True)
    return struc, arr


def save_structure_array(arr, outpath):
    out = structure_to_pdb(normalize_structure_array(arr))
    write_PDB(out, outpath)


# =============================================================================
# Anchor coordinate extraction
# =============================================================================

def get_nterm_anchor_coords(target_arr):
    target_name = target_arr[:, col_name]
    target_seq = target_arr[:, col_resSeq].astype(int)
    first_seq = target_seq[0]

    idx = {}
    for j, atom in enumerate(target_name):
        curr_seq = target_seq[j]
        if curr_seq == first_seq + 1 and atom == "N":
            idx["N"] = j
        elif curr_seq == first_seq + 1 and atom == "CA":
            idx["CA"] = j
        elif curr_seq == first_seq and atom == "C":
            idx["C"] = j
        elif curr_seq == first_seq + 2:
            break

    if set(idx) != {"C", "N", "CA"}:
        raise ValueError("Could not determine N-terminal anchor coordinates.")

    return np.array(
        [
            target_arr[idx["C"]][cols_coords].astype(float),
            target_arr[idx["N"]][cols_coords].astype(float),
            target_arr[idx["CA"]][cols_coords].astype(float),
        ]
    )


def get_cterm_anchor_coords(target_arr):
    target_name = target_arr[:, col_name]
    target_seq = target_arr[:, col_resSeq].astype(int)
    last_seq = target_seq[-1]

    idx = {}
    for j, _atom in enumerate(target_name):
        k = len(target_name) - 1 - j
        curr_seq = target_seq[k]
        if curr_seq == last_seq and target_name[k] == "N":
            idx["N"] = k
        elif curr_seq == last_seq and target_name[k] == "CA":
            idx["CA"] = k
        elif curr_seq == last_seq - 1 and target_name[k] == "C":
            idx["C"] = k
        elif curr_seq == last_seq - 2:
            break

    if set(idx) != {"C", "N", "CA"}:
        raise ValueError("Could not determine C-terminal anchor coordinates.")

    return np.array(
        [
            target_arr[idx["C"]][cols_coords].astype(float),
            target_arr[idx["N"]][cols_coords].astype(float),
            target_arr[idx["CA"]][cols_coords].astype(float),
        ]
    )


# =============================================================================
# Candidate handling
# =============================================================================

def parse_candidate_array(candidate_pdb):
    with open(candidate_pdb) as handle:
        pdb_data = handle.read()
    try:
        return np.array(parse_pdb_to_array(pdb_data), copy=True)
    except AssertionError:
        return None


def build_range_seq(sequence, start, end, kind):
    if kind == "N":
        return sequence[: end + 2]
    if kind == "C":
        return sequence[start - 3 :]
    return sequence[start - 3 : end + 2]


def is_long_idr(start, end):
    return (end - start + 1) >= long_idr_threshold


def run_build(seq, rs, nc, n, outdir, use_long=False):
    cmd = [
        "idpconfgen",
        "build",
        "-seq",
        seq,
        "-db",
        idpcg_database,
        "--dloop-off",
        "--dany",
        "-rs",
        str(rs),
        "-nc",
        str(nc),
        "-n",
        str(n),
        "-of",
        outdir,
    ]
    if use_long:
        cmd.extend(["--long", "--force-long"])
    return run_command(cmd)


# =============================================================================
# Alignment / clash checking
# =============================================================================

def align_idr_to_target(candidate_pdb, target_pdb, case, max_clash=80, tolerance=0.4):
    target_struc, target_arr = load_structure(target_pdb)
    candidate_arr = parse_candidate_array(candidate_pdb)
    if candidate_arr is None:
        return None, target_arr

    if case == "N-IDR":
        target_coords = get_nterm_anchor_coords(target_arr)
    elif case == "C-IDR":
        target_coords = get_cterm_anchor_coords(target_arr)
    else:
        raise ValueError(f"Unsupported case: {case}")

    aligned_candidate = align_coords(candidate_arr, target_coords, case)
    clashes, fragment = count_clashes(
        aligned_candidate,
        target_struc,
        case,
        max_clash=max_clash,
        tolerance=tolerance,
    )
    if type(clashes) is int:
        return np.array(fragment, copy=True), target_arr
    return None, target_arr


def align_domain_to_target(next_domain_pdb, target_pdb, max_clash=100, tolerance=0.4):
    target_struc, target_arr = load_structure(target_pdb)
    domain_arr = parse_candidate_array(next_domain_pdb)
    if domain_arr is None:
        return None, target_arr

    target_coords = get_cterm_anchor_coords(target_arr)
    aligned_domain = align_coords(domain_arr, target_coords, "C-IDR")
    clashes, fragment = count_clashes(
        aligned_domain,
        target_struc,
        "C-IDR",
        max_clash=max_clash,
        tolerance=tolerance,
    )
    if type(clashes) is int:
        return np.array(fragment, copy=True), target_arr
    return None, target_arr


def seed_candidate_task(task):
    candidate_pdb, domain0_path = task
    aligned_idr_arr, domain_arr = align_idr_to_target(
        candidate_pdb,
        domain0_path,
        case="N-IDR",
        max_clash=80,
        tolerance=0.4,
    )
    if aligned_idr_arr is None:
        return None
    return stitch_prepend_nidr(aligned_idr_arr, domain_arr)


# =============================================================================
# Stitching
# =============================================================================

def stitch_prepend_nidr(aligned_idr_arr, target_arr):
    aligned_idr_arr = np.array(aligned_idr_arr, copy=True)
    target_arr = np.array(target_arr, copy=True)
    chain = target_arr[:, col_chainID][0]
    # Vectorized chain ID assignment.
    aligned_idr_arr[:, col_chainID] = chain

    stitched_idr = remove_last_residue(aligned_idr_arr)
    stitched_target = remove_first_residue(target_arr)
    return normalize_structure_array(
        np.array(stitched_idr.tolist() + stitched_target.tolist())
    )


def stitch_append_idr(target_arr, aligned_idr_arr):
    target_arr = np.array(target_arr, copy=True)
    aligned_idr_arr = np.array(aligned_idr_arr, copy=True)
    chain = target_arr[:, col_chainID][0]
    # Vectorized chain ID assignment.
    aligned_idr_arr[:, col_chainID] = chain

    last_seq_target = last_resseq(target_arr)
    stitched_target = remove_last_residue(target_arr)
    stitched_idr = remove_first_residue(aligned_idr_arr)

    # Vectorized resSeq renumbering (replaces per-row Python loop).
    stitched_idr[:, col_resSeq] = (
        stitched_idr[:, col_resSeq].astype(int) + (last_seq_target - 2)
    ).astype(str)

    return normalize_structure_array(
        np.array(stitched_target.tolist() + stitched_idr.tolist())
    )


def stitch_append_domain(target_arr, aligned_domain_arr):
    target_arr = np.array(target_arr, copy=True)
    aligned_domain_arr = np.array(aligned_domain_arr, copy=True)
    chain = target_arr[:, col_chainID][0]
    # Vectorized chain ID assignment.
    aligned_domain_arr[:, col_chainID] = chain

    stitched_target = remove_last_residue(target_arr)
    stitched_domain = remove_first_residue(aligned_domain_arr)
    return normalize_structure_array(
        np.array(stitched_target.tolist() + stitched_domain.tolist())
    )


# =============================================================================
# Template extraction
# =============================================================================

def make_domain_templates(uniprot_id, struc_arr, fld_domains, path_templates):
    """Extract each folded domain from struc_arr using numpy boolean masking."""
    domain_paths = []
    fld_res = struc_arr[:, col_resSeq].astype(int)

    for i, (start, end) in enumerate(fld_domains):
        mask = (fld_res >= start) & (fld_res <= end)
        subdomain_arr = struc_arr[mask]
        if len(subdomain_arr) == 0:
            raise ValueError(
                f"{uniprot_id}: empty folded domain extracted for range [{start}, {end}]."
            )
        subdomain_struc = structure_to_pdb(subdomain_arr)
        domain_path = os.path.join(path_templates, f"{uniprot_id}_d{i}.pdb")
        write_PDB(subdomain_struc, domain_path)
        domain_paths.append(domain_path)

    return domain_paths


# =============================================================================
# Assembly stages
# =============================================================================

def seed_with_nidr(domain0_path, nidr_seq, nidr_is_long, path_build, path_current):
    """Build nconfs N-IDR + D0 starting conformers.

    Each accepted conformer uses a different N-IDR candidate (sampled from
    successive idpconfgen build batches), so all nconfs starting structures
    carry a unique N-IDR fragment.
    """
    clear_dir(path_current)
    rs = 0
    built = 0
    batches = 0
    no_progress_batches = 0

    while built < nconfs:
        clear_dir(path_build)
        run_build(
            seq=nidr_seq,
            rs=rs,
            nc=build_batch_size,
            n=ncores,
            outdir=path_build,
            use_long=nidr_is_long,
        )
        candidates = sorted_pdbs(path_build)
        tasks = [(candidate, domain0_path) for candidate in candidates]
        pool = pool_function(seed_candidate_task, tasks, ncores=ncores)
        accepted = [arr for arr in pool if arr is not None]

        if not accepted:
            no_progress_batches += 1
        else:
            no_progress_batches = 0
            for stitched in accepted:
                built += 1
                save_structure_array(
                    stitched,
                    os.path.join(path_current, f"conformer_{built}.pdb"),
                )
                if built == nconfs:
                    break

        batches += 1
        if batches % progress_report_every == 0:
            print(f"  N-seed progress: {built}/{nconfs} after {batches} batches")

        if batches >= seed_no_solution_batch_limit and built == 0:
            raise ProgressStalledError(
                stage="seed_with_nidr",
                details=(
                    f"No passing N-IDR candidates found after {seed_no_solution_batch_limit} batches."
                ),
            )

        if no_progress_batches >= seed_no_progress_batch_limit and built < nconfs:
            raise ProgressStalledError(
                stage="seed_with_nidr",
                details=(
                    f"No additional N-IDR seed conformers found in the last "
                    f"{seed_no_progress_batch_limit} batches (current={built}/{nconfs})."
                ),
            )

        rs += build_batch_size


def seed_without_nidr(domain0_path, path_current):
    clear_dir(path_current)
    for idx in range(1, nconfs + 1):
        shutil.copy2(domain0_path, os.path.join(path_current, f"conformer_{idx}.pdb"))


def extend_with_linker_and_domain(
    current_fragments,
    linker_seq,
    linker_is_long,
    next_domain_path,
    path_build,
    path_work,
    path_next,
    ):  
        """Extend each current fragment with a linker + next domain using shared candidate batches."""
        clear_dir(path_next)
        clear_dir(path_work)
        ensure_dir(path_build)

        pending = {idx: frag for idx, frag in enumerate(current_fragments[:nconfs], start=1)}
        batch_idx = 0
        rs = 0
        no_progress_batches = 0

        while pending:
            candidate_dir = os.path.join(path_build, f"linker_batch_{batch_idx:04d}")
            clear_dir(candidate_dir)

            run_build(
                seq=linker_seq,
                rs=rs,
                nc=build_batch_size,
                n=ncores,
                outdir=candidate_dir,
                use_long=linker_is_long,
            )

            candidates = sorted_pdbs(candidate_dir)
            random.shuffle(candidates)
            used_candidates = set()
            made_progress = 0

            for frag_idx in list(pending.keys()):
                frag = pending[frag_idx]
                # Fresh random order per fragment reduces systematic failure modes.
                trial_candidates = candidates[:]
                random.shuffle(trial_candidates)

                for candidate in trial_candidates:
                    if candidate in used_candidates:
                        continue

                    aligned_linker_arr, frag_arr = align_idr_to_target(
                        candidate,
                        frag,
                        case="C-IDR",
                        max_clash=80,
                        tolerance=0.4,
                    )
                    if aligned_linker_arr is None:
                        continue

                    frag_plus_linker = stitch_append_idr(frag_arr, aligned_linker_arr)
                    frag_plus_linker_path = os.path.join(path_work, f"frag_plus_linker_{frag_idx}.pdb")
                    save_structure_array(frag_plus_linker, frag_plus_linker_path)

                    aligned_domain_arr, linked_arr = align_domain_to_target(
                        next_domain_path,
                        frag_plus_linker_path,
                        max_clash=100,
                        tolerance=0.4,
                    )
                    if aligned_domain_arr is None:
                        continue

                    extended = stitch_append_domain(linked_arr, aligned_domain_arr)
                    save_structure_array(
                        extended,
                        os.path.join(path_next, f"conformer_{frag_idx}.pdb"),
                    )
                    used_candidates.add(candidate)
                    del pending[frag_idx]
                    made_progress += 1
                    break

            batch_idx += 1
            rs += build_batch_size + 17

            if made_progress == 0:
                no_progress_batches += 1
            else:
                no_progress_batches = 0

            print(
                f"  Linker stage progress: {nconfs - len(pending)}/{nconfs} "
                f"after {batch_idx} batches; this_batch={made_progress}; "
                f"pending={len(pending)}"
            )

            if batch_idx >= stage_no_solution_batch_limit and len(pending) == nconfs:
                raise ProgressStalledError(
                    stage="extend_with_linker_and_domain",
                    details=(
                        f"No fragments extended after {stage_no_solution_batch_limit} "
                        f"shared batches of {build_batch_size} linker candidates."
                    ),
                )

            if no_progress_batches >= stage_no_progress_batch_limit and pending:
                preview = ", ".join(str(x) for x in sorted(pending)[:10])
                raise ProgressStalledError(
                    stage="extend_with_linker_and_domain",
                    details=(
                        f"No additional fragments extended in the last "
                        f"{stage_no_progress_batch_limit} batches. "
                        f"Remaining examples: {preview}"
                    ),
                )


def append_cterm_idr(current_fragments, cidr_seq, cidr_is_long, path_build, path_next):
    """Append C-terminal IDRs using shared candidate batches."""
    clear_dir(path_next)
    ensure_dir(path_build)

    pending = {idx: frag for idx, frag in enumerate(current_fragments[:nconfs], start=1)}
    batch_idx = 0
    rs = 0
    no_progress_batches = 0

    while pending:
        candidate_dir = os.path.join(path_build, f"cterm_batch_{batch_idx:04d}")
        clear_dir(candidate_dir)

        run_build(
            seq=cidr_seq,
            rs=rs,
            nc=build_batch_size,
            n=ncores,
            outdir=candidate_dir,
            use_long=cidr_is_long,
        )

        candidates = sorted_pdbs(candidate_dir)
        random.shuffle(candidates)
        used_candidates = set()
        made_progress = 0

        for frag_idx in list(pending.keys()):
            frag = pending[frag_idx]
            trial_candidates = candidates[:]
            random.shuffle(trial_candidates)

            for candidate in trial_candidates:
                if candidate in used_candidates:
                    continue

                aligned_cidr_arr, frag_arr = align_idr_to_target(
                    candidate,
                    frag,
                    case="C-IDR",
                    max_clash=80,
                    tolerance=0.4,
                )
                if aligned_cidr_arr is None:
                    continue

                appended = stitch_append_idr(frag_arr, aligned_cidr_arr)
                save_structure_array(
                    appended,
                    os.path.join(path_next, f"conformer_{frag_idx}.pdb"),
                )
                used_candidates.add(candidate)
                del pending[frag_idx]
                made_progress += 1
                break

        batch_idx += 1
        rs += build_batch_size + 17

        if made_progress == 0:
            no_progress_batches += 1
        else:
            no_progress_batches = 0

        print(
            f"  C-IDR stage progress: {nconfs - len(pending)}/{nconfs} "
            f"after {batch_idx} batches; this_batch={made_progress}; "
            f"pending={len(pending)}"
        )

        if batch_idx >= stage_no_solution_batch_limit and len(pending) == nconfs:
            raise ProgressStalledError(
                stage="append_cterm_idr",
                details=(
                    f"No fragments accepted after {stage_no_solution_batch_limit} "
                    f"shared batches of {build_batch_size} C-IDR candidates."
                ),
            )

        if no_progress_batches >= stage_no_progress_batch_limit and pending:
            preview = ", ".join(str(x) for x in sorted(pending)[:10])
            raise ProgressStalledError(
                stage="append_cterm_idr",
                details=(
                    f"No additional C-IDR appends in the last "
                    f"{stage_no_progress_batch_limit} batches. "
                    f"Remaining examples: {preview}"
                ),
            )


def swap_stage_dirs(path_from, path_to):
    clear_dir(path_to)
    for pdb in sorted_pdbs(path_from):
        shutil.move(pdb, path_to)
    clear_dir(path_from)


# =============================================================================
# Main
# =============================================================================

def main():
    try:
        with open(master_db_file, "r") as f:
            master_db = json.load(f)
        with open(medium_ids_file, "r") as f:
            medium_ids = [line.strip() for line in f if line.strip()]
        with open(max_residues_file, "r") as f:
            max_residues = json.load(f)
    except FileNotFoundError:
        print("Error: file not found for databases. Please check paths.")
        sys.exit(1)

    ensure_dir(output_directory)

    for uniprot_id in medium_ids:
        path_final_ens = os.path.join(output_directory, uniprot_id)
        path_templates = os.path.join(path_final_ens, "temp_templates")
        path_build = os.path.join(path_final_ens, "temp_build")
        path_work = os.path.join(path_final_ens, "temp_work")
        path_current = os.path.join(path_final_ens, "temp_current")
        path_next = os.path.join(path_final_ens, "temp_next")

        ensure_dir(path_final_ens)
        remove_matching_files(path_final_ens, ["BUILD_PROBLEM*.txt"])

        try:
            for folder in (path_templates, path_build, path_work, path_current, path_next):
                clear_dir(folder)
            remove_matching_files(path_final_ens, ["conformer*.pdb", "*_idpcg_n*.pdb", "energies.log"])

            pdb_path = find_template_path(uniprot_id)
            struc = Structure(Path(pdb_path))
            struc.build()
            struc_arr = struc.data_array
            sequence = next(iter(struc.fasta.values()))
            details_all = [list(x) for x in master_db[uniprot_id]["idrs"]]
            num_res = max_residues[uniprot_id]

            if not details_all:
                print(f"Skipping {uniprot_id}: no IDRs found in master database.")
                continue

            has_n = details_all[0][0] == 1
            has_c = details_all[-1][1] == num_res

            linker_ranges = [list(x) for x in details_all]
            n_term = None
            c_term = None
            if has_n:
                n_term = linker_ranges.pop(0)
            if has_c:
                c_term = linker_ranges.pop(-1)

            if len(linker_ranges) == 0:
                print(
                    f"Skipping {uniprot_id}: no linker IDRs found. "
                    "This generalized medium builder expects at least one linker."
                )
                continue

            fld_domains = find_fld_domains(details_all, num_res)
            expected_domains = len(linker_ranges) + 1
            if len(fld_domains) != expected_domains:
                raise ValueError(
                    f"{uniprot_id}: expected {expected_domains} folded domains for "
                    f"{len(linker_ranges)} linker IDRs, but found {len(fld_domains)}."
                )

            # make_domain_templates no longer needs struc_lst — uses numpy mask directly.
            domain_paths = make_domain_templates(
                uniprot_id=uniprot_id,
                struc_arr=struc_arr,
                fld_domains=fld_domains,
                path_templates=path_templates,
            )

            linker_seqs = [build_range_seq(sequence, s, e, "L") for s, e in linker_ranges]
            linker_long = [is_long_idr(s, e) for s, e in linker_ranges]

            nidr_seq = None
            nidr_long = False
            if n_term is not None:
                nidr_seq = build_range_seq(sequence, n_term[0], n_term[1], "N")
                nidr_long = is_long_idr(n_term[0], n_term[1])

            cidr_seq = None
            cidr_long = False
            if c_term is not None:
                cidr_seq = build_range_seq(sequence, c_term[0], c_term[1], "C")
                cidr_long = is_long_idr(c_term[0], c_term[1])

            print(f"Building {nconfs} conformers for {uniprot_id}...")

            # Seed the current fragment set as either N + D0 or just D0.
            if has_n:
                seed_with_nidr(
                    domain0_path=domain_paths[0],
                    nidr_seq=nidr_seq,
                    nidr_is_long=nidr_long,
                    path_build=path_build,
                    path_current=path_current,
                )
            else:
                seed_without_nidr(domain_paths[0], path_current)

            current_fragments = sorted_pdbs(path_current)
            if len(current_fragments) != nconfs:
                raise RuntimeError(
                    f"{uniprot_id}: seed stage produced {len(current_fragments)} conformers instead of {nconfs}."
                )

            # Iteratively add each linker plus the next folded domain.
            for linker_idx, (linker_seq, linker_is_long) in enumerate(
                zip(linker_seqs, linker_long), start=1
            ):
                extend_with_linker_and_domain(
                    current_fragments=sorted_pdbs(path_current)[:nconfs],
                    linker_seq=linker_seq,
                    linker_is_long=linker_is_long,
                    next_domain_path=domain_paths[linker_idx],
                    path_build=path_build,
                    path_work=path_work,
                    path_next=path_next,
                )
                swap_stage_dirs(path_next, path_current)

            # Optionally append a C-terminal IDR.
            if has_c:
                append_cterm_idr(
                    current_fragments=sorted_pdbs(path_current)[:nconfs],
                    cidr_seq=cidr_seq,
                    cidr_is_long=cidr_long,
                    path_build=path_build,
                    path_next=path_next,
                )
                swap_stage_dirs(path_next, path_current)

            final_stage = sorted_pdbs(path_current)
            if len(final_stage) != nconfs:
                raise RuntimeError(
                    f"{uniprot_id}: final stage produced {len(final_stage)} conformers instead of {nconfs}."
                )

            remove_matching_files(path_final_ens, ["conformer*.pdb"])
            for idx, src in enumerate(final_stage, start=1):
                shutil.move(src, os.path.join(path_final_ens, f"conformer_{idx}.pdb"))

            print("Adding hydrogens...")
            idpcg_files = sorted_pdbs(path_final_ens)
            if len(idpcg_files) != nconfs:
                raise RuntimeError(
                    f"{uniprot_id}: expected {nconfs} conformers before protonation, found {len(idpcg_files)}."
                )
            fix_atoms_pool = pool_function(add_hydrogens, idpcg_files, ncores=fix_ncores)
            for _ in fix_atoms_pool:
                pass

            print("Resolving side-chain clashes...")
            hydrogenated_files = sorted_pdbs(path_final_ens)
            cc_pool = pool_function(resolve_clash, hydrogenated_files, ncores=cc_ncores)
            for _ in cc_pool:
                pass

            ensemble_path = os.path.join(path_final_ens, f"{uniprot_id}_idpcg_n{nconfs}.pdb")
            run_command(
                ["pdb_mkensemble"] + sorted_pdbs(path_final_ens),
                stdout_file=ensemble_path,
            )

            remove_matching_files(path_final_ens, ["conformer*.pdb", "temp*", "energies.log"])
            print(f"Finished: {uniprot_id}.")

        except ProgressStalledError as exc:
            print(f"Stalled for {uniprot_id}: {exc}")
            remove_matching_files(path_final_ens, ["conformer*.pdb", "*_idpcg_n*.pdb", "temp*", "energies.log"])
            message = (
                f"Build stalled for {uniprot_id}.\n"
                f"Stage: {exc.stage}\n"
                f"Details: {exc.details}\n"
                "This entry likely needs manual inspection or relaxed clash/sampling criteria."
            )
            mark_build_problem(path_final_ens, uniprot_id, message)
            continue


if __name__ == "__main__":
    main()
