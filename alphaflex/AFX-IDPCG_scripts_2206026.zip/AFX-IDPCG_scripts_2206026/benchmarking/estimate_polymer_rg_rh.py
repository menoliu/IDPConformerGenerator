"""
Estimate Rg and optional Rh from amino-acid sequence using simple empirical
polymer scaling laws.

Primary recommended null model for IDRs:
    Rg_IDP = 2.54 * N^0.522  [Å]

Also reports:
    Rg_denatured = 1.927 * N^0.598  [Å]
    Rg_folded_ref = sqrt(3/5) * 4.75 * N^0.29  [Å]

Optional Rh estimates:
    Rh_Bernado_Blackledge = 3.53 * N^0.449  [Å]
    Rh_Marsh_FormanKay_avg = 2.49 * N^0.509  [Å]
    Rh_Marsh_FormanKay_seq = sequence-adjusted rough estimate using Pro and net charge

Usage:
    python estimate_polymer_rg_rh.py --seq "MSEQUENCEHERE"
    python estimate_polymer_rg_rh.py --fasta idrs.fasta -o rg_rh_null_model.csv
"""
import argparse
import csv
import json
import math
import re
from pathlib import Path


AA_MASS = {
    # average residue masses in protein chain, Da; water removed
    "A": 71.0788, "R": 156.1875, "N": 114.1038, "D": 115.0886,
    "C": 103.1388, "E": 129.1155, "Q": 128.1307, "G": 57.0519,
    "H": 137.1411, "I": 113.1594, "L": 113.1594, "K": 128.1741,
    "M": 131.1926, "F": 147.1766, "P": 97.1167, "S": 87.0782,
    "T": 101.1051, "W": 186.2132, "Y": 163.1760, "V": 99.1326,
}

VALID_AA = set(AA_MASS)


def clean_sequence(seq: str) -> str:
    """Remove whitespace/gaps and keep uppercase amino acid letters."""
    seq = re.sub(r"[^A-Za-z]", "", seq).upper()
    bad = sorted(set(seq) - VALID_AA)
    if bad:
        raise ValueError(f"Unsupported residue(s): {bad}. Use standard 20 amino acids only.")
    return seq


def read_fasta(path):
    records = []
    name = None
    chunks = []

    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if name is not None:
                    records.append((name, clean_sequence("".join(chunks))))
                name = line[1:].split()[0]
                chunks = []
            else:
                chunks.append(line)

    if name is not None:
        records.append((name, clean_sequence("".join(chunks))))

    return records


def estimate_net_charge(seq: str, ph_approx: float = 7.0) -> int:
    """
    Very simple integer charge approximation near neutral pH.
    K/R = +1, D/E = -1.
    H is ignored by default because its charge is pH-sensitive.
    """
    pos = seq.count("K") + seq.count("R")
    neg = seq.count("D") + seq.count("E")
    return pos - neg


def calc_features(seq: str, seq_id: str = "sequence"):
    n = len(seq)
    if n == 0:
        raise ValueError("Empty sequence.")

    mw_da = sum(AA_MASS[aa] for aa in seq) + 18.01528  # add terminal water

    net_charge = estimate_net_charge(seq)
    n_charged = sum(seq.count(x) for x in "KRDE")
    fcr = n_charged / n
    ncpr = net_charge / n
    f_pro = seq.count("P") / n

    # Rg models, Å
    rg_idp = 2.54 * (n ** 0.522)
    rg_denatured = 1.927 * (n ** 0.598)
    rg_folded_ref = math.sqrt(3.0 / 5.0) * 4.75 * (n ** 0.29)

    # Optional Rh models, Å
    rh_bernado_blackledge = 3.53 * (n ** 0.449)
    rh_marsh_formankay_avg = 2.49 * (n ** 0.509)

    # Simple sequence-adjusted Marsh/Forman-Kay-style Rh estimate.
    # Treat this as a rough IDP hydrodynamic-radius control, not a SAXS Rg model.
    r0_seq = (1.24 * f_pro + 0.904) * (0.00759 * abs(net_charge) + 0.963) * 2.49
    rh_marsh_formankay_seq = r0_seq * (n ** 0.509)

    return {
        "id": seq_id,
        "N": n,
        "MW_Da": mw_da,
        "net_charge_simple": net_charge,
        "FCR_simple": fcr,
        "NCPR_simple": ncpr,
        "f_pro": f_pro,

        "Rg_IDP_Bernado_Blackledge_A": rg_idp,
        "Rg_denatured_Kohn_like_A": rg_denatured,
        "Rg_folded_reference_A": rg_folded_ref,

        "Rh_Bernado_Blackledge_A": rh_bernado_blackledge,
        "Rh_Marsh_FormanKay_avg_A": rh_marsh_formankay_avg,
        "Rh_Marsh_FormanKay_seq_adjusted_A": rh_marsh_formankay_seq,

        # Useful for comparing your ensemble/experimental Rg later:
        "Rg_IDP_nm": rg_idp / 10.0,
        "Rh_Marsh_FormanKay_avg_nm": rh_marsh_formankay_avg / 10.0,
    }


def estimate_rg_rh_only(seq: str):
    """Return only the primary Rg/Rh estimates for JSON output mode."""
    n = len(seq)
    if n == 0:
        raise ValueError("Empty sequence.")

    rg_idp = 2.54 * (n ** 0.522)
    rh_marsh_formankay_avg = 2.49 * (n ** 0.509)

    return {
        "Rg": [rg_idp, 0],
        "Rh": [rh_marsh_formankay_avg, 0],
    }


def extract_sequence(entry: dict, seq_key: str | None = None) -> str:
    """
    Extract sequence string from a JSON entry.

    Supports explicit key via --json-seq-key and common fallback keys.
    """
    if not isinstance(entry, dict):
        raise ValueError("Entry is not a JSON object")

    if seq_key:
        if seq_key not in entry:
            raise ValueError(f"Missing sequence key '{seq_key}'")
        return clean_sequence(str(entry[seq_key]))

    for key in ("Sequence", "sequence", "seq", "SEQ"):
        if key in entry:
            return clean_sequence(str(entry[key]))

    raise ValueError("No sequence key found (tried: Sequence, sequence, seq, SEQ)")


def predict_from_json(input_json: str, output_json: str | None = None, seq_key: str | None = None):
    """
    Read ID-keyed JSON and write ID-keyed JSON with only estimated Rg/Rh values.
    """
    with open(input_json, "r") as f:
        data = json.load(f)

    if not isinstance(data, dict):
        raise ValueError("Top-level JSON must be an object mapping ID -> entry")

    result = {}
    skipped = 0

    for seq_id, entry in data.items():
        try:
            seq = extract_sequence(entry, seq_key=seq_key)
            pred = estimate_rg_rh_only(seq)
            result[seq_id] = {
                "Sequence": seq,
                "Rg": pred["Rg"],
                "Rh": pred["Rh"],
            }
        except Exception as e:
            skipped += 1
            print(f"Skipping {seq_id}: {e}")

    in_path = Path(input_json)
    out_path = Path(output_json) if output_json else in_path.with_name(f"{in_path.stem}_rg_rh_predicted.json")

    with open(out_path, "w") as f:
        json.dump(result, f, indent=4)

    print(f"Wrote {len(result)} predicted entries to: {out_path}")
    if skipped:
        print(f"Skipped {skipped} entries due to missing/invalid sequence data")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seq", type=str, help="Single amino-acid sequence.")
    parser.add_argument("--id", type=str, default="sequence", help="ID for --seq input.")
    parser.add_argument("--fasta", type=str, help="FASTA file with one or more sequences.")
    parser.add_argument("--input-json", type=str, help="Input JSON mapping IDs to entries containing sequences.")
    parser.add_argument("--json-seq-key", type=str, default=None, help="Sequence key in each JSON entry (e.g., Sequence).")
    parser.add_argument("--output-json", type=str, default=None, help="Output JSON path for --input-json mode.")
    parser.add_argument("-o", "--out", type=str, default="rg_rh_null_model.csv")
    args = parser.parse_args()

    if args.input_json:
        predict_from_json(args.input_json, output_json=args.output_json, seq_key=args.json_seq_key)
        return

    if not args.seq and not args.fasta:
        parser.error("Provide either --seq, --fasta, or --input-json.")

    records = []

    if args.seq:
        records.append((args.id, clean_sequence(args.seq)))

    if args.fasta:
        records.extend(read_fasta(args.fasta))

    rows = [calc_features(seq, seq_id) for seq_id, seq in records]

    fieldnames = list(rows[0].keys())
    with open(args.out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(rows)} sequence(s) to: {args.out}")

    # Print single-sequence result nicely
    if len(rows) == 1:
        row = rows[0]
        print()
        print(f"ID: {row['id']}")
        print(f"N = {row['N']}")
        print(f"Rg_IDP = {row['Rg_IDP_Bernado_Blackledge_A']:.2f} Å "
              f"({row['Rg_IDP_nm']:.2f} nm)")
        print(f"Rh_avg = {row['Rh_Marsh_FormanKay_avg_A']:.2f} Å "
              f"({row['Rh_Marsh_FormanKay_avg_nm']:.2f} nm)")


if __name__ == "__main__":
    main()