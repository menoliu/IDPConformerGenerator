import argparse
import concurrent.futures as cf
import re
import subprocess
import sys
from pathlib import Path

import pandas as pd


def parse_ph_file(ph_file: Path) -> dict:
    """
    Parse lines like:
        O76070, 7244, pH = 7.4
        Q00688, 19551 pH = 7.0

    Returns:
        {"O76070": 7.4, ...}
    """
    ph_by_uniprot = {}

    pattern = re.compile(
        r"^\s*([A-Z0-9]+)\s*,.*?\bpH\s*=?\s*([0-9]+(?:\.[0-9]+)?)",
        re.IGNORECASE,
    )

    with open(ph_file, "r") as handle:
        for line_no, line in enumerate(handle, start=1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            match = pattern.search(line)
            if not match:
                print(f"WARNING: Could not parse pH line {line_no}: {line}", file=sys.stderr)
                continue

            uniprot = match.group(1).upper()
            ph = float(match.group(2))
            ph_by_uniprot[uniprot] = ph

    return ph_by_uniprot


def infer_uniprot_from_filename(pdb_path: Path) -> str:
    """
    Expected:
        UNIPROTID_idpcg_n100.pdb

    Example:
        P37840_idpcg_n100.pdb -> P37840
    """
    name = pdb_path.name

    if name.endswith("_idpcg_n100.pdb"):
        return name.replace("_idpcg_n100.pdb", "").upper()

    # Fallback: take everything before first underscore.
    return pdb_path.stem.split("_")[0].upper()


def split_multimodel_pdb(input_pdb: Path, split_dir: Path, overwrite: bool = False):
    """
    Split a multi-model PDB into single-model PDB files.

    Output:
        model_001.pdb
        model_002.pdb
        ...
    """
    split_dir.mkdir(parents=True, exist_ok=True)

    with open(input_pdb, "r") as handle:
        lines = handle.readlines()

    header = []
    models = []
    current = []
    inside_model = False
    saw_model = False

    for line in lines:
        rec = line[:6].strip()

        if rec == "MODEL":
            saw_model = True
            inside_model = True
            current = []
            continue

        if rec == "ENDMDL":
            inside_model = False
            models.append(current)
            current = []
            continue

        if rec == "END":
            continue

        if inside_model:
            current.append(line)
        elif not saw_model:
            header.append(line)

    if not saw_model:
        # Single-model fallback.
        models = [[line for line in lines if line[:6].strip() != "END"]]
        header = []

    output_pdbs = []

    for i, model_lines in enumerate(models, start=1):
        out_pdb = split_dir / f"model_{i:03d}.pdb"

        if out_pdb.exists() and not overwrite:
            output_pdbs.append(out_pdb)
            continue

        with open(out_pdb, "w") as out:
            for line in header:
                rec = line[:6].strip()
                if rec not in {"MODEL", "ENDMDL", "END"}:
                    out.write(line)

            for line in model_lines:
                rec = line[:6].strip()
                if rec not in {"MODEL", "ENDMDL", "END"}:
                    out.write(line)

            out.write("END\n")

        output_pdbs.append(out_pdb)

    return output_pdbs


def run_cspred_one(
    pdb_path: Path,
    csv_path: Path,
    log_path: Path,
    mount_root: Path,
    models_dir: Path,
    docker_image: str,
    ph: float,
    ph_flag: str = "-ph",
    overwrite: bool = False,
    ):
        """
        Run CSpred Docker command for one single-model PDB.
        """
        if csv_path.exists() and not overwrite:
            return {
                "pdb": str(pdb_path),
                "csv": str(csv_path),
                "log": str(log_path),
                "status": "skipped_existing",
                "returncode": 0,
            }

        csv_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        container_pdb = "/data/" + pdb_path.relative_to(mount_root).as_posix()
        container_csv = "/data/" + csv_path.relative_to(mount_root).as_posix()

        cmd = [
            "docker", "run", "--rm",
            "-v", f"{models_dir}:/opt/CSpred/models:ro",
            "-v", f"{mount_root}:/data",
            "-w", "/opt/CSpred",
            docker_image,
            container_pdb,
            ph_flag, str(ph),
            "-o", container_csv,
        ]

        with open(log_path, "w") as log:
            log.write("Command:\n")
            log.write(" ".join(cmd) + "\n\n")
            log.flush()

            result = subprocess.run(
                cmd,
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
            )

        return {
            "pdb": str(pdb_path),
            "csv": str(csv_path),
            "log": str(log_path),
            "status": "ok" if result.returncode == 0 else "failed",
            "returncode": result.returncode,
        }


def get_shift_columns(df: pd.DataFrame, shift_suffix: str = "_X"):
    """
    Your example CSV has predicted shifts in columns like:
        C_X, CA_X, CB_X, N_X, H_X, ...

    The *_Y columns appear empty in your example.
    The *_UCBShift columns appear to duplicate *_X.

    Default: summarize *_X only.
    """
    protected = {"RESNUM", "RESNAME", "UNIPROT", "MODEL", "PH"}

    shift_cols = []

    for col in df.columns:
        if col in protected:
            continue

        if col.endswith(shift_suffix):
            values = pd.to_numeric(df[col], errors="coerce")
            if values.notna().sum() > 0:
                shift_cols.append(col)

    return shift_cols


def combine_for_one_uniprot(
    uniprot: str,
    ph: float,
    csv_files: list[Path],
    outdir: Path,
    shift_suffix: str = "_X",
    ):
        """
        Combine 100 model CSVs for one protein and calculate ensemble mean/std.

        Writes:
            all_models_wide.csv
            ensemble_mean_std_wide.csv
            ensemble_mean_std_tidy.csv
        """
        dfs = []

        for csv_file in sorted(csv_files):
            match = re.search(r"model_(\d+)", csv_file.stem)
            model_idx = int(match.group(1)) if match else len(dfs) + 1

            df = pd.read_csv(csv_file)
            df.insert(0, "PH", ph)
            df.insert(0, "MODEL", model_idx)
            df.insert(0, "UNIPROT", uniprot)
            dfs.append(df)

        if not dfs:
            return None

        all_df = pd.concat(dfs, ignore_index=True)

        protein_outdir = outdir / "proteins" / uniprot
        protein_outdir.mkdir(parents=True, exist_ok=True)

        all_models_path = protein_outdir / "all_models_wide.csv"
        wide_summary_path = protein_outdir / "ensemble_mean_std_wide.csv"
        tidy_summary_path = protein_outdir / "ensemble_mean_std_tidy.csv"

        all_df.to_csv(all_models_path, index=False)

        shift_cols = get_shift_columns(all_df, shift_suffix=shift_suffix)

        if not shift_cols:
            print(f"WARNING: No shift columns found for {uniprot}", file=sys.stderr)
            return {
                "uniprot": uniprot,
                "all_models": all_models_path,
                "wide_summary": None,
                "tidy_summary": None,
            }

        for col in shift_cols:
            all_df[col] = pd.to_numeric(all_df[col], errors="coerce")

        group_cols = ["UNIPROT", "PH", "RESNUM", "RESNAME"]

        wide_summary = (
            all_df
            .groupby(group_cols, dropna=False)[shift_cols]
            .agg(["mean", "std", "count"])
            .reset_index()
        )

        wide_summary.columns = [
            "_".join([str(x) for x in col if str(x)])
            if isinstance(col, tuple)
            else col
            for col in wide_summary.columns
        ]

        wide_summary.to_csv(wide_summary_path, index=False)

        tidy_rows = []

        grouped = all_df.groupby(group_cols, dropna=False)

        for keys, sub in grouped:
            base = dict(zip(group_cols, keys))

            for col in shift_cols:
                atom = col.removesuffix(shift_suffix)
                vals = pd.to_numeric(sub[col], errors="coerce").dropna()

                tidy_rows.append({
                    **base,
                    "ATOM": atom,
                    "SHIFT_MEAN": vals.mean() if len(vals) else float("nan"),
                    "SHIFT_STD": vals.std(ddof=1) if len(vals) > 1 else float("nan"),
                    "SHIFT_COUNT": int(len(vals)),
                })

        tidy_summary = pd.DataFrame(tidy_rows)
        tidy_summary.to_csv(tidy_summary_path, index=False)

        return {
            "uniprot": uniprot,
            "all_models": all_models_path,
            "wide_summary": wide_summary_path,
            "tidy_summary": tidy_summary_path,
        }


def combine_global(protein_dirs: list[Path], outdir: Path):
    """
    Combine all per-protein summaries into global files.
    """
    tidy_paths = []
    wide_paths = []
    all_model_paths = []

    for pdir in protein_dirs:
        tidy = pdir / "ensemble_mean_std_tidy.csv"
        wide = pdir / "ensemble_mean_std_wide.csv"
        all_models = pdir / "all_models_wide.csv"

        if tidy.exists():
            tidy_paths.append(tidy)
        if wide.exists():
            wide_paths.append(wide)
        if all_models.exists():
            all_model_paths.append(all_models)

    if tidy_paths:
        df = pd.concat([pd.read_csv(p) for p in tidy_paths], ignore_index=True)
        df.to_csv(outdir / "ALL_ensemble_mean_std_tidy.csv", index=False)

    if wide_paths:
        df = pd.concat([pd.read_csv(p) for p in wide_paths], ignore_index=True)
        df.to_csv(outdir / "ALL_ensemble_mean_std_wide.csv", index=False)

    if all_model_paths:
        df = pd.concat([pd.read_csv(p) for p in all_model_paths], ignore_index=True)
        df.to_csv(outdir / "ALL_all_models_wide.csv", index=False)


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Run CSpred on a folder of multi-model IDPCG PDB ensembles named "
            "UNIPROTID_idpcg_n100.pdb, using per-UniProt pH values."
        )
    )

    parser.add_argument(
        "input_dir",
        help="Folder containing multi-model PDB files named UNIPROTID_idpcg_n100.pdb",
    )

    parser.add_argument(
        "--ph-file",
        required=True,
        help="Text file with UniProt-to-pH mapping, e.g. bmrb_final.txt",
    )

    parser.add_argument(
        "--models-dir",
        default="/mnt/x/Backups/models",
        help="Local CSpred models folder mounted to /opt/CSpred/models. Default: ~/Downloads/models",
    )

    parser.add_argument(
        "--outdir",
        default="cspred_batch_output",
        help="Output directory. Default: cspred_batch_output",
    )

    parser.add_argument(
        "--image",
        default="cspred:latest",
        help="Docker image name. Default: cspred:latest",
    )

    parser.add_argument(
        "--jobs",
        type=int,
        default=4,
        help="Number of parallel Docker jobs. Default: 4",
    )

    parser.add_argument(
        "--expected-models",
        type=int,
        default=100,
        help="Expected number of models per PDB. Use 0 to disable check. Default: 100",
    )

    parser.add_argument(
        "--default-ph",
        type=float,
        default=None,
        help="Fallback pH if a UniProt ID is missing from --ph-file. Default: fail if missing.",
    )

    parser.add_argument(
        "--ph-flag",
        default="-ph",
        help="CSpred pH flag. Default: -ph",
    )

    parser.add_argument(
        "--shift-suffix",
        default="_X",
        help="Which columns to ensemble-average. Default: _X",
    )

    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite split PDBs and existing CSpred CSVs.",
    )

    parser.add_argument(
        "--skip-combine",
        action="store_true",
        help="Run CSpred only; do not combine CSVs.",
    )

    args = parser.parse_args()

    input_dir = Path(args.input_dir).expanduser().resolve()
    ph_file = Path(args.ph_file).expanduser().resolve()
    models_dir = Path(args.models_dir).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve()

    if not input_dir.exists():
        raise FileNotFoundError(f"Input directory not found: {input_dir}")

    if not ph_file.exists():
        raise FileNotFoundError(f"pH file not found: {ph_file}")

    if not models_dir.exists():
        raise FileNotFoundError(f"CSpred models directory not found: {models_dir}")

    outdir.mkdir(parents=True, exist_ok=True)

    ph_by_uniprot = parse_ph_file(ph_file)

    pdb_files = sorted(input_dir.glob("*_cg2all_n100.pdb"))

    if not pdb_files:
        raise FileNotFoundError(f"No *_idpcg_n100.pdb files found in: {input_dir}")

    print(f"Found {len(pdb_files)} multi-model PDB files.")
    print(f"Loaded pH values for {len(ph_by_uniprot)} UniProt IDs.")

    all_tasks = []
    protein_to_csvs = {}
    protein_dirs = []

    for ensemble_pdb in pdb_files:
        uniprot = infer_uniprot_from_filename(ensemble_pdb)

        if uniprot in ph_by_uniprot:
            ph = ph_by_uniprot[uniprot]
        elif args.default_ph is not None:
            ph = args.default_ph
            print(f"WARNING: {uniprot} missing from pH file. Using default pH {ph}.")
        else:
            raise ValueError(
                f"{uniprot} is missing from pH file. "
                f"Either add it or use --default-ph."
            )

        protein_dir = outdir / "proteins" / uniprot
        split_dir = protein_dir / "single_model_pdbs"
        csv_dir = protein_dir / "cspred_csvs"
        log_dir = protein_dir / "logs"

        protein_dirs.append(protein_dir)

        print(f"\nSplitting {ensemble_pdb.name} for {uniprot} at pH {ph}...")

        model_pdbs = split_multimodel_pdb(
            input_pdb=ensemble_pdb,
            split_dir=split_dir,
            overwrite=args.overwrite,
        )

        if args.expected_models and len(model_pdbs) != args.expected_models:
            print(
                f"WARNING: {uniprot} expected {args.expected_models} models, "
                f"found {len(model_pdbs)}.",
                file=sys.stderr,
            )

        csv_files = []

        for model_pdb in model_pdbs:
            csv_path = csv_dir / f"{model_pdb.stem}_cspred.csv"
            log_path = log_dir / f"{model_pdb.stem}_cspred.log"
            csv_files.append(csv_path)

            all_tasks.append({
                "uniprot": uniprot,
                "ph": ph,
                "pdb": model_pdb,
                "csv": csv_path,
                "log": log_path,
            })

        protein_to_csvs[uniprot] = {
            "ph": ph,
            "csvs": csv_files,
        }

    print(f"\nRunning CSpred for {len(all_tasks)} single-model PDBs...")
    print(f"Parallel Docker jobs: {args.jobs}")

    results = []

    with cf.ThreadPoolExecutor(max_workers=args.jobs) as executor:
        futures = []

        for task in all_tasks:
            futures.append(
                executor.submit(
                    run_cspred_one,
                    pdb_path=task["pdb"],
                    csv_path=task["csv"],
                    log_path=task["log"],
                    mount_root=outdir,
                    models_dir=models_dir,
                    docker_image=args.image,
                    ph=task["ph"],
                    ph_flag=args.ph_flag,
                    overwrite=args.overwrite,
                )
            )

        for future in cf.as_completed(futures):
            result = future.result()
            results.append(result)

            print(
                f"{Path(result['pdb']).parent.parent.name}/"
                f"{Path(result['pdb']).name}: {result['status']} "
                f"(return code {result['returncode']})"
            )

    failed = [r for r in results if r["returncode"] != 0]

    if failed:
        print("\nERROR: Some CSpred runs failed.", file=sys.stderr)
        print("Failed jobs:", file=sys.stderr)

        for r in failed:
            print(f"  PDB: {r['pdb']}", file=sys.stderr)
            print(f"  LOG: {r['log']}", file=sys.stderr)

        print(
            "\nFix the failed jobs, then rerun. Existing successful CSVs are skipped "
            "unless --overwrite is used.",
            file=sys.stderr,
        )
        sys.exit(1)

    if not args.skip_combine:
        print("\nCombining CSVs and calculating ensemble statistics...")

        for uniprot, info in protein_to_csvs.items():
            combine_for_one_uniprot(
                uniprot=uniprot,
                ph=info["ph"],
                csv_files=info["csvs"],
                outdir=outdir,
                shift_suffix=args.shift_suffix,
            )

        combine_global(protein_dirs=protein_dirs, outdir=outdir)

    print("\nDone.")
    print(f"Output directory: {outdir}")


if __name__ == "__main__":
    main()
