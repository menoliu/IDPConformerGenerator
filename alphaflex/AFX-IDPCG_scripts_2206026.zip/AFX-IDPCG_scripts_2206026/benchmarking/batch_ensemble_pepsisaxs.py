"""
Batch compare multi-model ensemble PDBs against SASBDB experimental SAXS .dat files.

Typical use:

python batch_ensemble_pepsisaxs.py \
  --exp-dir ./sasbdb_dat \
  --ensemble-dir ./ensembles \
  --outdir ./saxs_batch_results \
  --pepsi-bin /path/to/Pepsi-SAXS \
  --run-pepsi \
  --workers 8 \
    --exp-q-unit auto \
    --pepsi-grid-q-unit A \
    --calc-q-unit A \
  --fit-mode scale_offset

Assumptions:
  - experimental SASBDB .dat filenames contain a UniProt accession
  - ensemble PDB filenames also contain the same UniProt accession
  - ensemble PDBs are multi-model PDBs with MODEL/ENDMDL blocks
    - SASBDB q/s values are often nm^-1; use explicit q-unit flags when known

The key ensemble comparison is:
  I_ensemble(q) = sum_i w_i I_i(q)
  I_fit(q) = scale * I_ensemble(q) + offset

This script fits scale/offset once after ensemble averaging. For strict benchmarking,
try to keep Pepsi-SAXS per-conformer forward-model parameters fixed, using --pepsi-extra
if your Pepsi-SAXS build exposes those flags.
"""
import argparse
import concurrent.futures as futures
import csv
import json
import math
import os
import re
import shlex
import shutil
import subprocess
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np

DEFAULT_UNIPROT_REGEX = r"(?<![A-Z0-9])(?:[OPQ][0-9][A-Z0-9]{3}[0-9]|[A-NR-Z][0-9](?:[A-Z][A-Z0-9]{2}[0-9]){1,2})(?![A-Z0-9])"


@dataclass
class Curve:
    q_A: np.ndarray
    intensity: np.ndarray
    sigma: Optional[np.ndarray] = None
    source_q_unit: str = "A"


@dataclass
class FitResult:
    scale: float
    offset: float
    chi2: float
    chi2_per_point: float
    chi2_reduced: float
    n_points: int
    n_params: int


@dataclass
class FitDiagnostics:
    r_factor: float
    r_factor_weighted: float
    pearson_r: float
    rmse: float
    rmse_over_sigma: float


@dataclass
class ResidualRunDiagnostics:
    n_sign_points: int
    n_runs: int
    longest_run: int
    longest_run_fraction: float
    sign_balance: float


@dataclass
class TargetJob:
    uniprot_id: str
    exp_path: Path
    ensemble_path: Path
    outdir: Path


@dataclass
class TargetSummary:
    status: str
    uniprot_id: str
    exp_file: str
    ensemble_file: str
    outdir: str
    n_models: int = 0
    n_profiles: int = 0
    n_points: int = 0
    scale: float = math.nan
    offset: float = math.nan
    chi2: float = math.nan
    chi2_per_point: float = math.nan
    chi2_reduced: float = math.nan
    r_factor: float = math.nan
    r_factor_weighted: float = math.nan
    pearson_r: float = math.nan
    rmse: float = math.nan
    rmse_over_sigma: float = math.nan
    chi2_p_value: float = math.nan
    statistically_different: Optional[bool] = None
    n_runs: float = math.nan
    longest_run: float = math.nan
    longest_run_fraction: float = math.nan
    sign_balance: float = math.nan
    q_min_A: float = math.nan
    q_max_A: float = math.nan
    rg_nm: float = math.nan
    rg_exp: float = math.nan
    message: str = ""
    rg_exp_min: float = math.nan
    rg_exp_max: float = math.nan


def _float_token(token: str) -> float:
    return float(token.replace("D", "E").replace("d", "e"))


def read_numeric_table(path: Path) -> np.ndarray:
    rows: list[list[float]] = []
    with path.open("r", errors="replace") as handle:
        for line in handle:
            stripped = line.strip()
            if not stripped or stripped.startswith(("#", ";", "!", "@")):
                continue
            toks = stripped.replace(",", " ").split()
            vals: list[float] = []
            for tok in toks:
                try:
                    vals.append(_float_token(tok))
                except ValueError:
                    vals = []
                    break
            if len(vals) >= 2:
                rows.append(vals)

    if not rows:
        raise ValueError(f"No numeric 2+ column data found in {path}")
    width = min(len(r) for r in rows)
    if width < 2:
        raise ValueError(f"Need at least two numeric columns in {path}")
    return np.asarray([r[:width] for r in rows], dtype=float)


def infer_q_unit(q: np.ndarray) -> str:
    qmax = float(np.nanmax(q))
    return "nm" if qmax > 1.5 else "A"


def _norm_unit(unit: str) -> str:
    unit = unit.strip().lower()
    unit = unit.replace("å", "a").replace("angstrom", "a").replace("angstroem", "a")
    if unit in {"a", "a^-1", "1/a", "ang", "ang^-1"}:
        return "A"
    if unit in {"nm", "nm^-1", "1/nm"}:
        return "nm"
    if unit == "auto":
        return "auto"
    raise ValueError(f"Unsupported q unit {unit!r}; use A, nm, or auto.")


def convert_q_to_A(q: np.ndarray, unit: str) -> np.ndarray:
    unit = _norm_unit(unit)
    if unit == "auto":
        unit = infer_q_unit(q)
    if unit == "A":
        return q.astype(float)
    if unit == "nm":
        return q.astype(float) * 0.1
    raise AssertionError(unit)


def convert_q_from_A(q_A: np.ndarray, unit: str) -> np.ndarray:
    unit = _norm_unit(unit)
    if unit == "auto":
        raise ValueError("Cannot convert from A to auto unit; specify A or nm.")
    if unit == "A":
        return q_A.astype(float)
    if unit == "nm":
        return q_A.astype(float) * 10.0
    raise AssertionError(unit)


def read_experimental_curve(path: Path, q_unit: str, q_min_A: Optional[float], q_max_A: Optional[float]) -> Curve:
    arr = read_numeric_table(path)
    if arr.shape[1] < 3:
        raise ValueError(
            f"{path} has only {arr.shape[1]} numeric columns. Experimental SAXS data should have q/s, I(q), sigma(q)."
        )
    q_raw = arr[:, 0]
    source_unit = infer_q_unit(q_raw) if q_unit == "auto" else _norm_unit(q_unit)
    q_A = convert_q_to_A(q_raw, source_unit)
    intensity = arr[:, 1].astype(float)
    sigma = arr[:, 2].astype(float)

    good = np.isfinite(q_A) & np.isfinite(intensity) & np.isfinite(sigma) & (sigma > 0)
    if q_min_A is not None:
        good &= q_A >= q_min_A
    if q_max_A is not None:
        good &= q_A <= q_max_A

    q_A = q_A[good]
    intensity = intensity[good]
    sigma = sigma[good]
    order = np.argsort(q_A)
    q_A, intensity, sigma = q_A[order], intensity[order], sigma[order]
    if q_A.size < 3:
        raise ValueError("Fewer than 3 valid experimental points after filtering.")
    return Curve(q_A=q_A, intensity=intensity, sigma=sigma, source_q_unit=source_unit)


def read_calc_curve(path: Path, calc_i_col: str, q_unit: str) -> Curve:
    arr = read_numeric_table(path)
    q_raw = arr[:, 0]
    q_A = convert_q_to_A(q_raw, q_unit)

    if calc_i_col == "auto":
        if arr.shape[1] == 2:
            i_col = 1
        elif arr.shape[1] >= 4:
            i_col = 3
        else:
            raise ValueError(
                f"{path} has exactly 3 columns. That is ambiguous for calculated curves. Pass --calc-i-col as a 1-based column number for Icalc."
            )
    else:
        i_col = int(calc_i_col) - 1
        if i_col < 1 or i_col >= arr.shape[1]:
            raise ValueError(f"--calc-i-col {calc_i_col} out of range for {path} with {arr.shape[1]} columns.")

    intensity = arr[:, i_col].astype(float)
    good = np.isfinite(q_A) & np.isfinite(intensity)
    q_A, intensity = q_A[good], intensity[good]
    order = np.argsort(q_A)
    return Curve(q_A=q_A[order], intensity=intensity[order], source_q_unit=_norm_unit(q_unit))


def write_exp_grid_for_pepsi(exp: Curve, out_path: Path, q_unit: str) -> None:
    q_out = convert_q_from_A(exp.q_A, q_unit)
    with out_path.open("w") as handle:
        handle.write("# q I sigma\n")
        for q, I, sig in zip(q_out, exp.intensity, exp.sigma):
            handle.write(f"{q:.10g} {I:.10g} {sig:.10g}\n")


def split_multimodel_pdb(pdb_path: Path, outdir: Path, overwrite: bool = False, max_models: Optional[int] = None) -> list[Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    if overwrite:
        for old in outdir.glob("model_*.pdb"):
            old.unlink()

    text = pdb_path.read_text(errors="replace").splitlines()
    has_model = any(line.startswith("MODEL") for line in text)

    if not has_model:
        out_path = outdir / "model_001.pdb"
        if overwrite or not out_path.exists():
            with out_path.open("w") as out:
                for line in text:
                    if line.startswith(("ATOM", "HETATM", "TER", "ANISOU")):
                        out.write(line.rstrip() + "\n")
                out.write("END\n")
        return [out_path]

    model_paths: list[Path] = []
    current: list[str] = []
    model_index = 0
    inside = False

    for line in text:
        if line.startswith("MODEL"):
            if max_models is not None and model_index >= max_models:
                break
            inside = True
            current = []
            model_index += 1
            continue
        if line.startswith("ENDMDL"):
            if inside and current:
                out_path = outdir / f"model_{model_index:03d}.pdb"
                if overwrite or not out_path.exists():
                    with out_path.open("w") as out:
                        for atom_line in current:
                            out.write(atom_line.rstrip() + "\n")
                        out.write("END\n")
                model_paths.append(out_path)
            inside = False
            current = []
            continue
        if inside and line.startswith(("ATOM", "HETATM", "TER", "ANISOU")):
            current.append(line)

    if inside and current and (max_models is None or model_index <= max_models):
        out_path = outdir / f"model_{model_index:03d}.pdb"
        if overwrite or not out_path.exists():
            with out_path.open("w") as out:
                for atom_line in current:
                    out.write(atom_line.rstrip() + "\n")
                out.write("END\n")
        model_paths.append(out_path)

    if not model_paths:
        raise ValueError(f"No models with ATOM/HETATM records found in {pdb_path}")
    return model_paths


def shell_quote(x: object) -> str:
    return shlex.quote(str(x))


def run_one_pepsi(
    pdb_path: Path,
    out_curve: Path,
    out_prefix: Path,
    exp_grid: Path,
    pepsi_bin: str,
    cmd_template: str,
    pepsi_extra: str,
    force: bool,
    ) -> Path:
        out_curve.parent.mkdir(parents=True, exist_ok=True)
        if out_curve.exists() and out_curve.stat().st_size > 0 and not force:
            return out_curve

        fmt = {
            "pepsi_bin": shell_quote(pepsi_bin),
            "pdb": shell_quote(pdb_path),
            "exp_grid": shell_quote(exp_grid),
            "exp_dat": shell_quote(exp_grid),
            "out_curve": shell_quote(out_curve),
            "out_prefix": shell_quote(out_prefix),
            "extra": pepsi_extra,
        }
        cmd = cmd_template.format(**fmt)

        log_path = out_curve.with_suffix(out_curve.suffix + ".log")
        with log_path.open("w") as log:
            log.write(f"# Command:\n{cmd}\n\n")
            proc = subprocess.run(cmd, shell=True, stdout=log, stderr=subprocess.STDOUT)
        if proc.returncode != 0:
            raise RuntimeError(f"Pepsi-SAXS failed for {pdb_path}. See log: {log_path}")

        if not out_curve.exists() or out_curve.stat().st_size == 0:
            candidates = sorted(
                [
                    p for p in out_curve.parent.glob(out_prefix.name + "*")
                    if p.is_file() and p.stat().st_size > 0 and p.suffix.lower() in {".dat", ".fit", ".txt", ".out", ".chi"}
                ],
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            if candidates:
                shutil.copyfile(candidates[0], out_curve)
            else:
                raise FileNotFoundError(
                    f"Expected Pepsi output {out_curve}, but it was not created. Check --pepsi-cmd-template and log {log_path}"
                )
        return out_curve


def run_pepsi_all(
    model_paths: list[Path],
    outdir: Path,
    exp_grid: Path,
    pepsi_bin: str,
    cmd_template: str,
    pepsi_extra: str,
    workers: int,
    force: bool,
    ) -> list[Path]:
        profiles_dir = outdir / "profiles"
        profiles_dir.mkdir(parents=True, exist_ok=True)
        tasks = []
        for model_path in model_paths:
            stem = model_path.stem
            tasks.append((model_path, profiles_dir / f"{stem}.dat", profiles_dir / stem))

        if workers <= 1:
            return [
                run_one_pepsi(model_path, out_curve, out_prefix, exp_grid, pepsi_bin, cmd_template, pepsi_extra, force)
                for model_path, out_curve, out_prefix in tasks
            ]

        results: list[Path] = []
        with futures.ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [
                ex.submit(run_one_pepsi, model_path, out_curve, out_prefix, exp_grid, pepsi_bin, cmd_template, pepsi_extra, force)
                for model_path, out_curve, out_prefix in tasks
            ]
            for fut in futures.as_completed(futs):
                results.append(fut.result())
        return sorted(results)


def load_weights(path: Optional[Path], n: int) -> np.ndarray:
    if path is None:
        return np.ones(n, dtype=float) / float(n)
    vals: list[float] = []
    with path.open() as handle:
        for line in handle:
            stripped = line.strip()
            if not stripped or stripped.startswith(("#", ";")):
                continue
            vals.append(float(stripped.replace(",", " ").split()[-1]))
    weights = np.asarray(vals, dtype=float)
    if weights.size != n:
        raise ValueError(f"Weight file contains {weights.size} weights but there are {n} profiles.")
    if np.any(weights < 0) or not np.any(weights > 0):
        raise ValueError("Weights must be non-negative and at least one weight must be positive.")
    return weights / weights.sum()


def interpolate_profiles_to_exp(profile_paths: list[Path], exp_q_A: np.ndarray, calc_i_col: str, calc_q_unit: str) -> tuple[np.ndarray, list[str]]:
    rows = []
    names = []
    for path in profile_paths:
        curve = read_calc_curve(path, calc_i_col=calc_i_col, q_unit=calc_q_unit)
        if curve.q_A.size < 2:
            raise ValueError(f"Calculated profile {path} has fewer than 2 q-points.")
        interp = np.interp(exp_q_A, curve.q_A, curve.intensity)
        outside = (exp_q_A < curve.q_A.min()) | (exp_q_A > curve.q_A.max())
        interp[outside] = np.nan
        rows.append(interp)
        names.append(path.name)
    return np.vstack(rows), names


def weighted_mean_profiles(profile_matrix: np.ndarray, weights: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    valid = np.isfinite(profile_matrix)
    weighted = np.where(valid, profile_matrix * weights[:, None], 0.0)
    wsum = np.where(valid, weights[:, None], 0.0).sum(axis=0)
    mean = np.full(profile_matrix.shape[1], np.nan, dtype=float)
    good = wsum > 0
    mean[good] = weighted[:, good].sum(axis=0) / wsum[good]
    return mean, wsum


def weighted_profile_std(profile_matrix: np.ndarray, weights: np.ndarray, mean: np.ndarray) -> np.ndarray:
    valid = np.isfinite(profile_matrix) & np.isfinite(mean)[None, :]
    centered = np.where(valid, profile_matrix - mean[None, :], 0.0)
    wsum = np.where(valid, weights[:, None], 0.0).sum(axis=0)
    var_num = np.where(valid, weights[:, None] * centered ** 2, 0.0).sum(axis=0)
    var = np.full(profile_matrix.shape[1], np.nan, dtype=float)
    good = wsum > 0
    var[good] = var_num[good] / wsum[good]
    var[var < 0] = 0.0
    return np.sqrt(var)


def fit_scale_offset(I_exp: np.ndarray, sigma: np.ndarray, I_calc: np.ndarray, fit_mode: str) -> FitResult:
    good = np.isfinite(I_exp) & np.isfinite(sigma) & np.isfinite(I_calc) & (sigma > 0)
    y, s, x = I_exp[good], sigma[good], I_calc[good]
    if y.size < 3:
        raise ValueError("Fewer than 3 points available for chi^2 fit.")
    w_sqrt = 1.0 / s
    if fit_mode == "scale":
        X = x[:, None]
        n_params = 1
    elif fit_mode == "scale_offset":
        X = np.column_stack([x, np.ones_like(x)])
        n_params = 2
    else:
        raise ValueError("--fit-mode must be 'scale' or 'scale_offset'.")
    beta, *_ = np.linalg.lstsq(X * w_sqrt[:, None], y * w_sqrt, rcond=None)
    scale = float(beta[0])
    offset = float(beta[1]) if fit_mode == "scale_offset" else 0.0
    y_fit = scale * x + offset
    chi2 = float(np.sum(((y_fit - y) / s) ** 2))
    n_points = int(y.size)
    dof = max(n_points - n_params, 1)
    return FitResult(scale, offset, chi2, chi2 / n_points, chi2 / dof, n_points, n_params)


def chi2_pvalue_upper_approx(chi2: float, dof: int) -> float:
    """
    Approximate upper-tail p-value P(ChiSquare_dof >= chi2) using
    the Wilson-Hilferty transform to a standard normal variable.
    """
    if not np.isfinite(chi2) or dof <= 0:
        return math.nan
    if chi2 < 0:
        return 1.0
    k = float(dof)
    z = ((chi2 / k) ** (1.0 / 3.0) - (1.0 - 2.0 / (9.0 * k))) / math.sqrt(2.0 / (9.0 * k))
    p_upper = 0.5 * math.erfc(z / math.sqrt(2.0))
    return float(min(max(p_upper, 0.0), 1.0))


def compute_fit_diagnostics(I_exp: np.ndarray, sigma: np.ndarray, I_fit: np.ndarray) -> FitDiagnostics:
    good = np.isfinite(I_exp) & np.isfinite(sigma) & np.isfinite(I_fit) & (sigma > 0)
    y = I_exp[good]
    s = sigma[good]
    yf = I_fit[good]
    if y.size < 2:
        return FitDiagnostics(math.nan, math.nan, math.nan, math.nan, math.nan)

    resid = yf - y
    abs_y_sum = float(np.sum(np.abs(y)))
    r_factor = float(np.sum(np.abs(resid)) / abs_y_sum) if abs_y_sum > 0 else math.nan

    wy_abs_sum = float(np.sum(np.abs(y / s)))
    r_factor_weighted = float(np.sum(np.abs(resid / s)) / wy_abs_sum) if wy_abs_sum > 0 else math.nan

    y_std = float(np.std(y))
    yf_std = float(np.std(yf))
    if y_std > 0 and yf_std > 0:
        pearson_r = float(np.corrcoef(y, yf)[0, 1])
    else:
        pearson_r = math.nan

    rmse = float(np.sqrt(np.mean(resid ** 2)))
    rmse_over_sigma = float(np.sqrt(np.mean((resid / s) ** 2)))
    return FitDiagnostics(r_factor, r_factor_weighted, pearson_r, rmse, rmse_over_sigma)


def compute_residual_run_diagnostics(residual_over_sigma: np.ndarray) -> ResidualRunDiagnostics:
    finite = np.isfinite(residual_over_sigma)
    if finite.sum() < 2:
        return ResidualRunDiagnostics(0, 0, 0, math.nan, math.nan)

    signs = np.sign(residual_over_sigma[finite])
    signs = signs[signs != 0]
    n = int(signs.size)
    if n < 2:
        return ResidualRunDiagnostics(n, 1 if n == 1 else 0, n, 1.0 if n == 1 else math.nan, math.nan)

    run_lengths: list[int] = []
    cur = 1
    for prev, nxt in zip(signs[:-1], signs[1:]):
        if nxt == prev:
            cur += 1
        else:
            run_lengths.append(cur)
            cur = 1
    run_lengths.append(cur)

    n_runs = len(run_lengths)
    longest = int(max(run_lengths))
    sign_balance = float(abs(np.sum(signs)) / n)
    return ResidualRunDiagnostics(n, n_runs, longest, float(longest / n), sign_balance)


def write_per_target_outputs(
    outdir: Path,
    exp: Curve,
    I_avg: np.ndarray,
    wsum: np.ndarray,
    fit: FitResult,
    diagnostics: FitDiagnostics,
    run_diag: ResidualRunDiagnostics,
    chi2_p_value: float,
    statistically_different: Optional[bool],
    sigma_fit: np.ndarray,
    sigma_backcalc: np.ndarray,
    profile_names: list[str],
    weights: np.ndarray,
    args: argparse.Namespace,
    uniprot_id: str,
    exp_path: Path,
    ensemble_path: Path,
    ) -> None:
        outdir.mkdir(parents=True, exist_ok=True)
        I_fit = fit.scale * I_avg + fit.offset
        residual_sigma = (I_fit - exp.intensity) / sigma_fit
        q_orig = convert_q_from_A(exp.q_A, exp.source_q_unit)

        with (outdir / "ensemble_saxs_fit.csv").open("w", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow([
                "uniprot_id", "q_A^-1", f"q_original_{exp.source_q_unit}^-1", "I_exp", "sigma_exp",
                "sigma_backcalc", "sigma_fit", "I_calc_ensemble_raw", "I_calc_ensemble_fit", "residual_over_sigma", "conformer_weight_sum_at_q",
            ])
            for qA, q0, ie, sig, sig_back, sig_fit, ic, iff, res, ws in zip(
                exp.q_A,
                q_orig,
                exp.intensity,
                exp.sigma,
                sigma_backcalc,
                sigma_fit,
                I_avg,
                I_fit,
                residual_sigma,
                wsum,
            ):
                writer.writerow([uniprot_id, qA, q0, ie, sig, sig_back, sig_fit, ic, iff, res, ws])

        with (outdir / "profile_weights.csv").open("w", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["profile", "weight"])
            for name, weight in zip(profile_names, weights):
                writer.writerow([name, weight])

        summary = {
            "uniprot_id": uniprot_id,
            "experimental_curve": str(exp_path),
            "ensemble_pdb": str(ensemble_path),
            "n_profiles": len(profile_names),
            "q_unit_experimental_detected_or_given": exp.source_q_unit,
            "q_range_A^-1": [float(np.nanmin(exp.q_A)), float(np.nanmax(exp.q_A))],
            "fit_mode": args.fit_mode,
            "scale": fit.scale,
            "offset": fit.offset,
            "chi2": fit.chi2,
            "chi2_per_point": fit.chi2_per_point,
            "chi2_reduced_dof": fit.chi2_reduced,
            "r_factor": diagnostics.r_factor,
            "r_factor_weighted": diagnostics.r_factor_weighted,
            "pearson_r": diagnostics.pearson_r,
            "rmse": diagnostics.rmse,
            "rmse_over_sigma": diagnostics.rmse_over_sigma,
            "chi2_p_value_approx": chi2_p_value,
            "significance_alpha": args.significance_alpha,
            "statistically_different_vs_experiment": statistically_different,
            "residual_runs": run_diag.n_runs,
            "residual_longest_run": run_diag.longest_run,
            "residual_longest_run_fraction": run_diag.longest_run_fraction,
            "residual_sign_balance": run_diag.sign_balance,
            "sigma_mode": args.sigma_mode,
            "n_points_used": fit.n_points,
            "n_fit_parameters": fit.n_params,
            "calc_i_col": args.calc_i_col,
            "calc_q_unit": args.calc_q_unit,
            "pepsi_grid_q_unit": args.pepsi_grid_q_unit,
            "pepsi_cmd_template": args.pepsi_cmd_template,
            "pepsi_extra": args.pepsi_extra,
        }
        with (outdir / "summary.json").open("w") as handle:
            json.dump(summary, handle, indent=2)

        try:
            import matplotlib.pyplot as plt
            good = np.isfinite(I_avg) & np.isfinite(I_fit) & np.isfinite(exp.intensity) & (exp.intensity > 0) & (I_fit > 0)
            fig = plt.figure(figsize=(7.0, 5.0))
            ax = fig.add_axes([0.12, 0.34, 0.84, 0.60])
            ax.errorbar(exp.q_A[good], exp.intensity[good], yerr=exp.sigma[good], fmt=".", markersize=3, label="Experiment")
            ax.plot(exp.q_A[good], I_fit[good], label="Ensemble fit")
            ax.set_yscale("log")
            ax.set_ylabel("I(q)")
            ax.set_title(f"{uniprot_id}: chi2/N={fit.chi2_per_point:.3g}, red chi2={fit.chi2_reduced:.3g}")
            ax.legend(frameon=False)
            axr = fig.add_axes([0.12, 0.11, 0.84, 0.18], sharex=ax)
            axr.axhline(0.0, linewidth=1)
            finite_res = np.isfinite(residual_sigma)
            axr.plot(exp.q_A[finite_res], residual_sigma[finite_res], ".-", markersize=3)
            axr.set_xlabel("q (Å$^{-1}$)")
            axr.set_ylabel("Δ/σ")
            axr.set_ylim(-5, 5)
            fig.savefig(outdir / "ensemble_saxs_fit.png", dpi=200)
            plt.close(fig)
        except Exception as exc:
            print(f"[WARN] Could not write plot for {uniprot_id}: {exc}", file=sys.stderr)


def extract_ids_from_filename(path: Path, id_regex: str) -> list[str]:
    rx = re.compile(id_regex)
    return sorted(set(m.group(0) for m in rx.finditer(path.name)))


def find_files(root: Path, glob_pattern: str, recursive: bool) -> list[Path]:
    return sorted([p for p in (root.rglob(glob_pattern) if recursive else root.glob(glob_pattern)) if p.is_file()])


def index_files_by_uniprot(files: list[Path], id_regex: str) -> tuple[dict[str, list[Path]], list[Path]]:
    by_id: dict[str, list[Path]] = {}
    no_id: list[Path] = []
    for f in files:
        ids = extract_ids_from_filename(f, id_regex)
        if not ids:
            no_id.append(f)
            continue
        for uid in ids:
            by_id.setdefault(uid, []).append(f)
    for uid in by_id:
        by_id[uid] = sorted(by_id[uid])
    return by_id, no_id


def sanitize_filename(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9_.-]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s[:180]


def resolve_pepsi_executable(pepsi_bin: str) -> str:
    candidate = pepsi_bin.strip()
    if not candidate:
        raise ValueError("--pepsi-bin cannot be empty when --run-pepsi is used.")

    # If the user passed a path, require that path to exist and be executable.
    if any(sep in candidate for sep in ("/", "\\")):
        path = Path(candidate).expanduser()
        if not path.exists():
            raise FileNotFoundError(f"Pepsi-SAXS executable path does not exist: {path}")
        if not path.is_file() or not os.access(path, os.X_OK):
            raise PermissionError(f"Pepsi-SAXS path is not executable: {path}")
        return str(path)

    resolved = shutil.which(candidate)
    if resolved:
        return resolved

    # Also support a local executable in the current working directory when the
    # user passes a bare command name such as "Pepsi-SAXS".
    local_path = Path.cwd() / candidate
    if local_path.exists() and local_path.is_file() and os.access(local_path, os.X_OK):
        return str(local_path.resolve())

    raise FileNotFoundError(
        f"Could not find Pepsi-SAXS executable '{candidate}' in PATH. "
        "Activate the environment that provides Pepsi-SAXS or pass --pepsi-bin /full/path/to/Pepsi-SAXS."
    )


def _safe_float_or_nan(value: object) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return math.nan


def _normalized_path_strings(path: Path, base_dir: Optional[Path] = None) -> list[str]:
    candidates: list[Path] = [path.expanduser()]
    if base_dir is not None and not path.is_absolute():
        candidates.append((base_dir / path).expanduser())

    out: list[str] = []
    for cand in candidates:
        try:
            key = str(cand.resolve())
        except Exception:
            key = str(cand)
        if key not in out:
            out.append(key)
    return out


def load_qc_screen_summary(path: Path) -> tuple[dict[str, dict[str, object]], dict[str, list[dict[str, object]]]]:
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"QC summary CSV does not exist: {path}")

    by_path: dict[str, dict[str, object]] = {}
    by_name: dict[str, list[dict[str, object]]] = {}

    with path.open("r", newline="", errors="replace") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            src = str(row.get("file", "")).strip()
            decision = str(row.get("decision", "")).strip().upper()
            if not src or not decision:
                continue

            rec: dict[str, object] = {
                "decision": decision,
                "q_useful_max_A": _safe_float_or_nan(row.get("q_useful_max_A")),
                "source_file": src,
            }

            src_path = Path(src)
            for key in _normalized_path_strings(src_path, base_dir=path.parent):
                by_path[key] = rec

            by_name.setdefault(src_path.name, []).append(rec)

    return by_path, by_name


def get_qc_entry_for_exp(exp_path: Path, args: argparse.Namespace) -> Optional[dict[str, object]]:
    by_path = getattr(args, "qc_screen_by_path", None)
    by_name = getattr(args, "qc_screen_by_name", None)
    if not by_path and not by_name:
        return None

    for key in _normalized_path_strings(exp_path):
        rec = by_path.get(key)
        if rec is not None:
            return rec

    name_matches = by_name.get(exp_path.name, [])
    if len(name_matches) == 1:
        return name_matches[0]
    return None


def build_batch_jobs(args: argparse.Namespace) -> tuple[list[TargetJob], list[dict[str, str]]]:
    exp_files = find_files(args.exp_dir, args.exp_glob, args.recursive)
    ensemble_files = find_files(args.ensemble_dir, args.ensemble_glob, args.recursive)
    report: list[dict[str, str]] = []
    if args.qc_screen_csv is not None:
        screened_exp_files: list[Path] = []
        for exp_path in exp_files:
            qc = get_qc_entry_for_exp(exp_path, args)
            if qc is None:
                if args.strict_qc_screen:
                    report.append(
                        {
                            "status": "qc_missing",
                            "uniprot_id": "",
                            "exp_file": str(exp_path),
                            "ensemble_file": "",
                            "message": "No row in QC screen CSV for this experimental file; skipping because --strict-qc-screen is set.",
                        }
                    )
                else:
                    screened_exp_files.append(exp_path)
                continue

            decision = str(qc.get("decision", "")).upper()
            if decision in {"PASS", "PASS_TAIL_NOISY", "CROP"}:
                screened_exp_files.append(exp_path)
            else:
                report.append(
                    {
                        "status": "qc_excluded",
                        "uniprot_id": "",
                        "exp_file": str(exp_path),
                        "ensemble_file": "",
                        "message": f"Excluded by QC decision={decision}.",
                    }
                )

        exp_files = screened_exp_files

    exp_by_id, exp_no_id = index_files_by_uniprot(exp_files, args.id_regex)
    ens_by_id, ens_no_id = index_files_by_uniprot(ensemble_files, args.id_regex)

    all_ids = sorted(set(exp_by_id) | set(ens_by_id))
    jobs: list[TargetJob] = []

    for uid in all_ids:
        efiles = exp_by_id.get(uid, [])
        pfiles = ens_by_id.get(uid, [])
        if not efiles:
            for p in pfiles:
                report.append({"status": "missing_exp", "uniprot_id": uid, "exp_file": "", "ensemble_file": str(p), "message": "No experimental .dat matched this UniProt ID."})
            continue
        if not pfiles:
            for e in efiles:
                report.append({"status": "missing_ensemble", "uniprot_id": uid, "exp_file": str(e), "ensemble_file": "", "message": "No ensemble PDB matched this UniProt ID."})
            continue
        selected_pfiles = pfiles if args.all_ensemble_matches else pfiles[:1]
        if len(pfiles) > 1 and not args.all_ensemble_matches:
            report.append({"status": "multiple_ensembles_using_first", "uniprot_id": uid, "exp_file": ";".join(map(str, efiles)), "ensemble_file": ";".join(map(str, pfiles)), "message": f"Using first sorted ensemble only: {pfiles[0]}"})
        for exp_path in efiles:
            for ensemble_path in selected_pfiles:
                leaf = sanitize_filename(f"{uid}__{exp_path.stem}__{ensemble_path.stem}")
                jobs.append(TargetJob(uid, exp_path, ensemble_path, args.outdir / leaf))

    for p in exp_no_id:
        report.append({"status": "no_uniprot_id_in_exp_filename", "uniprot_id": "", "exp_file": str(p), "ensemble_file": "", "message": "Could not extract UniProt accession from experimental filename."})
    for p in ens_no_id:
        report.append({"status": "no_uniprot_id_in_ensemble_filename", "uniprot_id": "", "exp_file": "", "ensemble_file": str(p), "message": "Could not extract UniProt accession from ensemble filename."})
    return jobs, report


def process_one_job(job: TargetJob, args: argparse.Namespace) -> TargetSummary:
    try:
        job.outdir.mkdir(parents=True, exist_ok=True)
        q_max_A = args.q_max_A
        success_message = ""

        qc = get_qc_entry_for_exp(job.exp_path, args)
        if qc is not None and str(qc.get("decision", "")).upper() == "CROP":
            q_useful_max_A = _safe_float_or_nan(qc.get("q_useful_max_A"))
            if np.isfinite(q_useful_max_A) and q_useful_max_A > 0:
                q_max_A = q_useful_max_A if q_max_A is None else min(float(q_max_A), q_useful_max_A)
                success_message = f"QC CROP applied: q_max_A={q_max_A:.6g}"

        exp = read_experimental_curve(job.exp_path, q_unit=args.exp_q_unit, q_min_A=args.q_min_A, q_max_A=q_max_A)
        split_dir = job.outdir / "split_models"
        model_paths = split_multimodel_pdb(job.ensemble_path, split_dir, overwrite=args.force, max_models=args.max_models)
        exp_grid = job.outdir / f"experimental_grid_for_pepsi_{_norm_unit(args.pepsi_grid_q_unit)}.dat"
        write_exp_grid_for_pepsi(exp, exp_grid, q_unit=args.pepsi_grid_q_unit)

        if args.run_pepsi:
            profile_paths = run_pepsi_all(
                model_paths=model_paths,
                outdir=job.outdir,
                exp_grid=exp_grid,
                pepsi_bin=args.pepsi_bin,
                cmd_template=args.pepsi_cmd_template,
                pepsi_extra=args.pepsi_extra,
                workers=max(args.workers, 1),
                force=args.force,
            )
        else:
            profiles_dir = args.profiles_dir / job.uniprot_id if args.profiles_dir else job.outdir / "profiles"
            profile_paths = sorted(p for p in profiles_dir.glob(args.profile_glob) if p.is_file())
            if not profile_paths:
                raise FileNotFoundError(f"No precomputed profiles found in {profiles_dir} matching {args.profile_glob}")

        profile_matrix, profile_names = interpolate_profiles_to_exp(profile_paths, exp.q_A, args.calc_i_col, args.calc_q_unit)
        weights = load_weights(args.weights, n=len(profile_paths))
        I_avg, wsum = weighted_mean_profiles(profile_matrix, weights)
        sigma_backcalc = weighted_profile_std(profile_matrix, weights, I_avg)
        sigma_backcalc = np.where(np.isfinite(sigma_backcalc), sigma_backcalc, 0.0)
        sigma_backcalc = np.maximum(sigma_backcalc, float(args.backcalc_sigma_floor))

        if args.sigma_mode == "exp":
            sigma_fit = exp.sigma.copy()
        elif args.sigma_mode == "exp_plus_backcalc":
            sigma_fit = np.sqrt(exp.sigma ** 2 + sigma_backcalc ** 2)
        else:
            raise ValueError("--sigma-mode must be 'exp' or 'exp_plus_backcalc'.")

        usable = np.isfinite(I_avg) & np.isfinite(exp.intensity) & np.isfinite(sigma_fit) & (sigma_fit > 0)
        if usable.sum() < 3:
            raise ValueError(f"Only {usable.sum()} usable q points after interpolation.")
        fit = fit_scale_offset(exp.intensity[usable], sigma_fit[usable], I_avg[usable], args.fit_mode)
        I_fit_usable = fit.scale * I_avg[usable] + fit.offset
        diagnostics = compute_fit_diagnostics(exp.intensity[usable], sigma_fit[usable], I_fit_usable)
        run_diag = compute_residual_run_diagnostics((I_fit_usable - exp.intensity[usable]) / sigma_fit[usable])
        dof = max(fit.n_points - fit.n_params, 1)
        chi2_p_value = chi2_pvalue_upper_approx(fit.chi2, dof)
        statistically_different = bool(chi2_p_value < args.significance_alpha) if np.isfinite(chi2_p_value) else None

        I_avg_out = np.full_like(exp.intensity, np.nan, dtype=float)
        I_avg_out[usable] = I_avg[usable]
        wsum_out = np.zeros_like(exp.intensity, dtype=float)
        wsum_out[usable] = wsum[usable]
        sigma_fit_out = np.full_like(exp.intensity, np.nan, dtype=float)
        sigma_fit_out[usable] = sigma_fit[usable]
        sigma_backcalc_out = np.full_like(exp.intensity, np.nan, dtype=float)
        sigma_backcalc_out[usable] = sigma_backcalc[usable]

        rg_exp_fit_nm = estimate_rg_guinier_nm(exp.q_A, exp.intensity)
        rg_calc_nm = estimate_rg_guinier_nm(exp.q_A[usable], I_avg[usable])
        rg_exp_min = math.nan
        rg_exp_max = math.nan
        rg_map = getattr(args, "experimental_rg_map", {})
        if job.uniprot_id in rg_map:
            rg_exp_min, rg_exp_max = rg_map[job.uniprot_id]
            rg_exp_nm = 0.5 * (rg_exp_min + rg_exp_max)
        else:
            rg_exp_nm = rg_exp_fit_nm

        write_per_target_outputs(
            job.outdir,
            exp,
            I_avg_out,
            wsum_out,
            fit,
            diagnostics,
            run_diag,
            chi2_p_value,
            statistically_different,
            sigma_fit_out,
            sigma_backcalc_out,
            profile_names,
            weights,
            args,
            job.uniprot_id,
            job.exp_path,
            job.ensemble_path,
        )

        return TargetSummary(
            status="ok", uniprot_id=job.uniprot_id, exp_file=str(job.exp_path), ensemble_file=str(job.ensemble_path), outdir=str(job.outdir),
            n_models=len(model_paths), n_profiles=len(profile_paths), n_points=fit.n_points, scale=fit.scale, offset=fit.offset,
            chi2=fit.chi2, chi2_per_point=fit.chi2_per_point, chi2_reduced=fit.chi2_reduced,
            r_factor=diagnostics.r_factor, r_factor_weighted=diagnostics.r_factor_weighted,
            pearson_r=diagnostics.pearson_r, rmse=diagnostics.rmse, rmse_over_sigma=diagnostics.rmse_over_sigma,
            chi2_p_value=chi2_p_value, statistically_different=statistically_different,
            n_runs=float(run_diag.n_runs), longest_run=float(run_diag.longest_run), longest_run_fraction=run_diag.longest_run_fraction, sign_balance=run_diag.sign_balance,
            q_min_A=float(np.nanmin(exp.q_A)), q_max_A=float(np.nanmax(exp.q_A)),
            rg_nm=rg_calc_nm, rg_exp=rg_exp_nm, rg_exp_min=rg_exp_min, rg_exp_max=rg_exp_max,
            message=success_message,
        )
    except Exception as exc:
        job.outdir.mkdir(parents=True, exist_ok=True)
        with (job.outdir / "error_traceback.txt").open("w") as handle:
            traceback.print_exc(file=handle)
        return TargetSummary(status="failed", uniprot_id=job.uniprot_id, exp_file=str(job.exp_path), ensemble_file=str(job.ensemble_path), outdir=str(job.outdir), message=f"{type(exc).__name__}: {exc}")


def write_match_report(outdir: Path, jobs: list[TargetJob], report_rows: list[dict[str, str]]) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    fieldnames = ["status", "uniprot_id", "exp_file", "ensemble_file", "message"]
    with (outdir / "batch_match_report.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for job in jobs:
            writer.writerow({"status": "matched", "uniprot_id": job.uniprot_id, "exp_file": str(job.exp_path), "ensemble_file": str(job.ensemble_path), "message": str(job.outdir)})
        for row in report_rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})


def write_batch_summary(outdir: Path, summaries: list[TargetSummary]) -> None:
    fieldnames = [
        "status", "uniprot_id", "exp_file", "ensemble_file", "outdir", "n_models", "n_profiles", "n_points", "q_min_A", "q_max_A",
        "scale", "offset", "chi2", "chi2_per_point", "chi2_reduced", "chi2_p_value", "statistically_different",
        "r_factor", "r_factor_weighted", "pearson_r", "rmse", "rmse_over_sigma",
        "rg_nm", "rg_exp", "rg_exp_min", "rg_exp_max",
        "n_runs", "longest_run", "longest_run_fraction", "sign_balance", "message",
    ]
    with (outdir / "batch_summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for s in summaries:
            writer.writerow({k: getattr(s, k) for k in fieldnames})


def write_batch_markdown_summary(outdir: Path, summaries: list[TargetSummary]) -> None:
    ok = [s for s in summaries if s.status == "ok"]
    failed = [s for s in summaries if s.status != "ok"]
    lines = ["# Batch ensemble SAXS χ² summary\n", f"- Successful fits: {len(ok)}", f"- Failed fits: {len(failed)}\n"]
    if ok:
        lines += [
            "| UniProt | Rg(exp) nm | Rg(calc) nm | ΔRg nm | χ²/N | reduced χ² | p-value | significantly different | R-factor | weighted R-factor | Pearson r | longest sign-run frac | N q-points | models | exp file | fit plot |",
            "|---|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---|---|",
        ]
        for s in sorted(ok, key=lambda x: x.chi2_per_point):
            plot_path = Path(s.outdir) / "ensemble_saxs_fit.png"
            sig_text = "yes" if s.statistically_different is True else ("no" if s.statistically_different is False else "n/a")
            delta_rg = s.rg_nm - s.rg_exp if np.isfinite(s.rg_nm) and np.isfinite(s.rg_exp) else math.nan
            lines.append(
                f"| {s.uniprot_id} | {s.rg_exp:.4g} | {s.rg_nm:.4g} | {delta_rg:.4g} | {s.chi2_per_point:.4g} | {s.chi2_reduced:.4g} | {s.chi2_p_value:.3g} | {sig_text} | {s.r_factor:.4g} | {s.r_factor_weighted:.4g} | {s.pearson_r:.4g} | {s.longest_run_fraction:.4g} | {s.n_points} | {s.n_models} | "
                f"{Path(s.exp_file).name} | {plot_path} |"
            )
        lines.append("")
    if failed:
        lines.append("## Failed")
        for s in failed:
            lines.append(f"- **{s.uniprot_id}** {Path(s.exp_file).name}: {s.message}")
    (outdir / "batch_summary.md").write_text("\n".join(lines))


def write_batch_chi2_plot(outdir: Path, summaries: list[TargetSummary]) -> None:
    ok = [s for s in summaries if s.status == "ok" and np.isfinite(s.chi2_per_point) and np.isfinite(s.chi2_reduced)]
    if not ok:
        return

    try:
        import matplotlib.pyplot as plt

        sorted_ok = sorted(ok, key=lambda s: s.chi2_per_point)
        labels = [s.uniprot_id for s in sorted_ok]
        chi2_n = np.asarray([s.chi2_per_point for s in sorted_ok], dtype=float)
        chi2_red = np.asarray([s.chi2_reduced for s in sorted_ok], dtype=float)
        x = np.arange(len(sorted_ok), dtype=float)

        fig = plt.figure(figsize=(max(8.0, 0.9 * len(sorted_ok)), 5.0))
        ax = fig.add_axes([0.08, 0.22, 0.88, 0.72])
        width = 0.4
        ax.bar(x - width / 2.0, chi2_n, width=width, label="χ²/N")
        ax.bar(x + width / 2.0, chi2_red, width=width, label="reduced χ²")
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=45, ha="right")
        ax.set_ylabel("Fit statistic")
        ax.set_title("Batch SAXS fit quality per target")
        ax.legend(frameon=False)
        fig.savefig(outdir / "batch_chi2_overview.png", dpi=200)
        plt.close(fig)
    except Exception as exc:
        print(f"[WARN] Could not write batch chi2 plot: {exc}", file=sys.stderr)


def write_batch_sanity_multiplot(outdir: Path, summaries: list[TargetSummary]) -> None:
    ok = [s for s in summaries if s.status == "ok"]
    if not ok:
        return

    try:
        import matplotlib.pyplot as plt

        n = len(ok)
        ncols = min(3, n)
        nrows = (n + ncols - 1) // ncols
        fig, axes = plt.subplots(nrows, ncols, figsize=(5.2 * ncols, 3.8 * nrows), squeeze=False)

        for idx, s in enumerate(sorted(ok, key=lambda x: x.uniprot_id)):
            r = idx // ncols
            c = idx % ncols
            ax = axes[r][c]
            fit_csv = Path(s.outdir) / "ensemble_saxs_fit.csv"
            q_vals: list[float] = []
            ie_vals: list[float] = []
            sig_vals: list[float] = []
            ifit_vals: list[float] = []
            with fit_csv.open("r", newline="") as handle:
                reader = csv.DictReader(handle)
                for row in reader:
                    try:
                        q_vals.append(float(row.get("q_A^-1", "nan")))
                        ie_vals.append(float(row.get("I_exp", "nan")))
                        sig_vals.append(float(row.get("sigma_fit", "nan")))
                        ifit_vals.append(float(row.get("I_calc_ensemble_fit", "nan")))
                    except ValueError:
                        continue

            q = np.asarray(q_vals, dtype=float)
            I_exp = np.asarray(ie_vals, dtype=float)
            sigma = np.asarray(sig_vals, dtype=float)
            I_fit = np.asarray(ifit_vals, dtype=float)

            good = np.isfinite(q) & np.isfinite(I_exp) & np.isfinite(sigma) & np.isfinite(I_fit) & (I_exp > 0) & (I_fit > 0)
            if np.any(good):
                ax.errorbar(q[good], I_exp[good], yerr=sigma[good], fmt=".", markersize=2.5, linewidth=0.6, label="exp")
                ax.plot(q[good], I_fit[good], linewidth=1.2, label="fit")
                ax.set_yscale("log")
            ax.set_title(f"{s.uniprot_id}  χ²/N={s.chi2_per_point:.3g}  Rw={s.r_factor_weighted:.3g}")
            ax.set_xlabel("q (A^-1)")
            ax.set_ylabel("I(q)")
            ax.legend(frameon=False, fontsize=8)

        for idx in range(n, nrows * ncols):
            r = idx // ncols
            c = idx % ncols
            axes[r][c].axis("off")

        fig.tight_layout()
        fig.savefig(outdir / "batch_sanity_multiplot.png", dpi=220)
        plt.close(fig)
    except Exception as exc:
        print(f"[WARN] Could not write batch sanity multiplot: {exc}", file=sys.stderr)


def write_batch_residual_sign_plot(outdir: Path, summaries: list[TargetSummary]) -> None:
    ok = [s for s in summaries if s.status == "ok"]
    if not ok:
        return

    try:
        import matplotlib.pyplot as plt

        sorted_ok = sorted(ok, key=lambda x: x.uniprot_id)
        fig = plt.figure(figsize=(10.0, max(4.0, 0.8 * len(sorted_ok))))
        ax = fig.add_axes([0.10, 0.12, 0.86, 0.82])

        for i, s in enumerate(sorted_ok):
            fit_csv = Path(s.outdir) / "ensemble_saxs_fit.csv"
            q_vals: list[float] = []
            res_vals: list[float] = []
            with fit_csv.open("r", newline="") as handle:
                reader = csv.DictReader(handle)
                for row in reader:
                    try:
                        q_vals.append(float(row.get("q_A^-1", "nan")))
                        res_vals.append(float(row.get("residual_over_sigma", "nan")))
                    except ValueError:
                        continue

            q = np.asarray(q_vals, dtype=float)
            res = np.asarray(res_vals, dtype=float)
            good = np.isfinite(q) & np.isfinite(res)
            if not np.any(good):
                continue

            qg = q[good]
            sign = np.sign(res[good])
            pos = sign > 0
            neg = sign < 0

            y = np.full_like(qg, i, dtype=float)
            ax.scatter(qg[pos], y[pos], s=6, marker="s", color="#d95f02", label="+" if i == 0 else None)
            ax.scatter(qg[neg], y[neg], s=6, marker="s", color="#1b9e77", label="-" if i == 0 else None)

        ax.set_yticks(np.arange(len(sorted_ok), dtype=float))
        ax.set_yticklabels([f"{s.uniprot_id} (longest={s.longest_run:.0f})" for s in sorted_ok])
        ax.set_xlabel("q (A^-1)")
        ax.set_title("Residual sign consistency (CorMap-inspired): contiguous color patches indicate structured mismatch")
        ax.legend(frameon=False, loc="upper right")
        fig.savefig(outdir / "batch_residual_sign_map.png", dpi=220)
        plt.close(fig)
    except Exception as exc:
        print(f"[WARN] Could not write residual sign map: {exc}", file=sys.stderr)


def write_batch_fit_scatter_plot(outdir: Path, summaries: list[TargetSummary]) -> None:
    """
    Two-panel fit summary across targets.

    Left panel: Pearson r delta from ideal (1 - r).
    Right panel: actual reduced chi^2 values.
    """
    ok = [
        s for s in summaries
        if s.status == "ok" and np.isfinite(s.pearson_r) and np.isfinite(s.chi2_reduced)
    ]
    if not ok:
        return

    try:
        import matplotlib.pyplot as plt

        sorted_ok = sorted(ok, key=lambda s: (s.uniprot_id,))
        labels = [s.uniprot_id for s in sorted_ok]
        pearson_r = np.asarray([s.pearson_r for s in sorted_ok], dtype=float)
        chi2_red = np.asarray([s.chi2_reduced for s in sorted_ok], dtype=float)
        delta_r = 1.0 - pearson_r
        x = np.arange(len(sorted_ok), dtype=float)

        # Heuristic "bad fit" guide lines.
        # Pearson r threshold r < 0.95 -> delta_r > 0.05.
        # Reduced chi^2 threshold: chi^2_red > 5.
        bad_delta_r = 0.05
        bad_chi2_red = 5.0

        fig, (ax_r, ax_c) = plt.subplots(2, 1, figsize=(max(11.0, 0.45 * len(sorted_ok)), 8.2), sharex=True)

        ax_r.bar(x, delta_r, width=0.72, color="#1f77b4", alpha=0.9)
        ax_r.axhline(0.0, linestyle="--", linewidth=1.0, color="0.45", label="ideal Δr=0")
        ax_r.axhline(bad_delta_r, linestyle=":", linewidth=1.2, color="#c44e52", label="bad-fit threshold")
        ax_r.set_ylabel("Δr = 1 - r")
        ax_r.set_title("Pearson r delta")
        ax_r.grid(True, axis="y", linestyle=":", linewidth=0.6, alpha=0.6)
        ax_r.legend(frameon=False, loc="best")

        ax_c.bar(x, chi2_red, width=0.72, color="#d62728", alpha=0.9)
        ax_c.axhline(bad_chi2_red, linestyle="--", linewidth=1.2, color="#c44e52", label="bad-fit threshold (χ²red=5)")
        ax_c.set_ylabel("χ²red")
        ax_c.set_xlabel("UniProt ID")
        ax_c.set_title("Reduced χ²")
        ax_c.grid(True, axis="y", linestyle=":", linewidth=0.6, alpha=0.6)
        ax_c.legend(frameon=False, loc="best")

        # Keep ideal value 0 near the top of each panel for visual ranking.
        r_low = min(float(np.nanmin(delta_r)) if delta_r.size else 0.0, bad_delta_r, 0.0)
        r_high = max(float(np.nanmax(delta_r)) if delta_r.size else 0.0, bad_delta_r, 0.0)

        r_span = max(r_high - r_low, 1e-6)

        # Pearson panel: keep ideal 0 near the top while showing full bars.
        # Inverted y-axis makes larger deltas extend downward from the ideal baseline.
        r_top = r_low - 0.08 * r_span
        r_bottom = r_high + 0.12 * r_span
        c_top = max(float(np.nanmax(chi2_red)) if chi2_red.size else 0.0, bad_chi2_red)
        c_top = c_top * 1.12 if c_top > 0.0 else 1.0
        ax_r.set_ylim(r_bottom, r_top)
        ax_c.set_ylim(0.0, c_top)

        ax_c.set_xticks(x)
        ax_c.set_xticklabels(labels, rotation=55, ha="right", fontsize=8)

        fig.suptitle("Batch fit-quality summary (back-calculated vs experimental SAXS)", y=0.99)
        fig.tight_layout(rect=[0.0, 0.0, 1.0, 0.97])
        fig.savefig(outdir / "batch_fit_scatter_summary.png", dpi=220)
        plt.close(fig)
    except Exception as exc:
        print(f"[WARN] Could not write batch fit scatter plot: {exc}", file=sys.stderr)


def write_rg_summary(outdir: Path, summaries: list[TargetSummary]) -> None:
    """
    Generate a summary of back-calculated vs experimental Rg values.

    Outputs:
    - A CSV file summarizing Rg values.
    - A scatter plot comparing back-calculated and experimental Rg values.
    """
    import matplotlib.pyplot as plt

    # Filter summaries with valid Rg values
    valid_summaries = [
        s for s in summaries
        if s.status == "ok" and np.isfinite(s.rg_nm) and np.isfinite(s.rg_exp)
    ]

    if not valid_summaries:
        print("[INFO] No valid Rg values found for summary.")
        return

    # Prepare data for CSV and plotting
    uniprot_ids = [s.uniprot_id for s in valid_summaries]
    experimental_rgs = [s.rg_exp for s in valid_summaries]
    calculated_rgs = [s.rg_nm for s in valid_summaries]
    rg_min_vals = [s.rg_exp_min for s in valid_summaries]
    rg_max_vals = [s.rg_exp_max for s in valid_summaries]

    # Write CSV summary
    csv_path = outdir / "rg_summary.csv"
    with csv_path.open("w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([
            "uniprot_id", "rg_exp_nm", "rg_calc_nm", "delta_nm", "delta_pct", "rg_exp_min_nm", "rg_exp_max_nm"
        ])
        for uid, exp_rg, calc_rg, rg_min, rg_max in zip(uniprot_ids, experimental_rgs, calculated_rgs, rg_min_vals, rg_max_vals):
            delta_nm = calc_rg - exp_rg
            delta_pct = 100.0 * delta_nm / exp_rg if exp_rg != 0 else math.nan
            writer.writerow([uid, exp_rg, calc_rg, delta_nm, delta_pct, rg_min, rg_max])

    # Generate scatter plot
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(experimental_rgs, calculated_rgs, color="#1f77b4", alpha=0.8, label="Targets")
    ax.plot([min(experimental_rgs), max(experimental_rgs)],
            [min(experimental_rgs), max(experimental_rgs)],
            linestyle="--", color="0.5", label="y=x (ideal)")
    ax.set_xlabel("Experimental Rg (nm)")
    ax.set_ylabel("Calculated Rg (nm)")
    ax.set_title("Back-calculated vs Experimental Rg")
    ax.legend(frameon=False)
    ax.grid(True, linestyle=":", linewidth=0.6, alpha=0.7)

    # Save plot
    plot_path = outdir / "rg_comparison.png"
    fig.tight_layout()
    fig.savefig(plot_path, dpi=220)
    plt.close(fig)

    print(f"[INFO] Rg summary written to {csv_path}")
    print(f"[INFO] Rg comparison plot saved to {plot_path}")


def parse_experimental_rgs(file_path: Path) -> dict[str, tuple[float, float]]:
    """
    Parse experimental Rg values from a file.

    Args:
        file_path: Path to the file containing experimental Rg data.

    Returns:
        A dictionary mapping UniProt IDs to (min Rg, max Rg).
    """
    rg_data: dict[str, tuple[float, float]] = {}
    if not file_path.exists():
        return rg_data
    with file_path.open("r", errors="replace") as handle:
        for line in handle:
            stripped = line.strip()
            if not stripped:
                continue
            m_uid = re.search(DEFAULT_UNIPROT_REGEX, stripped)
            m_rg = re.search(r"Rg\s*=\s*([0-9]+(?:\.[0-9]+)?)(?:\s*-\s*([0-9]+(?:\.[0-9]+)?))?\s*nm", stripped, flags=re.IGNORECASE)
            if not m_uid or not m_rg:
                continue
            uniprot_id = m_uid.group(0).upper()
            rg_min = float(m_rg.group(1))
            rg_max = float(m_rg.group(2)) if m_rg.group(2) is not None else rg_min
            rg_data[uniprot_id] = (rg_min, rg_max)
    return rg_data


def estimate_rg_guinier_nm(q_A: np.ndarray, intensity: np.ndarray) -> float:
    """Estimate Rg in nm from low-q Guinier fit: ln(I)=ln(I0)-Rg^2*q^2/3."""
    good = np.isfinite(q_A) & np.isfinite(intensity) & (q_A > 0) & (intensity > 0)
    q = q_A[good]
    I = intensity[good]
    if q.size < 6:
        return math.nan
    n = min(25, max(6, int(0.25 * q.size)))
    q_fit = q[:n]
    I_fit = I[:n]
    x = q_fit ** 2
    y = np.log(I_fit)
    A = np.column_stack([x, np.ones_like(x)])
    beta, *_ = np.linalg.lstsq(A, y, rcond=None)
    slope = float(beta[0])
    rg2_A2 = -3.0 * slope
    if not np.isfinite(rg2_A2) or rg2_A2 <= 0:
        return math.nan
    return float(math.sqrt(rg2_A2) * 0.1)

def print_dry_run(jobs: list[TargetJob], report_rows: list[dict[str, str]]) -> None:
    print("\n=== DRY RUN: matched jobs ===")
    for job in jobs:
        print(f"{job.uniprot_id}\n  exp:      {job.exp_path}\n  ensemble: {job.ensemble_path}\n  outdir:   {job.outdir}")
    print(f"\nMatched jobs: {len(jobs)}")
    if report_rows:
        print("\n=== DRY RUN: unmatched / issues ===")
        for row in report_rows:
            print(f"{row.get('status','')}: {row.get('uniprot_id','')}\n  exp:      {row.get('exp_file','')}\n  ensemble: {row.get('ensemble_file','')}\n  message:  {row.get('message','')}")


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Batch Pepsi-SAXS ensemble-average chi^2 analysis against SASBDB .dat files.", formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--exp-dir", type=Path, required=True, help="Directory containing SASBDB experimental .dat files.")
    p.add_argument("--ensemble-dir", type=Path, required=True, help="Directory containing multi-model ensemble PDB files.")
    p.add_argument("--outdir", type=Path, required=True, help="Batch output directory.")
    p.add_argument("--exp-glob", default="*.dat", help="Glob for experimental files.")
    p.add_argument("--ensemble-glob", default="*.pdb", help="Glob for ensemble PDB files.")
    p.add_argument("--recursive", action="store_true", help="Search input directories recursively.")
    p.add_argument("--id-regex", default=DEFAULT_UNIPROT_REGEX, help="Regex used to extract UniProt IDs from filenames.")
    p.add_argument("--all-ensemble-matches", action="store_true", help="If multiple ensemble files match one UniProt ID, process all instead of using the first sorted file.")
    p.add_argument("--dry-run", action="store_true", help="Only print and write matching report; do not run Pepsi-SAXS.")
    p.add_argument("--exp-q-unit", choices=["auto", "A", "nm"], default="auto", help="Experimental q/s unit.")
    p.add_argument(
        "--qc-screen-csv",
        type=Path,
        default=Path("../Revision/experimental/saxs_qc_summary_n12.csv"),
        help="QC summary CSV from screen_saxs_errors.py. Keeps PASS/PASS_TAIL_NOISY/CROP and excludes REJECT/ERROR.",
    )
    p.add_argument(
        "--no-qc-screen-csv",
        action="store_true",
        help="Disable QC-screen filtering and process all matching experimental files.",
    )
    p.add_argument(
        "--strict-qc-screen",
        action="store_true",
        help="If set, skip experimental files missing from --qc-screen-csv. Otherwise, missing files are kept.",
    )
    p.add_argument("--calc-q-unit", choices=["A", "nm"], default="A", help="q unit in Pepsi calculated output profiles.")
    p.add_argument("--pepsi-grid-q-unit", choices=["A", "nm"], default="A", help="q unit written to data grid passed to Pepsi.")
    p.add_argument("--q-min-A", type=float, default=None, help="Minimum q in Å^-1 after unit conversion.")
    p.add_argument("--q-max-A", type=float, default=None, help="Maximum q in Å^-1 after unit conversion.")
    p.add_argument("--run-pepsi", action="store_true", help="Run Pepsi-SAXS for each conformer.")
    p.add_argument("--pepsi-bin", default="./Pepsi-SAXS", help="Path/name of Pepsi-SAXS executable.")
    p.add_argument("--pepsi-cmd-template", default="{pepsi_bin} {pdb} {exp_grid} -o {out_curve} {extra}", help="Shell command template. Placeholders: {pepsi_bin}, {pdb}, {exp_grid}, {exp_dat}, {out_curve}, {out_prefix}, {extra}.")
    p.add_argument("--pepsi-extra", default="", help="Extra Pepsi-SAXS flags inserted into {extra}.")
    p.add_argument("--workers", type=int, default=1, help="Parallel Pepsi-SAXS subprocesses per target.")
    p.add_argument("--force", action="store_true", help="Overwrite/recompute split models and profiles.")
    p.add_argument("--max-models", type=int, default=None, help="For testing, process only first N models per ensemble.")
    p.add_argument("--profiles-dir", type=Path, default=None, help="Optional precomputed profiles root. Without --run-pepsi, profiles are expected in --profiles-dir/UNIPROT_ID/*.dat, or in each target outdir/profiles if omitted.")
    p.add_argument("--profile-glob", default="*.dat", help="Glob for precomputed calculated profiles.")
    p.add_argument("--calc-i-col", default="auto", help="Calculated intensity column in Pepsi/profile files, 1-based, or auto.")
    p.add_argument("--fit-mode", choices=["scale", "scale_offset"], default="scale_offset")
    p.add_argument("--weights", type=Path, default=None, help="Optional conformer weights file, one weight per profile.")
    p.add_argument(
        "--sigma-mode",
        choices=["exp", "exp_plus_backcalc"],
        default="exp_plus_backcalc",
        help="Sigma used in fitting: experimental only, or sqrt(exp^2 + backcalc^2).",
    )
    p.add_argument(
        "--backcalc-sigma-floor",
        type=float,
        default=0.0,
        help="Minimum back-calculator sigma contribution added per q-point before sigma combination.",
    )
    p.add_argument(
        "--significance-alpha",
        type=float,
        default=0.05,
        help="Alpha threshold used to label fit as statistically different from experiment based on chi-square p-value.",
    )
    p.add_argument("--target-workers", type=int, default=1, help="Number of UniProt/experiment/ensemble targets to process in parallel. Usually keep this 1 if --workers is already >1.")
    p.add_argument("--stop-on-error", action="store_true", help="Stop batch immediately on first failed target.")
    p.add_argument(
        "--experimental-rg-file",
        type=Path,
        default=Path("./sasbdb_hits/sasbdb_final.txt"),
        help="Optional file containing experimental Rg per UniProt (e.g., 'P12345, SASXXXX, Rg = 4.0-4.4nm').",
    )
    return p


def main() -> int:
    args = build_arg_parser().parse_args()
    if not args.exp_dir.is_dir():
        raise NotADirectoryError(args.exp_dir)
    if not args.ensemble_dir.is_dir():
        raise NotADirectoryError(args.ensemble_dir)

    if args.no_qc_screen_csv:
        args.qc_screen_csv = None

    if args.run_pepsi:
        try:
            args.pepsi_bin = resolve_pepsi_executable(args.pepsi_bin)
            print(f"[INFO] Using Pepsi-SAXS executable: {args.pepsi_bin}")
        except Exception as exc:
            print(f"[ERROR] {exc}", file=sys.stderr)
            return 2

    args.outdir.mkdir(parents=True, exist_ok=True)

    if args.qc_screen_csv is not None:
        try:
            args.qc_screen_by_path, args.qc_screen_by_name = load_qc_screen_summary(args.qc_screen_csv)
            print(f"[INFO] Loaded QC summary entries: {len(args.qc_screen_by_path)} from {args.qc_screen_csv}")
        except Exception as exc:
            print(f"[ERROR] Could not load --qc-screen-csv: {exc}", file=sys.stderr)
            return 2
    else:
        args.qc_screen_by_path = {}
        args.qc_screen_by_name = {}
        if args.no_qc_screen_csv:
            print("[INFO] QC-screen filtering disabled; using all matched experimental files.")

    args.experimental_rg_map = parse_experimental_rgs(args.experimental_rg_file)
    if args.experimental_rg_map:
        print(f"[INFO] Loaded experimental Rg entries: {len(args.experimental_rg_map)} from {args.experimental_rg_file}")
    else:
        print(f"[WARN] No experimental Rg entries loaded from {args.experimental_rg_file}; using Guinier-estimated Rg from .dat curves.")

    jobs, report_rows = build_batch_jobs(args)
    write_match_report(args.outdir, jobs, report_rows)
    if args.dry_run:
        print_dry_run(jobs, report_rows)
        print(f"\nWrote match report: {args.outdir / 'batch_match_report.csv'}")
        return 0
    if not jobs:
        print("[ERROR] No matched jobs. Check filenames, --id-regex, --exp-glob, and --ensemble-glob.", file=sys.stderr)
        print(f"Match report: {args.outdir / 'batch_match_report.csv'}", file=sys.stderr)
        return 2
    if not args.run_pepsi and args.profiles_dir is None:
        print("[WARN] --run-pepsi was not set and --profiles-dir was not provided. Looking under each target outdir/profiles.", file=sys.stderr)

    summaries: list[TargetSummary] = []
    print(f"[INFO] Matched jobs: {len(jobs)}")
    print(f"[INFO] Match report: {args.outdir / 'batch_match_report.csv'}")

    if args.target_workers <= 1:
        for i, job in enumerate(jobs, start=1):
            print(f"[INFO] [{i}/{len(jobs)}] {job.uniprot_id}: {job.exp_path.name} vs {job.ensemble_path.name}")
            summary = process_one_job(job, args)
            summaries.append(summary)
            print(f"[INFO]    {summary.status}: chi2/N={summary.chi2_per_point:.6g} red_chi2={summary.chi2_reduced:.6g} {summary.message}")
            write_batch_summary(args.outdir, summaries)
            write_batch_markdown_summary(args.outdir, summaries)
            if summary.status != "ok" and args.stop_on_error:
                return 1
    else:
        with futures.ThreadPoolExecutor(max_workers=args.target_workers) as ex:
            future_to_job = {ex.submit(process_one_job, job, args): job for job in jobs}
            for fut in futures.as_completed(future_to_job):
                job = future_to_job[fut]
                summary = fut.result()
                summaries.append(summary)
                print(f"[INFO] {job.uniprot_id}: {summary.status} chi2/N={summary.chi2_per_point:.6g} red_chi2={summary.chi2_reduced:.6g} {summary.message}")
                write_batch_summary(args.outdir, summaries)
                write_batch_markdown_summary(args.outdir, summaries)
                if summary.status != "ok" and args.stop_on_error:
                    return 1

    write_batch_summary(args.outdir, summaries)
    write_batch_markdown_summary(args.outdir, summaries)
    write_batch_chi2_plot(args.outdir, summaries)
    write_batch_sanity_multiplot(args.outdir, summaries)
    write_batch_residual_sign_plot(args.outdir, summaries)
    write_batch_fit_scatter_plot(args.outdir, summaries)
    write_rg_summary(args.outdir, summaries)
    ok = sum(1 for s in summaries if s.status == "ok")
    failed = len(summaries) - ok
    print("\n=== Batch complete ===")
    print(f"Successful: {ok}")
    print(f"Failed:     {failed}")
    print(f"Summary:    {args.outdir / 'batch_summary.csv'}")
    print(f"Markdown:   {args.outdir / 'batch_summary.md'}")
    print(f"Rg table:   {args.outdir / 'rg_summary.csv'}")
    print(f"Rg plot:    {args.outdir / 'rg_comparison.png'}")
    print(f"Match log:  {args.outdir / 'batch_match_report.csv'}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
