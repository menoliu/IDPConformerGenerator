"""
Simple model-independent QC screen for experimental SAXS .dat curves.

Assumes columns:
  col 1 = q or s
  col 2 = I(q)
  col 3 = sigma(q)

Main idea:
  - Convert q to Angstrom^-1.
  - Examine relative error = sigma / |I| and SNR = |I| / sigma.
  - Put extra weight on q = 0.10-0.20 A^-1.
  - Reject if errors are already bad in q=0.10-0.20 A^-1.
  - Keep if errors only become bad in the last 20% of q>=0.10 data.
  - Mark as CROP if the curve is good early but becomes bad before the tail.

Example:
  python screen_saxs_errors.py --indir ./sasbdb_dat --out qc_saxs.csv --plot-dir qc_plots

For SASBDB files, q/s is often nm^-1, but this script can infer or you can force:
  --q-unit nm
  --q-unit A
"""
import argparse
import csv
import math
import numpy as np

from pathlib import Path


def read_numeric_table(path: Path) -> np.ndarray:
    rows = []
    with path.open("r", errors="replace") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith(("#", ";", "!", "@")):
                continue
            vals = []
            for tok in s.replace(",", " ").split():
                try:
                    vals.append(float(tok.replace("D", "E").replace("d", "e")))
                except ValueError:
                    vals = []
                    break
            if len(vals) >= 3:
                rows.append(vals[:3])
    if not rows:
        raise ValueError(f"No numeric q/I/sigma rows found in {path}")
    return np.asarray(rows, dtype=float)


def infer_q_unit(q: np.ndarray) -> str:
    # SAXS q in A^-1 usually maxes around 0.3-0.6
    # SASBDB s in nm^-1 often maxes around 3-6
    return "nm" if np.nanmax(q) > 1.5 else "A"


def q_to_A(q: np.ndarray, unit: str) -> tuple[np.ndarray, str]:
    unit = unit.lower()
    if unit == "auto":
        unit = infer_q_unit(q)
        unit = unit.lower()
    if unit in {"a", "ang", "angstrom", "angstrom^-1", "a^-1"}:
        return q.astype(float), "A"
    if unit in {"nm", "nm^-1"}:
        return q.astype(float) * 0.1, "nm"
    raise ValueError("--q-unit must be auto, A, or nm")


def rolling_median(x: np.ndarray, window: int) -> np.ndarray:
    if window <= 1 or x.size == 0:
        return x.copy()
    out = np.full_like(x, np.nan, dtype=float)
    half = window // 2
    for i in range(x.size):
        lo = max(0, i - half)
        hi = min(x.size, i + half + 1)
        vals = x[lo:hi]
        vals = vals[np.isfinite(vals)]
        if vals.size:
            out[i] = np.median(vals)
    return out


def first_sustained_bad(mask: np.ndarray, min_run: int) -> int | None:
    run = 0
    start = None
    for i, bad in enumerate(mask):
        if bad:
            if run == 0:
                start = i
            run += 1
            if run >= min_run:
                return start
        else:
            run = 0
            start = None
    return None


def weighted_error_score(q: np.ndarray, relerr: np.ndarray, start_q: float, decay: float) -> float:
    good = np.isfinite(q) & np.isfinite(relerr)
    if good.sum() == 0:
        return math.nan
    # Higher weight near start_q, exponentially decaying toward high q
    w = np.exp(-(q[good] - start_q) / decay)
    e = np.clip(relerr[good], 0.0, 10.0)
    return float(np.sum(w * e) / np.sum(w))


def screen_curve(path: Path, args: argparse.Namespace) -> dict:
    arr = read_numeric_table(path)
    q_raw, I, sigma = arr[:, 0], arr[:, 1], arr[:, 2]
    q, inferred_unit = q_to_A(q_raw, args.q_unit)

    order = np.argsort(q)
    q, I, sigma = q[order], I[order], sigma[order]

    valid = np.isfinite(q) & np.isfinite(I) & np.isfinite(sigma) & (sigma > 0)
    q, I, sigma = q[valid], I[valid], sigma[valid]

    if q.size < args.min_points_total:
        return {
            "file": str(path),
            "decision": "REJECT",
            "reason": "too_few_valid_points",
            "q_unit_detected_or_used": inferred_unit,
            "n_total": int(q.size),
        }

    # Only screen from q >= start_q, as requested
    region = q >= args.start_q
    q2, I2, s2 = q[region], I[region], sigma[region]

    if q2.size < args.min_points_screen:
        return {
            "file": str(path),
            "decision": "REJECT",
            "reason": "too_few_points_after_start_q",
            "q_unit_detected_or_used": inferred_unit,
            "n_total": int(q.size),
            "n_screen": int(q2.size),
        }

    eps = np.nanmedian(np.abs(I2[np.isfinite(I2)])) * 1e-12
    eps = max(float(eps), 1e-300)
    relerr = s2 / np.maximum(np.abs(I2), eps)
    snr = np.abs(I2) / s2

    # Critical early region: q = 0.10-0.20 A^-1 by default
    early = (q2 >= args.start_q) & (q2 <= args.early_q_max)
    if early.sum() < args.min_points_early:
        # Fall back to first 20% of screened points if sparse
        n_early = max(args.min_points_early, int(math.ceil(0.20 * q2.size)))
        early = np.zeros(q2.size, dtype=bool)
        early[:min(n_early, q2.size)] = True

    early_rel = relerr[early]
    early_snr = snr[early]
    early_I = I2[early]

    med_rel_early = float(np.nanmedian(early_rel))
    p75_rel_early = float(np.nanpercentile(early_rel, 75))
    frac_bad_early = float(np.mean(early_rel > args.bad_relerr))
    frac_nonpos_early = float(np.mean(early_I <= 0))
    med_snr_early = float(np.nanmedian(early_snr))

    # Smooth errors so isolated spikes do not trigger rejection
    win = min(args.roll_window, q2.size)
    if win % 2 == 0:
        win += 1
    roll_rel = rolling_median(relerr, win)
    roll_snr = rolling_median(snr, win)

    bad = (roll_rel > args.bad_relerr) | (roll_snr < args.min_snr)
    bad_idx = first_sustained_bad(bad, args.min_bad_run)

    if bad_idx is None:
        q_bad_start = math.nan
        bad_start_fraction = math.nan
    else:
        q_bad_start = float(q2[bad_idx])
        bad_start_fraction = float(bad_idx / max(q2.size - 1, 1))

    # Last 20% tail criterion
    tail_start_idx = int(math.floor((1.0 - args.tail_fraction) * q2.size))
    tail_start_idx = min(max(tail_start_idx, 0), q2.size - 1)
    q_tail_start = float(q2[tail_start_idx])

    weighted_score = weighted_error_score(q2, relerr, args.start_q, args.weight_decay)

    reject_reasons = []

    # Hard early-q rejection: bad immediately after low-q/Guinier region
    if med_rel_early > args.max_median_relerr_early:
        reject_reasons.append("early_median_relative_error_too_high")
    if p75_rel_early > args.max_p75_relerr_early:
        reject_reasons.append("early_p75_relative_error_too_high")
    if frac_bad_early > args.max_frac_bad_early:
        reject_reasons.append("too_many_bad_points_in_early_region")
    if med_snr_early < args.min_median_snr_early:
        reject_reasons.append("early_median_snr_too_low")
    if frac_nonpos_early > args.max_frac_nonpositive_early:
        reject_reasons.append("too_many_nonpositive_intensities_in_early_region")

    if reject_reasons:
        decision = "REJECT"
        reason = ";".join(reject_reasons)
        q_useful_max = float(q2[0])
    elif bad_idx is None:
        decision = "PASS"
        reason = "errors_ok_through_screened_range"
        q_useful_max = float(q2[-1])
    elif bad_idx >= tail_start_idx:
        decision = "PASS_TAIL_NOISY"
        reason = "errors_only_become_bad_in_last_tail_fraction"
        q_useful_max = float(q2[-1])
    elif q_bad_start < args.early_q_max:
        decision = "REJECT"
        reason = "sustained_bad_errors_start_before_early_q_max"
        q_useful_max = q_bad_start
    else:
        decision = "CROP"
        reason = "good_early_but_noisy_before_tail;use_q_le_q_useful_max"
        q_useful_max = float(q2[max(bad_idx - 1, 0)])

    return {
        "file": str(path),
        "decision": decision,
        "reason": reason,
        "q_unit_detected_or_used": inferred_unit,
        "n_total": int(q.size),
        "n_screen": int(q2.size),
        "q_min_A": float(np.nanmin(q)),
        "q_max_A": float(np.nanmax(q)),
        "screen_start_q_A": float(args.start_q),
        "early_q_max_A": float(args.early_q_max),
        "q_tail_start_A": q_tail_start,
        "q_bad_start_A": q_bad_start,
        "q_useful_max_A": q_useful_max,
        "bad_start_fraction_after_start_q": bad_start_fraction,
        "weighted_relerr_score": weighted_score,
        "early_median_relerr": med_rel_early,
        "early_p75_relerr": p75_rel_early,
        "early_frac_relerr_gt_bad": frac_bad_early,
        "early_median_snr": med_snr_early,
        "early_frac_nonpositive_I": frac_nonpos_early,
    }


def write_plot(path: Path, result: dict, args: argparse.Namespace, plot_dir: Path) -> None:
    try:
        import matplotlib.pyplot as plt
    except Exception:
        return

    arr = read_numeric_table(path)
    q_raw, I, sigma = arr[:, 0], arr[:, 1], arr[:, 2]
    q, _ = q_to_A(q_raw, args.q_unit)
    order = np.argsort(q)
    q, I, sigma = q[order], I[order], sigma[order]
    valid = np.isfinite(q) & np.isfinite(I) & np.isfinite(sigma) & (sigma > 0)
    q, I, sigma = q[valid], I[valid], sigma[valid]

    eps = max(np.nanmedian(np.abs(I)) * 1e-12, 1e-300)
    relerr = sigma / np.maximum(np.abs(I), eps)

    plot_dir.mkdir(parents=True, exist_ok=True)

    fig = plt.figure(figsize=(7.0, 5.2))

    ax1 = fig.add_axes([0.12, 0.55, 0.84, 0.36])
    pos = I > 0
    ax1.errorbar(q[pos], I[pos], yerr=sigma[pos], fmt=".", markersize=2, linewidth=0.5)
    ax1.set_yscale("log")
    ax1.set_ylabel("I(q)")
    ax1.set_title(f"{path.name} | {result.get('decision')} | useful q <= {result.get('q_useful_max_A', np.nan):.3g} A^-1")

    ax2 = fig.add_axes([0.12, 0.12, 0.84, 0.34], sharex=ax1)
    ax2.plot(q, relerr, ".-", markersize=2, linewidth=0.7)
    ax2.axhline(args.bad_relerr, linestyle="--", linewidth=1, label="bad relerr")
    ax2.axvline(args.start_q, linestyle=":", linewidth=1, label="screen start")
    ax2.axvline(args.early_q_max, linestyle=":", linewidth=1, label="early end")
    if np.isfinite(result.get("q_tail_start_A", np.nan)):
        ax2.axvline(result["q_tail_start_A"], linestyle="--", linewidth=1, label="tail start")
    if np.isfinite(result.get("q_bad_start_A", np.nan)):
        ax2.axvline(result["q_bad_start_A"], linestyle="-.", linewidth=1, label="bad start")
    ax2.set_xlabel("q (A^-1)")
    ax2.set_ylabel("relative error sigma/|I|")
    ax2.set_ylim(bottom=0)
    ax2.legend(frameon=False, fontsize=7)

    out = plot_dir / (path.stem + "_qc.png")
    fig.savefig(out, dpi=180)
    plt.close(fig)


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Simple experimental SAXS error QC screen.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument("--indir", type=Path, required=True, help="Directory of .dat SAXS files.")
    ap.add_argument("--glob", default="*.dat", help="Input file glob.")
    ap.add_argument("--recursive", action="store_true", help="Search recursively.")
    ap.add_argument("--out", type=Path, default=Path("saxs_qc_summary.csv"), help="Output CSV.")
    ap.add_argument("--plot-dir", type=Path, default=None, help="Optional directory for QC plots.")

    ap.add_argument("--q-unit", choices=["auto", "A", "nm"], default="auto")
    ap.add_argument("--start-q", type=float, default=0.10, help="Start screening at this q in A^-1.")
    ap.add_argument("--early-q-max", type=float, default=0.20, help="Critical early region ends at this q in A^-1.")
    ap.add_argument("--tail-fraction", type=float, default=0.20, help="If errors start only in this last fraction, keep.")

    # Conservative defaults for peer-review screening. Adjust after inspecting QC plots.
    ap.add_argument("--bad-relerr", type=float, default=0.50, help="Rolling error is bad if sigma/|I| exceeds this.")
    ap.add_argument("--min-snr", type=float, default=2.0, help="Rolling SNR is bad if |I|/sigma is below this.")
    ap.add_argument("--max-median-relerr-early", type=float, default=0.25)
    ap.add_argument("--max-p75-relerr-early", type=float, default=0.50)
    ap.add_argument("--max-frac-bad-early", type=float, default=0.20)
    ap.add_argument("--min-median-snr-early", type=float, default=4.0)
    ap.add_argument("--max-frac-nonpositive-early", type=float, default=0.02)

    ap.add_argument("--roll-window", type=int, default=9, help="Rolling median window in points.")
    ap.add_argument("--min-bad-run", type=int, default=8, help="Consecutive bad rolling points needed to call q_bad_start.")
    ap.add_argument("--weight-decay", type=float, default=0.08, help="Decay length in A^-1 for weighted error score.")

    ap.add_argument("--min-points-total", type=int, default=30)
    ap.add_argument("--min-points-screen", type=int, default=20)
    ap.add_argument("--min-points-early", type=int, default=8)

    args = ap.parse_args()

    files = sorted(args.indir.rglob(args.glob) if args.recursive else args.indir.glob(args.glob))
    files = [p for p in files if p.is_file()]
    if not files:
        raise SystemExit(f"No files matched {args.indir}/{args.glob}")

    rows = []
    for p in files:
        try:
            row = screen_curve(p, args)
        except Exception as e:
            row = {"file": str(p), "decision": "ERROR", "reason": f"{type(e).__name__}: {e}"}
        rows.append(row)
        if args.plot_dir and row.get("decision") != "ERROR":
            write_plot(p, row, args, args.plot_dir)

    fieldnames = [
        "file", "decision", "reason", "q_unit_detected_or_used",
        "n_total", "n_screen", "q_min_A", "q_max_A",
        "screen_start_q_A", "early_q_max_A", "q_tail_start_A",
        "q_bad_start_A", "q_useful_max_A", "bad_start_fraction_after_start_q",
        "weighted_relerr_score",
        "early_median_relerr", "early_p75_relerr", "early_frac_relerr_gt_bad",
        "early_median_snr", "early_frac_nonpositive_I",
    ]

    with args.out.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    counts = {}
    for r in rows:
        counts[r.get("decision", "UNKNOWN")] = counts.get(r.get("decision", "UNKNOWN"), 0) + 1

    print(f"Wrote: {args.out}")
    if args.plot_dir:
        print(f"Plots: {args.plot_dir}")
    print("Decision counts:")
    for k, v in sorted(counts.items()):
        print(f"  {k}: {v}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
