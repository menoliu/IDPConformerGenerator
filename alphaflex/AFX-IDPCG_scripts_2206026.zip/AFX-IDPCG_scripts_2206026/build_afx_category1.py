"""
Generalized builder for category 1 cases:
  1. full-length IDPs
  2. N-terminal IDR + folded core
  3. folded core + C-terminal IDR
  4. N-terminal IDR + folded core + C-terminal IDR

Strategy
--------
* Full IDP:
    - use `idpconfgen build`
    - automatically switch to long mode for long sequences
* Terminal category 1 cases (N, C, or N+C):
    - always use `idpconfgen build` to generate terminal-IDR candidates
    - filter candidates against the folded template using `count_clashes()`
    - stitch passing terminal fragments back onto the folded core

Assumptions
-----------
* "category 1" means there are no linker/internal IDRs. Only:
    - [1, num_res]                         -> IDP
    - [1, x]                              -> N-IDR only
    - [y, num_res]                        -> C-IDR only
    - [1, x] and [y, num_res]             -> N + C IDRs
* The folded portion between terminal IDRs is treated as a single non-interacting
  folded template.
* Terminal IDR stitching uses a 2-residue overhang.

Requirements
------------
* IDPConformerGenerator >= 0.7.27
* OpenMM >= 8.2
* pdb-tools >= 2.5
* PDBFixer >= 1.9
"""

import json
import os
import random
import re
import shutil
import subprocess
import sys

from functools import partial
from glob import glob
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from pdbfixer import PDBFixer

from openmm import CustomExternalForce, LangevinIntegrator
from openmm.app import ForceField, HBonds, NoCutoff, PDBFile, Simulation
from openmm.unit import angstrom, kilocalories_per_mole, kelvin, picosecond, picoseconds

from idpconfgen import Path as IDPPath
from idpconfgen.ldrs_helper import align_coords, count_clashes, disorder_cases
from idpconfgen.libs.libmulticore import pool_function
from idpconfgen.libs.libstructure import (
    Structure,
    col_chainID,
    col_name,
    col_resSeq,
    col_serial,
    cols_coords,
    parse_pdb_to_array,
    structure_to_pdb,
    write_PDB,
)


# =============================================================================
# User-editable parameters
# =============================================================================

set_num = int(re.search(r"\d+", Path(sys.argv[0]).name).group()) if re.search(r"\d+", Path(sys.argv[0]).name) else 0

nconfs = 100
ncores = 50
# Keep IDPCG/alignment parallel, but keep PDBFixer/OpenMM postprocessing
# memory-safe on 96 GB nodes. 50 concurrent PDBFixer/OpenMM workers can OOM.
fix_ncores = 10
cc_ncores = 2


LONG_IDR_CUTOFF = 150
BATCH_MULTIPLIER = 3               # build 3x as many raw candidates per batch
MAX_PAIR_CHECKS = 20000            # safety valve for N/C pairing
# For the NC case, collect this many unique candidates per terminal so the
# greedy unique-pairing step has enough material to avoid repeating any IDR.
NC_CANDIDATE_MULTIPLIER = 2
NO_SOLUTION_BATCH_LIMIT = 10       # per filter stage; see TERMINAL_FILTER_STAGES
PROGRESS_REPORT_EVERY = 5          # print batch progress every N batches
# Strict first, then progressively relax terminal-fragment clash acceptance.
# This prevents very short terminal IDRs, especially short C-IDRs, from burning
# 3 days and then failing with zero candidates.
TERMINAL_FILTER_STAGES = [
    (80, 0.40, "strict"),
    (120, 0.35, "relaxed"),
    (200, 0.30, "last_resort"),
]

output_directory = Path(f"../AFX-IDPCG_Category_1_ensembles/cat1_ens{set_num}")
easy_ids_file = f"../databases/category_1_ids/cat1_{set_num}.txt"
idpcg_database = "../databases/idpconfgen_database_2024.json"
master_db_file = "../databases/AlphaFlex_database_July2024_v2.json"
max_residues_file = "../databases/AF2_9606_HUMAN_v4_num_residues.json"
af2_pdb_glob = "../databases/AF2_9606_PAE_PDB/*.pdb"


# =============================================================================
# Utilities
# =============================================================================

def run_shell(
    cmd: str,
    *,
    quiet: bool = True,
    stdout_file: Optional[Path] = None,
    ) -> subprocess.CompletedProcess:
        """Run a shell command and raise a helpful error on failure.

        When ``quiet`` is True, stdout is discarded (not buffered in memory) and
        stderr is captured for error reporting only.  Pass ``stdout_file`` to
        redirect stdout to a file instead of discarding it (used for
        pdb_mkensemble).
        """
        if stdout_file is not None:
            with open(stdout_file, "w") as outf:
                result = subprocess.run(
                    cmd, shell=True, text=True, stdout=outf, stderr=subprocess.PIPE
                )
        elif quiet:
            result = subprocess.run(
                cmd, shell=True, text=True,
                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            )
        else:
            result = subprocess.run(cmd, shell=True, text=True)

        if result.returncode != 0:
            msg = f"Command failed ({result.returncode}):\n{cmd}"
            if quiet or stdout_file is not None:
                stderr = (getattr(result, "stderr", None) or "").strip()
                if stderr:
                    msg += f"\n\nSTDERR:\n{stderr}"
            raise RuntimeError(msg)
        return result


class NoSolutionAfterSamplingError(RuntimeError):
    """Raised when repeated sampling cannot produce even one passing candidate."""
    def __init__(self, terminal_case: str, batch_limit: int, passed_dir: Path):
        self.terminal_case = terminal_case
        self.batch_limit = batch_limit
        self.passed_dir = passed_dir
        super().__init__(
            f"No passing {terminal_case} candidates after {batch_limit} batches "
            f"(passed_dir={passed_dir})."
        )


def mkdir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def cleanup_glob(pattern: str) -> None:
    for p in glob(pattern):
        path = Path(p)
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        elif path.exists():
            path.unlink(missing_ok=True)


def load_easy_ids(easy_ids_path: str) -> List[str]:
    """Load the UniProt IDs for this easy set from the explicit txt file."""
    path = Path(easy_ids_path)
    if not path.exists():
        raise FileNotFoundError(f"Could not find easy IDs file: {path}")

    with open(path) as handle:
        return [line.strip() for line in handle if line.strip()]


def load_json(path: str) -> dict:
    with open(path, "r") as handle:
        return json.load(handle)


def get_pdb_path(uniprot_id: str, af2_pdbs: Sequence[str]) -> str:
    # Single-pass: collect exact-prefix matches and fallback matches together.
    exact: List[str] = []
    fuzzy: List[str] = []
    for p in af2_pdbs:
        name = Path(p).name
        if uniprot_id not in name:
            continue
        if name.startswith(f"AF-{uniprot_id}-"):
            exact.append(p)
        else:
            fuzzy.append(p)

    candidates = exact or fuzzy
    if not candidates:
        raise FileNotFoundError(f"No AF2 PDB found for {uniprot_id}")
    if len(candidates) == 1:
        return candidates[0]
    return sorted(candidates)[0]


def normalize_idr_ranges(details: Sequence[Sequence[int]]) -> List[Tuple[int, int]]:
    return sorted([(int(start), int(end)) for start, end in details], key=lambda x: (x[0], x[1]))


def classify_easy_case(details: Sequence[Tuple[int, int]], num_res: int) -> Optional[str]:
    """
    Return one of:
        IDP, N, C, NC
    or None if this is not a valid Category 1 case.
    """
    if not details:
        return None

    if len(details) == 1:
        start, end = details[0]
        if start == 1 and end == num_res:
            return "IDP"
        if start == 1 and end < num_res:
            return "N"
        if start > 1 and end == num_res:
            return "C"
        return None

    if len(details) == 2:
        (s1, e1), (s2, e2) = details
        if s1 == 1 and e2 == num_res and e1 < s2 - 1:
            return "NC"
        return None

    return None


def terminal_lengths(case: str, details: Sequence[Tuple[int, int]], num_res: int) -> Tuple[int, int]:
    n_len = 0
    c_len = 0
    if case in {"N", "NC"}:
        n_len = details[0][1] - details[0][0] + 1
    if case == "C":
        c_len = details[0][1] - details[0][0] + 1
    elif case == "NC":
        c_len = details[1][1] - details[1][0] + 1
    return n_len, c_len


def is_long_segment(residue_count: int) -> bool:
    return residue_count >= LONG_IDR_CUTOFF


def build_full_idp(sequence: str, outdir: Path) -> None:
    long_flag = " --long" if is_long_segment(len(sequence)) else ""
    cmd = (
        f"idpconfgen build "
        f"-seq {sequence} "
        f"-db {idpcg_database} "
        f"--dloop-off --dany{long_flag} "
        f"-nc {nconfs} -n {ncores} "
        f"-of {outdir}"
    )
    run_shell(cmd)


def write_folded_template(struc: Structure, details: Sequence[Tuple[int, int]], outpath: Path) -> None:
    struc_arr = struc.data_array
    seqs = struc_arr[:, col_resSeq].astype(int)
    seq_mask = np.ones(seqs.shape, dtype=bool)
    for start, end in details:
        seq_mask[(seqs >= start) & (seqs <= end)] = False

    filtered = struc_arr[seq_mask]
    if len(filtered) == 0:
        raise ValueError("Folded template became empty after removing easy-case IDRs.")

    template_struc = structure_to_pdb(filtered)
    write_PDB(template_struc, str(outpath))


def add_hydrogens(pdb_file: str, pH: float = 7.4) -> None:
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))

    fixer = PDBFixer(filename=pdb_file)
    fixer.findMissingResidues()
    fixer.findMissingAtoms()
    fixer.addMissingHydrogens(pH=pH)

    outfile = os.path.join(folder, f"{name}_pro.pdb")
    with open(outfile, "w") as handle:
        PDBFile.writeFile(fixer.topology, fixer.positions, handle)

    os.remove(pdb_file)


def resolve_clash(pdb_file: str) -> None:
    """
    Resolve local clashes while restraining the backbone.
    """
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))

    pdb = PDBFile(pdb_file)
    forcefield = ForceField("amber99sb.xml")
    system = forcefield.createSystem(
        pdb.topology, constraints=HBonds, nonbondedMethod=NoCutoff
    )

    # Use a set for O(1) membership testing instead of a list.
    backbone_names = {"N", "CA", "C", "O"}
    sidechain_atoms = {
        atom.index
        for atom in pdb.topology.atoms()
        if atom.name not in backbone_names
    }

    k = 10.0 * kilocalories_per_mole / angstrom**2
    constraint_force = CustomExternalForce(
        "0.5 * k * ((x - x0)^2 + (y - y0)^2 + (z - z0)^2)"
    )
    constraint_force.addPerParticleParameter("x0")
    constraint_force.addPerParticleParameter("y0")
    constraint_force.addPerParticleParameter("z0")
    constraint_force.addGlobalParameter("k", k)

    for atom in pdb.topology.atoms():
        if atom.index not in sidechain_atoms:
            position = pdb.positions[atom.index]
            constraint_force.addParticle(atom.index, [position.x, position.y, position.z])

    system.addForce(constraint_force)

    integrator = LangevinIntegrator(300 * kelvin, 1 / picosecond, 0.002 * picoseconds)  # type: ignore
    simulation = Simulation(pdb.topology, system, integrator)
    simulation.context.setPositions(pdb.positions)
    simulation.minimizeEnergy(maxIterations=1000)

    positions = simulation.context.getState(getPositions=True).getPositions()
    with open(os.path.join(folder, f"{name}_cr.pdb"), "w") as handle:
        PDBFile.writeFile(simulation.topology, positions, handle)

    os.remove(pdb_file)


def postprocess_ensemble(path_final_ens: Path, uniprot_id: str) -> None:
    print("Adding hydrogens...")
    idpcg_files = sorted(glob(str(path_final_ens / "conformer_*.pdb")))
    fix_pool = pool_function(add_hydrogens, idpcg_files, ncores=fix_ncores)
    for _ in fix_pool:
        pass

    print("Resolving side-chain clashes...")
    hydrogenated_files = sorted(glob(str(path_final_ens / "conformer_*_pro.pdb")))
    clash_pool = pool_function(resolve_clash, hydrogenated_files, ncores=cc_ncores)
    for _ in clash_pool:
        pass

    ensemble_path = path_final_ens / f"{uniprot_id}_idpcg_n{nconfs}.pdb"
    # Use stdout_file instead of a shell redirect to avoid buffering all output
    # in memory.
    run_shell(
        f"pdb_mkensemble {path_final_ens}/conformer_*_cr.pdb",
        stdout_file=ensemble_path,
    )

    cleanup_glob(str(path_final_ens / "conformer*"))
    cleanup_glob(str(path_final_ens / "temp*"))
    cleanup_glob(str(path_final_ens / "energies.log"))


# =============================================================================
# Terminal-IDR build/filter/stitch path
# =============================================================================

def idr_aligner(
    idr: str,
    fld_struc: Structure,
    case: str,
    batch_tag: str,
    output: str,
    max_clash: int = 80,
    tolerance: float = 0.4,
    ) -> None:
        fld_name = fld_struc.data_array[:, col_name]
        fld_seq = fld_struc.data_array[:, col_resSeq].astype(int)

        first_seq = fld_seq[0]
        last_seq = fld_seq[-1]

        fld_term_idx: Dict[str, int] = {}

        if case == "N-IDR":
            for j, atom in enumerate(fld_name):
                curr_seq = fld_seq[j]
                if curr_seq == first_seq + 1 and atom == "N":
                    fld_term_idx["N"] = j
                elif curr_seq == first_seq + 1 and atom == "CA":
                    fld_term_idx["CA"] = j
                elif curr_seq == first_seq and atom == "C":
                    fld_term_idx["C"] = j
                elif curr_seq == first_seq + 2:
                    break

        elif case == "C-IDR":
            for j, _atom in enumerate(fld_name):
                k = len(fld_name) - 1 - j
                curr_seq = fld_seq[k]
                if curr_seq == last_seq and fld_name[k] == "N":
                    fld_term_idx["N"] = k
                elif curr_seq == last_seq and fld_name[k] == "CA":
                    fld_term_idx["CA"] = k
                elif curr_seq == last_seq - 1 and fld_name[k] == "C":
                    fld_term_idx["C"] = k
                elif curr_seq == last_seq - 2:
                    break
        else:
            raise ValueError(f"Unsupported terminal case for aligner: {case}")

        if set(fld_term_idx) != {"N", "CA", "C"}:
            raise ValueError(f"Could not find stitching atoms for {case}")

        fld_Cxyz = fld_struc.data_array[fld_term_idx["C"]][cols_coords].astype(float)
        fld_Nxyz = fld_struc.data_array[fld_term_idx["N"]][cols_coords].astype(float)
        fld_CAxyz = fld_struc.data_array[fld_term_idx["CA"]][cols_coords].astype(float)
        fld_coords = np.array([fld_Cxyz, fld_Nxyz, fld_CAxyz])

        with open(idr) as handle:
            idr_data = handle.read()

        try:
            idr_arr = parse_pdb_to_array(idr_data)
        except AssertionError:
            return

        aligned_idr = align_coords(idr_arr, fld_coords, case)
        clashes, fragment = count_clashes(
            aligned_idr,
            fld_struc,
            case,
            max_clash=max_clash,
            tolerance=tolerance,
        )

        if type(clashes) is int:
            aligned_struc = structure_to_pdb(fragment)
            stem = Path(idr).stem
            write_PDB(aligned_struc, os.path.join(output, f"aligned_{case}_{batch_tag}_{stem}.pdb"))


def trim_residue_from_end(arr: np.ndarray) -> np.ndarray:
    seq = arr[:, col_resSeq]
    for i in range(len(seq)):
        j = len(seq) - 1 - i
        curr = seq[j]
        prev = seq[j - 1]
        arr = arr[:-1]
        if prev != curr:
            break
    return arr


def trim_residue_from_start(arr: np.ndarray) -> np.ndarray:
    seq = arr[:, col_resSeq]
    for i in range(len(seq)):
        curr = seq[i]
        next_seq = seq[i + 1]
        arr = arr[1:]
        if next_seq != curr:
            break
    return arr


def idr_stitcher(idr_arr, case: List[str], fld_arr: np.ndarray, output: Path, idx: int) -> None:
    chain = fld_arr[:, col_chainID][0]
    seq_fld = fld_arr[:, col_resSeq]
    last_seq_fld = int(seq_fld[-1])

    if len(case) == 1:
        # Vectorized chain ID assignment (replaces per-row Python loop).
        idr_arr[:, col_chainID] = chain

        if case[0] == disorder_cases[0]:
            idr_arr = trim_residue_from_end(idr_arr)
            fld_arr = trim_residue_from_start(fld_arr)
            new_struc_lst = idr_arr.tolist() + fld_arr.tolist()
        else:
            idr_arr = trim_residue_from_start(idr_arr)
            fld_arr = trim_residue_from_end(fld_arr)
            # Vectorized resSeq renumbering (replaces per-row Python loop).
            idr_arr[:, col_resSeq] = (
                idr_arr[:, col_resSeq].astype(int) + (last_seq_fld - 2)
            ).astype(str)
            new_struc_lst = fld_arr.tolist() + idr_arr.tolist()

        new_struc_arr = np.array(new_struc_lst)

    else:
        nidr_path = idr_arr[0]
        cidr_path = idr_arr[1]

        nidr_struc = Structure(IDPPath(nidr_path))
        cidr_struc = Structure(IDPPath(cidr_path))
        nidr_struc.build()
        cidr_struc.build()

        nidr_arr = nidr_struc.data_array
        cidr_arr = cidr_struc.data_array

        # Vectorized chain ID assignment.
        nidr_arr[:, col_chainID] = chain
        cidr_arr[:, col_chainID] = chain

        nidr_arr = trim_residue_from_end(nidr_arr)
        fld_arr = trim_residue_from_start(fld_arr)
        cidr_arr = trim_residue_from_start(cidr_arr)
        fld_arr = trim_residue_from_end(fld_arr)

        # Vectorized resSeq renumbering.
        cidr_arr[:, col_resSeq] = (
            cidr_arr[:, col_resSeq].astype(int) + (last_seq_fld - 2)
        ).astype(str)

        new_struc_lst = nidr_arr.tolist() + fld_arr.tolist() + cidr_arr.tolist()
        new_struc_arr = np.array(new_struc_lst)

    new_serial = [str(i) for i in range(1, len(new_struc_arr) + 1)]
    new_struc_arr[:, col_serial] = new_serial
    new_struc = structure_to_pdb(new_struc_arr)
    write_PDB(new_struc, str(output / f"conformer_{idx}.pdb"))


def build_segment_candidates(
    seq: str,
    *,
    fld_template: Structure,
    terminal_case: str,
    raw_dir: Path,
    passed_dir: Path,
    long_mode: bool,
    target_n: int,
    ) -> List[str]:
        mkdir(raw_dir)
        mkdir(passed_dir)

        batch_size = nconfs * BATCH_MULTIPLIER
        stagnant_batches = 0
        batch_idx = 0
        seed = 0

        # Check whether a previous run already deposited enough passing files.
        passed = sorted(glob(str(passed_dir / "*.pdb")))
        if len(passed) >= target_n:
            return passed[:target_n]
        prev_passed = len(passed)

        while True:
            batch_out = raw_dir / f"batch_{batch_idx:03d}"
            mkdir(batch_out)

            long_flags = " --long --force-long" if long_mode else ""
            cmd = (
                f"idpconfgen build "
                f"-seq {seq} "
                f"-db {idpcg_database} "
                f"--dloop-off --dany "
                f"-nc {batch_size} -n {ncores} "
                f"-rs {seed}{long_flags} "
                f"-of {batch_out}"
            )
            run_shell(cmd)

            new_raw = sorted(glob(str(batch_out / "*.pdb")))

            stage_idx = min(
                batch_idx // NO_SOLUTION_BATCH_LIMIT,
                len(TERMINAL_FILTER_STAGES) - 1,
            )
            max_clash, tolerance, stage_name = TERMINAL_FILTER_STAGES[stage_idx]
            if batch_idx > 0 and batch_idx % NO_SOLUTION_BATCH_LIMIT == 0:
                print(
                    f"  {terminal_case}: switching to {stage_name} filter "
                    f"(max_clash={max_clash}, tolerance={tolerance})"
                )

            execute = partial(
                idr_aligner,
                fld_struc=fld_template,
                case=terminal_case,
                batch_tag=f"b{batch_idx:03d}_{stage_name}",
                output=str(passed_dir),
                max_clash=max_clash,
                tolerance=tolerance,
            )
            pool = pool_function(execute, new_raw, ncores=ncores)
            for _ in pool:
                pass

            # Single glob per iteration: used for both the early-exit check and
            # the stagnation check (eliminates the redundant second glob).
            passed = sorted(glob(str(passed_dir / "*.pdb")))
            if len(passed) >= target_n:
                return passed[:target_n]

            batches_done = batch_idx + 1
            if batches_done % PROGRESS_REPORT_EVERY == 0:
                print(
                    f"  {terminal_case}: {len(passed)}/{target_n} passing candidates "
                    f"after {batches_done} batches"
                )

            final_stage_reached = stage_idx == len(TERMINAL_FILTER_STAGES) - 1
            max_total_batches = NO_SOLUTION_BATCH_LIMIT * len(TERMINAL_FILTER_STAGES)
            if batches_done >= max_total_batches and len(passed) == 0 and final_stage_reached:
                raise NoSolutionAfterSamplingError(
                    terminal_case=terminal_case,
                    batch_limit=max_total_batches,
                    passed_dir=passed_dir,
                )

            new_count = len(passed)
            if new_count == prev_passed:
                stagnant_batches += 1
            else:
                stagnant_batches = 0
            if stagnant_batches >= 10 and new_count > 0:
                print(
                    f"  {terminal_case}: no new passing candidates in 10 recent batches "
                    f"({new_count}/{target_n}); continuing sampling."
                )
                stagnant_batches = 0

            prev_passed = new_count
            seed += batch_size
            batch_idx += 1


def check_nc_pair_passes(task: Tuple[str, str]) -> Optional[Tuple[str, str]]:
    n_path, c_path = task
    n_struc = Structure(IDPPath(n_path))
    c_struc = Structure(IDPPath(c_path))
    n_struc.build()
    c_struc.build()
    nc, _ = count_clashes(n_struc.data_array, c_struc)
    return (n_path, c_path) if type(nc) is int else None


def choose_nc_pairs(
    nidrs: Sequence[str],
    cidrs: Sequence[str],
    needed: int,
    ) -> List[Tuple[str, str]]:
        """
        Select N/C terminal IDR pairs with a diversity-preserving fallback.
    
        First performs greedy unique bipartite matching so each N-IDR and C-IDR
        appears at most once. If that cannot reach ``needed``, it fills the
        remainder with non-clashing repeats while balancing terminal reuse.
    
        Algorithm
        ---------
        1. Shuffle both lists independently.
         2. Build candidate N/C pair checks up to ``MAX_PAIR_CHECKS`` and keep only
             clash-free passing pairs.
         3. Apply strict no-repeat matching first (each N and C used at most once).
         4. If needed, fill the shortfall from remaining passing pairs using a
             diversity score that favors underused N and C fragments.
         5. Only fail when the total number of passing pairs is below ``needed``.
        """
        if not nidrs or not cidrs:
            raise RuntimeError("Need both N-IDR and C-IDR candidate lists to form NC pairs.")
    
        nidrs = list(nidrs)
        cidrs = list(cidrs)
        random.shuffle(nidrs)
        random.shuffle(cidrs)
    
        candidate_pairs: List[Tuple[str, str]] = []
        checks_planned = 0
        for n_path in nidrs:
            if checks_planned >= MAX_PAIR_CHECKS:
                break
            c_order = cidrs.copy()
            random.shuffle(c_order)
            for c_path in c_order:
                candidate_pairs.append((n_path, c_path))
                checks_planned += 1
                if checks_planned >= MAX_PAIR_CHECKS:
                    break
                
        print(f"  Checking up to {len(candidate_pairs)} N/C pair clashes in parallel...")
        pair_pool = pool_function(check_nc_pair_passes, candidate_pairs, ncores=cc_ncores)
        passing_pairs = [p for p in pair_pool if p is not None]
    
        random.shuffle(passing_pairs)
        used_n = set()
        used_c = set()
        unique_pairs: List[Tuple[str, str]] = []
        for n_path, c_path in passing_pairs:
            if n_path in used_n or c_path in used_c:
                continue
            unique_pairs.append((n_path, c_path))
            used_n.add(n_path)
            used_c.add(c_path)
            if len(unique_pairs) >= needed:
                break
            
        if len(unique_pairs) >= needed:
            return unique_pairs[:needed]
    
        if len(passing_pairs) < needed:
            raise RuntimeError(
                f"Could not find {needed} non-clashing N/C IDR pairs "
                f"(found {len(passing_pairs)} total passing pairs after {len(candidate_pairs)} checks; "
                f"strict-unique={len(unique_pairs)})."
            )
    
        print(
            f"  Unique NC pairing found {len(unique_pairs)}/{needed}; "
            f"filling remaining {needed - len(unique_pairs)} with diverse repeats."
        )
    
        selected_pairs = unique_pairs.copy()
        selected_set = set(selected_pairs)
        n_use: Dict[str, int] = {}
        c_use: Dict[str, int] = {}
        for n_path, c_path in selected_pairs:
            n_use[n_path] = n_use.get(n_path, 0) + 1
            c_use[c_path] = c_use.get(c_path, 0) + 1
    
        non_repeated_pair_pool = [pair for pair in passing_pairs if pair not in selected_set]
        random.shuffle(non_repeated_pair_pool)
    
        def diversity_score(pair: Tuple[str, str]) -> Tuple[int, int]:
            n_path, c_path = pair
            n_count = n_use.get(n_path, 0)
            c_count = c_use.get(c_path, 0)
            return (max(n_count, c_count), n_count + c_count)
    
        while len(selected_pairs) < needed and non_repeated_pair_pool:
            best_i = min(
                range(len(non_repeated_pair_pool)),
                key=lambda i: diversity_score(non_repeated_pair_pool[i]),
            )
            n_path, c_path = non_repeated_pair_pool.pop(best_i)
            selected_pairs.append((n_path, c_path))
            n_use[n_path] = n_use.get(n_path, 0) + 1
            c_use[c_path] = c_use.get(c_path, 0) + 1
    
        if len(selected_pairs) < needed:
            # Last-resort: allow exact pair reuse, still choosing least-used endpoints.
            while len(selected_pairs) < needed:
                n_path, c_path = min(passing_pairs, key=diversity_score)
                selected_pairs.append((n_path, c_path))
                n_use[n_path] = n_use.get(n_path, 0) + 1
                c_use[c_path] = c_use.get(c_path, 0) + 1
    
        if len(selected_pairs) < needed:
            raise RuntimeError(
                f"Could not find {needed} non-clashing N/C IDR pairs "
                f"(selected={len(selected_pairs)} after {len(candidate_pairs)} checks; "
                f"passing={len(passing_pairs)})."
            )
    
        return selected_pairs[:needed]


def stitch_terminal_task(
    task: Tuple[int, str],
    *,
    out_case: List[str],
    fld_arr: np.ndarray,
    output: Path,
    ) -> None:
        idx, idr_path = task
        idr_struc = Structure(IDPPath(idr_path))
        idr_struc.build()
        idr_stitcher(
            idr_arr=idr_struc.data_array.copy(),
            case=out_case,
            fld_arr=fld_arr.copy(),
            output=output,
            idx=idx,
        )


def stitch_nc_task(
    task: Tuple[int, Tuple[str, str]],
    *,
    out_case: List[str],
    fld_arr: np.ndarray,
    output: Path,
    ) -> None:
        idx, pair = task
        idr_stitcher(
            idr_arr=pair,
            case=out_case,
            fld_arr=fld_arr.copy(),
            output=output,
            idx=idx,
        )


def build_terminal_filtered(
    sequence: str,
    details: Sequence[Tuple[int, int]],
    case: str,
    af2_template_path: Path,
    path_final_ens: Path,
    path_idrs: Path,
    ) -> None:
        af2_template = Structure(IDPPath(str(af2_template_path)))
        af2_template.build()

        if case == "N":
            n_end = details[0][1]
            nidr_seq = sequence[: min(len(sequence), n_end + 2)]
            n_long = is_long_segment(len(nidr_seq))

            path_n_raw = path_idrs / disorder_cases[0]
            path_n_passed = path_idrs / f"{disorder_cases[0]}_passed"

            nidrs_passed = build_segment_candidates(
                nidr_seq,
                fld_template=af2_template,
                terminal_case=disorder_cases[0],
                raw_dir=path_n_raw,
                passed_dir=path_n_passed,
                long_mode=n_long,
                target_n=nconfs,
            )

            out_case = [disorder_cases[0]]
            tasks = list(zip(range(1, nconfs + 1), nidrs_passed[:nconfs]))
            execute = partial(
                stitch_terminal_task,
                out_case=out_case,
                fld_arr=af2_template.data_array,
                output=path_final_ens,
            )
            stitch_pool = pool_function(execute, tasks, ncores=ncores)
            for _ in stitch_pool:
                pass

        elif case == "C":
            c_start = details[0][0]
            cidr_seq = sequence[max(0, c_start - 3):]
            c_long = is_long_segment(len(cidr_seq))

            path_c_raw = path_idrs / disorder_cases[2]
            path_c_passed = path_idrs / f"{disorder_cases[2]}_passed"

            cidrs_passed = build_segment_candidates(
                cidr_seq,
                fld_template=af2_template,
                terminal_case=disorder_cases[2],
                raw_dir=path_c_raw,
                passed_dir=path_c_passed,
                long_mode=c_long,
                target_n=nconfs,
            )

            out_case = [disorder_cases[2]]
            tasks = list(zip(range(1, nconfs + 1), cidrs_passed[:nconfs]))
            execute = partial(
                stitch_terminal_task,
                out_case=out_case,
                fld_arr=af2_template.data_array,
                output=path_final_ens,
            )
            stitch_pool = pool_function(execute, tasks, ncores=ncores)
            for _ in stitch_pool:
                pass

        elif case == "NC":
            n_end = details[0][1]
            c_start = details[1][0]

            nidr_seq = sequence[: min(len(sequence), n_end + 2)]
            cidr_seq = sequence[max(0, c_start - 3):]

            n_long = is_long_segment(len(nidr_seq))
            c_long = is_long_segment(len(cidr_seq))

            path_n_raw = path_idrs / disorder_cases[0]
            path_c_raw = path_idrs / disorder_cases[2]
            path_n_passed = path_idrs / f"{disorder_cases[0]}_passed"
            path_c_passed = path_idrs / f"{disorder_cases[2]}_passed"

            nc_target = nconfs * NC_CANDIDATE_MULTIPLIER
            print(f"  NC case: collecting {nc_target} candidates per terminal for unique pairing.")

            nidrs_passed = build_segment_candidates(
                nidr_seq,
                fld_template=af2_template,
                terminal_case=disorder_cases[0],
                raw_dir=path_n_raw,
                passed_dir=path_n_passed,
                long_mode=n_long,
                target_n=nc_target,
            )
            cidrs_passed = build_segment_candidates(
                cidr_seq,
                fld_template=af2_template,
                terminal_case=disorder_cases[2],
                raw_dir=path_c_raw,
                passed_dir=path_c_passed,
                long_mode=c_long,
                target_n=nc_target,
            )

            idr_combos = choose_nc_pairs(nidrs_passed, cidrs_passed, nconfs)
            out_case = [disorder_cases[0], disorder_cases[2]]
            tasks = list(zip(range(1, nconfs + 1), idr_combos[:nconfs]))
            execute = partial(
                stitch_nc_task,
                out_case=out_case,
                fld_arr=af2_template.data_array,
                output=path_final_ens,
            )
            stitch_pool = pool_function(execute, tasks, ncores=ncores)
            for _ in stitch_pool:
                pass
        else:
            raise ValueError(f"Unsupported easy case: {case}")


# =============================================================================
# Main
# =============================================================================

def main() -> None:
    master_db = load_json(master_db_file)
    max_residues = load_json(max_residues_file)
    easy_ids = load_easy_ids(easy_ids_file)
    af2_pdbs = glob(af2_pdb_glob)

    mkdir(output_directory)

    for uniprot_id in easy_ids:
        print(f"\n=== {uniprot_id} ===")
        path_final_ens = output_directory / uniprot_id
        path_templates = path_final_ens / "temp_templates"
        path_idrs = path_final_ens / "temp_idrs"

        mkdir(path_final_ens)
        cleanup_glob(str(path_final_ens / "conformer*"))
        cleanup_glob(str(path_final_ens / "temp*"))
        cleanup_glob(str(path_final_ens / "*_idpcg_n*.pdb"))
        mkdir(path_templates)
        mkdir(path_idrs)

        pdb_path = get_pdb_path(uniprot_id, af2_pdbs)
        struc = Structure(IDPPath(pdb_path))
        struc.build()

        sequence = next(iter(struc.fasta.values()))
        details = normalize_idr_ranges(master_db[uniprot_id]["idrs"])
        num_res = int(max_residues[uniprot_id])

        case = classify_easy_case(details, num_res)
        if case is None:
            print(f"Skipping {uniprot_id}: not a valid easy case ({details}).")
            marker = path_final_ens / f"NOT_EASY_{uniprot_id}.txt"
            marker.write_text(
                f"{uniprot_id} was skipped by build_easy because its IDR ranges "
                f"are not terminal-only: {details}.\n"
                "Route this ID to medium/hard handling, or inspect the database if "
                "the first/last residue boundary is an off-by-one artifact.\n"
            )
            cleanup_glob(str(path_final_ens / "temp*"))
            continue

        print(f"Case: {case}")
        print(f"Building {nconfs} conformers for {uniprot_id}...")

        try:
            if case == "IDP":
                build_full_idp(sequence, path_final_ens)
            else:
                template_path = path_templates / f"{uniprot_id}_processed.pdb"
                write_folded_template(struc, details, template_path)

                n_len, c_len = terminal_lengths(case, details, num_res)
                print(
                    "Strategy: build + clash-filter + stitch "
                    f"(N_len={n_len}, C_len={c_len})"
                )
                build_terminal_filtered(
                    sequence=sequence,
                    details=details,
                    case=case,
                    af2_template_path=template_path,
                    path_final_ens=path_final_ens,
                    path_idrs=path_idrs,
                )

            postprocess_ensemble(path_final_ens, uniprot_id)
            print(f"Finished: {uniprot_id}")

        except NoSolutionAfterSamplingError as exc:
            print(f"ERROR for {uniprot_id}: {exc}")
            cleanup_glob(str(path_final_ens / "conformer*"))
            cleanup_glob(str(path_final_ens / "temp*"))
            cleanup_glob(str(path_final_ens / "*_idpcg_n*.pdb"))
            marker = path_final_ens / f"BUILD_PROBLEM_{uniprot_id}.txt"
            marker.write_text(
                "Unable to find any passing terminal IDR candidates after "
                f"{exc.batch_limit} batches for {exc.terminal_case}.\n"
                "This entry likely needs manual inspection or relaxed criteria.\n"
            )
            continue

        except Exception as exc:
            print(f"ERROR for {uniprot_id}: {exc}")
            raise


if __name__ == "__main__":
    main()
