"""
Profile folded-domain and IDR physico-chemical surface features from AlphaFlex/AFX
multi-model PDB ensembles using a master JSON with IDR residue boundaries.

Main idea:
  - Folded-domain surface chemistry is computed from FD-only SASA per model.
  - IDR sequence chemistry is computed from PDB-resolved IDR residues.
  - IDR complex-exposed surface chemistry is computed from full-complex SASA.
  - Anchor-local folded-domain patch chemistry is computed around folded residues
    immediately adjacent to each IDR interval.
  - FD-only exposed residues are now written explicitly to
    fd_surface_residues_by_model.csv. These rows exclude all master-json IDR
    intervals and are intended for non-anchor FD surface patch selection.
  - Spatially connected FD-only exposed patches are written to
    fd_surface_patches_by_model.csv.

Dependencies:
  pip install numpy pandas freesasa tqdm
Optional:
  pip install localcider

Example:
  python afx_surface_chemistry_profile.py \
      --pdb-dir ../AF_tm_ensembles/tmidr_popc_slab_easy \
      --master-json ../databases/min15_updated_PAE_master_db_fixed.json \
      --outdir afx_surface_chemistry \
      --n-workers 32 \
      --recursive
"""
import argparse
import concurrent.futures as cf
import json
import math
import os
import re
import sys
import tempfile
from collections import defaultdict
from concurrent.futures.process import BrokenProcessPool
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm

try:
    import freesasa
    freesasa.setVerbosity(freesasa.nowarnings)
except Exception as exc:  # pragma: no cover
    freesasa = None

try:
    from localcider.sequenceParameters import SequenceParameters  # type: ignore
except Exception:  # pragma: no cover
    SequenceParameters = None


AA3_TO_1 = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "HID": "H",
    "HIE": "H", "HIP": "H", "ILE": "I", "LEU": "L", "LYS": "K",
    "MET": "M", "MSE": "M", "PHE": "F", "PRO": "P", "SER": "S",
    "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V",
}

# Tien et al.-style theoretical maximum ASA values, Å^2. Used for RSA.
MAX_ASA_TIEN = {
    "A": 129.0, "R": 274.0, "N": 195.0, "D": 193.0, "C": 167.0,
    "Q": 223.0, "E": 225.0, "G": 104.0, "H": 224.0, "I": 197.0,
    "L": 201.0, "K": 236.0, "M": 224.0, "F": 240.0, "P": 159.0,
    "S": 155.0, "T": 172.0, "W": 285.0, "Y": 263.0, "V": 174.0,
}

KYTE_DOOLITTLE = {
    "I": 4.5, "V": 4.2, "L": 3.8, "F": 2.8, "C": 2.5, "M": 1.9,
    "A": 1.8, "G": -0.4, "T": -0.7, "S": -0.8, "W": -0.9,
    "Y": -1.3, "P": -1.6, "H": -3.2, "E": -3.5, "Q": -3.5,
    "D": -3.5, "N": -3.5, "K": -3.9, "R": -4.5,
}

AROMATIC = set("FYW")
PI_RESIDUES = set("FYWH")
HYDROPHOBIC = set("AVILMFWYPC")
POSITIVE_CANONICAL = set("KR")
NEGATIVE = set("DE")

ResidueKey = Tuple[str, int, str]


_WORKER_MASTER: Optional[Dict[str, dict]] = None
_WORKER_OPTS: Optional[dict] = None


@dataclass(frozen=True)
class Atom:
    line: str
    atom_name: str
    resname: str
    chain: str
    resseq: int
    icode: str
    element: str
    xyz: Tuple[float, float, float]

    @property
    def key(self) -> ResidueKey:
        return (self.chain, self.resseq, self.icode)


@dataclass
class Residue:
    key: ResidueKey
    chain: str
    resseq: int
    icode: str
    resname: str
    aa: str
    atoms: List[Atom]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Profile folded-domain and IDR surface chemistry for AFX multi-model PDB ensembles."
    )
    inp = p.add_mutually_exclusive_group(required=True)
    inp.add_argument("--pdb-dir", type=Path, help="Directory containing multi-model PDB files.")
    inp.add_argument("--pdb-file", type=Path, help="Single multi-model PDB file.")
    p.add_argument("--master-json", type=Path, required=True, help="Master JSON with IDR intervals keyed by UniProt ID.")
    p.add_argument("--outdir", type=Path, required=True, help="Output directory.")
    p.add_argument("--pattern", default="*.pdb", help="PDB glob pattern if --pdb-dir is used. Default: *.pdb")
    p.add_argument("--recursive", action="store_true", help="Recursively search --pdb-dir for PDB files.")
    p.add_argument("--chain", default=None, help="Optional chain ID to analyze. Default: all chains.")
    p.add_argument("--n-workers", type=int, default=1, help="Number of PDB files to process in parallel.")
    p.add_argument("--surface-rsa", type=float, default=0.25, help="RSA cutoff defining exposed residues. Default: 0.25")
    p.add_argument("--fd-patch-distance-cutoff", type=float, default=10.0,
                   help="CA/centroid distance cutoff in Å for clustering FD-only exposed residues into surface patches. Default: 10 Å")
    p.add_argument("--min-fd-patch-residues", type=int, default=5,
                   help="Minimum number of FD-only exposed residues required to write an FD surface patch row. Default: 5")
    p.add_argument("--skip-fd-surface-residue-table", action="store_true",
                   help="Do not write fd_surface_residues_by_model.csv/per-protein residue tables. Patch rows are still written.")
    p.add_argument("--anchor-radius", type=float, default=20.0, help="Å radius around IDR-adjacent folded anchors for local FD patch. Default: 20 Å")
    p.add_argument("--histidine-charge", type=float, default=0.1, help="Effective His charge used in sequence/charge features. Default: 0.1")
    p.add_argument("--model-stride", type=int, default=1, help="Analyze every Nth model. Default: 1")
    p.add_argument("--max-models", type=int, default=None, help="Maximum number of models to analyze per PDB.")
    p.add_argument("--checkpoint-every", type=int, default=100, help="Flush results to disk every N processed PDB files. Default: 100")
    p.add_argument("--restart", action="store_true", help="Start fresh in --outdir instead of resuming from an existing checkpoint.")
    p.add_argument("--retry-failed-only", action="store_true", help="When resuming from checkpoint, process only PDBs marked failed in checkpoint_manifest.csv.")
    p.add_argument("--max-tasks-per-child", type=int, default=25, help="Recycle worker processes after N tasks to reduce long-run worker instability. Set 0 to disable. Default: 25")
    p.add_argument("--write-per-protein", action="store_true", help="Also write per-protein CSV files.")
    return p.parse_args()


def load_master(path: Path) -> Dict[str, dict]:
    with open(path, "r") as fh:
        data = json.load(fh)
    return data


def find_pdbs(args: argparse.Namespace) -> List[Path]:
    if args.pdb_file:
        return [args.pdb_file]
    globber = args.pdb_dir.rglob if args.recursive else args.pdb_dir.glob
    return sorted([p for p in globber(args.pattern) if p.is_file()])


def infer_protein_id(pdb_path: Path, master_ids: Sequence[str]) -> Optional[str]:
    stem = pdb_path.stem
    if stem in master_ids:
        return stem
    first = re.split(r"[_\-.]", stem)[0]
    if first in master_ids:
        return first
    hits = [mid for mid in master_ids if mid in stem]
    if hits:
        return sorted(hits, key=len, reverse=True)[0]
    return None


def split_models(pdb_path: Path) -> List[List[str]]:
    models: List[List[str]] = []
    current: List[str] = []
    saw_model = False
    with open(pdb_path, "r", errors="replace") as fh:
        for line in fh:
            rec = line[:6].strip()
            if rec == "MODEL":
                saw_model = True
                if current:
                    models.append(current)
                    current = []
            elif rec in {"ATOM", "HETATM"}:
                current.append(line.rstrip("\n"))
            elif rec == "ENDMDL":
                if current:
                    models.append(current)
                    current = []
    if current:
        models.append(current)
    # If no MODEL records, models contains the whole file as one model.
    return models


def normalize_chain(chain: str) -> str:
    c = chain.strip()
    return c if c else "_"


def guess_element(atom_name: str, element_field: str) -> str:
    e = element_field.strip().upper()
    if e:
        return e
    letters = "".join([c for c in atom_name.strip() if c.isalpha()])
    if not letters:
        return ""
    if len(letters) >= 2 and letters[:2].upper() in {"CL", "BR", "NA", "MG", "ZN", "FE", "CA"}:
        return letters[:2].upper()
    return letters[0].upper()


def _clean_pdb_numeric_text(line: str) -> str:
    """Normalize a few characters that occasionally appear in generated PDBs."""
    # Some malformed outputs contain U+00AF (macron) where a minus sign should be.
    # Also normalize Unicode minus variants just in case.
    return (
        line.replace("\u00af", "-")
            .replace("\u2212", "-")
            .replace("\u2013", "-")
            .replace("\u2014", "-")
    )


def _parse_chain_resseq_token(tok: str) -> Tuple[str, int, str]:
    """Parse tokens like 'A', '95' or combined tokens like 'A1121'."""
    tok = tok.strip()
    m = re.match(r"^([A-Za-z_]?)(-?\d+)([A-Za-z]?)$", tok)
    if not m:
        raise ValueError(f"cannot parse chain/residue token: {tok}")
    chain = normalize_chain(m.group(1))
    resseq = int(m.group(2))
    icode = m.group(3) or ""
    return chain, resseq, icode


def parse_atom_line(line: str) -> Optional[Atom]:
    """Parse ATOM/HETATM lines robustly.

    AFX/IDPCG-generated PDBs can contain valid coordinates in whitespace form but
    invalid fixed-width coordinate columns, for example x=15.87 instead of 15.870,
    or a malformed minus sign. We first try standard fixed-width PDB parsing, then
    fall back to whitespace-token parsing.
    """
    line = _clean_pdb_numeric_text(line.rstrip("\n"))
    if not line.startswith(("ATOM", "HETATM")):
        return None

    # Standard fixed-width PDB parse.
    try:
        atom_name = line[12:16].strip()
        resname = line[17:20].strip().upper()
        if resname not in AA3_TO_1:
            return None
        chain = normalize_chain(line[21:22])
        resseq = int(line[22:26].strip())
        icode = line[26:27].strip()
        x = float(line[30:38])
        y = float(line[38:46])
        z = float(line[46:54])
        element = guess_element(atom_name, line[76:78] if len(line) >= 78 else "")
        return Atom(line=line, atom_name=atom_name, resname=resname, chain=chain,
                    resseq=resseq, icode=icode, element=element, xyz=(x, y, z))
    except Exception:
        pass

    # Whitespace-token fallback. Handles both:
    # ATOM 1623 CB ALA A 95 3.219 -30.529 -93.676 ... C
    # ATOM 17021 O HIS A1121 26.433 -84.22 85.008 ... O
    try:
        toks = line.split()
        if len(toks) < 8 or toks[0] not in {"ATOM", "HETATM"}:
            return None
        atom_name = toks[2].strip()
        resname = toks[3].strip().upper()
        if resname not in AA3_TO_1:
            return None

        if re.match(r"^[A-Za-z_]-?\d+[A-Za-z]?$", toks[4]):
            chain, resseq, icode = _parse_chain_resseq_token(toks[4])
            coord_i = 5
        else:
            chain = normalize_chain(toks[4])
            resseq = int(re.match(r"^-?\d+", toks[5]).group(0))
            m_icode = re.match(r"^-?\d+([A-Za-z])$", toks[5])
            icode = m_icode.group(1) if m_icode else ""
            coord_i = 6
        x = float(toks[coord_i])
        y = float(toks[coord_i + 1])
        z = float(toks[coord_i + 2])
        element = guess_element(atom_name, toks[-1] if toks else "")
        return Atom(line=line, atom_name=atom_name, resname=resname, chain=chain,
                    resseq=resseq, icode=icode, element=element, xyz=(x, y, z))
    except Exception:
        return None


def format_atom_line(atom: Atom, serial: int) -> str:
    """Return strict fixed-width PDB line acceptable to FreeSASA."""
    record = "ATOM"
    name = atom.atom_name.strip()
    # PDB convention: one-letter atom names are right-shifted within the 4-char field.
    name_field = f" {name:<3}" if len(name) < 4 and not name[0].isdigit() else f"{name:<4}"[:4]
    chain = " " if atom.chain == "_" else atom.chain[:1]
    icode = atom.icode[:1] if atom.icode else " "
    elem = (atom.element or guess_element(atom.atom_name, "") or "").strip().upper()[:2]
    x, y, z = atom.xyz
    return (
        f"{record:<6}{serial:5d} {name_field}{' ':1}{atom.resname:>3} {chain:1}"
        f"{atom.resseq:4d}{icode:1}   {x:8.3f}{y:8.3f}{z:8.3f}"
        f"  1.00  0.00          {elem:>2}"
    )


def parse_residues(model_lines: List[str], chain_filter: Optional[str] = None) -> Dict[ResidueKey, Residue]:
    atoms_by_key: Dict[ResidueKey, List[Atom]] = defaultdict(list)
    resname_by_key: Dict[ResidueKey, str] = {}
    wanted_chain = normalize_chain(chain_filter) if chain_filter else None
    for line in model_lines:
        atom = parse_atom_line(line)
        if atom is None:
            continue
        if wanted_chain is not None and atom.chain != wanted_chain:
            continue
        atoms_by_key[atom.key].append(atom)
        resname_by_key[atom.key] = atom.resname
    residues = {}
    for key, atoms in atoms_by_key.items():
        resname = resname_by_key[key]
        aa = AA3_TO_1.get(resname, "X")
        residues[key] = Residue(
            key=key, chain=key[0], resseq=key[1], icode=key[2],
            resname=resname, aa=aa, atoms=atoms,
        )
    return residues


def sorted_residues(residues: Dict[ResidueKey, Residue]) -> List[Residue]:
    return sorted(residues.values(), key=lambda r: (r.chain, r.resseq, r.icode))


def is_in_idr(resseq: int, idrs: Sequence[Sequence[int]]) -> bool:
    return any(int(start) <= resseq <= int(end) for start, end in idrs)


def idr_label_for_resseq(resseq: int, idrs: Sequence[Sequence[int]]) -> Optional[str]:
    for i, (start, end) in enumerate(idrs, start=1):
        if int(start) <= resseq <= int(end):
            return f"IDR{i}"
    return None


def residue_coord(res: Residue) -> Optional[np.ndarray]:
    # Prefer CA; otherwise use heavy-atom centroid.
    for a in res.atoms:
        if a.atom_name == "CA":
            return np.asarray(a.xyz, dtype=float)
    coords = [a.xyz for a in res.atoms if a.element != "H"]
    if not coords:
        coords = [a.xyz for a in res.atoms]
    if not coords:
        return None
    return np.asarray(coords, dtype=float).mean(axis=0)


def write_temp_pdb(lines: Iterable[str], tmpdir: str) -> str:
    fd, path = tempfile.mkstemp(suffix=".pdb", dir=tmpdir, text=True)
    with os.fdopen(fd, "w") as fh:
        for line in lines:
            fh.write(line.rstrip("\n") + "\n")
        fh.write("END\n")
    return path


def key_from_line(line: str) -> Optional[ResidueKey]:
    atom = parse_atom_line(line)
    return atom.key if atom is not None else None


def filtered_lines_by_keys(model_lines: List[str], keys: Optional[set]) -> List[str]:
    """Select atoms and rewrite them as strict fixed-width PDB records.

    This prevents FreeSASA from failing on technically invalid PDB coordinate
    columns produced by some generators.
    """
    out = []
    serial = 1
    for ln in model_lines:
        atom = parse_atom_line(ln)
        if atom is None:
            continue
        if keys is not None and atom.key not in keys:
            continue
        out.append(format_atom_line(atom, serial))
        serial += 1
    return out


def parse_freesasa_resnum(resnum: str) -> Tuple[Optional[int], str]:
    s = str(resnum)
    m = re.search(r"-?\d+", s)
    if not m:
        return None, ""
    n = int(m.group(0))
    rest = s[m.end():].strip()
    icode = rest[0] if rest else ""
    return n, icode


def calc_sasa(model_lines: List[str], keys: Optional[set], tmpdir: str) -> Dict[ResidueKey, float]:
    if freesasa is None:
        raise RuntimeError("freesasa is required. Install with: pip install freesasa")
    selected = filtered_lines_by_keys(model_lines, keys)
    if not selected:
        return {}
    path = write_temp_pdb(selected, tmpdir)
    try:
        structure = freesasa.Structure(path)
        result = freesasa.calc(structure)
        areas = result.residueAreas()
        out: Dict[ResidueKey, float] = {}
        # Map by chain/residue number; insertion codes are rare and treated conservatively.
        valid_keys = set()
        for ln in selected:
            k = key_from_line(ln)
            if k is not None:
                valid_keys.add(k)
        by_chain_resseq = defaultdict(list)
        for k in valid_keys:
            by_chain_resseq[(k[0], k[1])].append(k)
        for chain_raw, chain_areas in areas.items():
            chain = normalize_chain(str(chain_raw))
            for resnum_raw, area_obj in chain_areas.items():
                resseq, icode = parse_freesasa_resnum(str(resnum_raw))
                if resseq is None:
                    continue
                candidates = by_chain_resseq.get((chain, resseq), [])
                if not candidates and chain == "_":
                    candidates = by_chain_resseq.get((" ", resseq), [])
                if not candidates:
                    continue
                # Prefer exact insertion code when available.
                chosen = None
                for c in candidates:
                    if c[2] == icode:
                        chosen = c
                        break
                if chosen is None:
                    chosen = candidates[0]
                out[chosen] = float(area_obj.total)
        return out
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def rsa_for_key(key: ResidueKey, sasa: Dict[ResidueKey, float], residues: Dict[ResidueKey, Residue]) -> float:
    aa = residues[key].aa
    max_asa = MAX_ASA_TIEN.get(aa)
    if max_asa is None or max_asa <= 0:
        return float("nan")
    return sasa.get(key, 0.0) / max_asa


def charge_of_aa(aa: str, histidine_charge: float) -> float:
    if aa in NEGATIVE:
        return -1.0
    if aa in POSITIVE_CANONICAL:
        return 1.0
    if aa == "H":
        return float(histidine_charge)
    return 0.0


def safe_mean(values: List[float]) -> float:
    vals = [v for v in values if v is not None and not (isinstance(v, float) and math.isnan(v))]
    return float(np.mean(vals)) if vals else float("nan")


def sequence_scd(seq: str, histidine_charge: float) -> float:
    # Simple sequence charge decoration metric: sum_{i<j} q_i q_j sqrt(|j-i|) / N.
    # Useful as a signed charge-patterning descriptor, not meant as a full localCIDER replacement.
    n = len(seq)
    if n == 0:
        return float("nan")
    q = np.array([charge_of_aa(a, histidine_charge) for a in seq], dtype=float)
    total = 0.0
    for i in range(n):
        if q[i] == 0:
            continue
        for j in range(i + 1, n):
            if q[j] == 0:
                continue
            total += q[i] * q[j] * math.sqrt(j - i)
    return total / n


def chemistry_features_from_sequence(seq: str, histidine_charge: float, prefix: str = "") -> Dict[str, float]:
    L = len(seq)
    q = [charge_of_aa(a, histidine_charge) for a in seq]
    out: Dict[str, float] = {
        f"{prefix}length": L,
        f"{prefix}net_charge": float(sum(q)) if L else float("nan"),
        f"{prefix}ncpr": float(sum(q) / L) if L else float("nan"),
        f"{prefix}fcr": float(sum(1 for a in seq if a in NEGATIVE or a in POSITIVE_CANONICAL or (a == "H" and histidine_charge != 0.0)) / L) if L else float("nan"),
        f"{prefix}positive_fraction": float(sum(1 for a in seq if a in POSITIVE_CANONICAL or (a == "H" and histidine_charge > 0.0)) / L) if L else float("nan"),
        f"{prefix}negative_fraction": float(sum(1 for a in seq if a in NEGATIVE) / L) if L else float("nan"),
        f"{prefix}aromatic_fraction": float(sum(1 for a in seq if a in AROMATIC) / L) if L else float("nan"),
        f"{prefix}pi_fraction": float(sum(1 for a in seq if a in PI_RESIDUES) / L) if L else float("nan"),
        f"{prefix}hydrophobic_fraction": float(sum(1 for a in seq if a in HYDROPHOBIC) / L) if L else float("nan"),
        f"{prefix}gly_fraction": float(seq.count("G") / L) if L else float("nan"),
        f"{prefix}pro_fraction": float(seq.count("P") / L) if L else float("nan"),
        f"{prefix}mean_kd_hydropathy": safe_mean([KYTE_DOOLITTLE.get(a, float("nan")) for a in seq]),
        f"{prefix}scd_simple": sequence_scd(seq, histidine_charge),
    }
    if SequenceParameters is not None and L > 0:
        try:
            sp = SequenceParameters(seq)
            for name, func in [
                ("localcider_ncpr", "get_NCPR"),
                ("localcider_fcr", "get_FCR"),
                ("localcider_kappa", "get_kappa"),
                ("localcider_mean_hydropathy", "get_mean_hydropathy"),
                ("localcider_fraction_disorder_promoting", "get_fraction_disorder_promoting"),
            ]:
                try:
                    out[f"{prefix}{name}"] = float(getattr(sp, func)())
                except Exception:
                    out[f"{prefix}{name}"] = float("nan")
        except Exception:
            pass
    return out


def chemistry_features_from_residues(res_list: Sequence[Residue], histidine_charge: float, prefix: str = "") -> Dict[str, float]:
    seq = "".join(r.aa for r in sorted(res_list, key=lambda r: (r.chain, r.resseq, r.icode)) if r.aa != "X")
    return chemistry_features_from_sequence(seq, histidine_charge, prefix=prefix)


def find_anchor_keys(
    residues: Dict[ResidueKey, Residue],
    fd_keys: set,
    start: int,
    end: int,
    ) -> List[ResidueKey]:
        anchors = []
        chains = sorted({k[0] for k in residues})
        for chain in chains:
            before = [k for k in fd_keys if k[0] == chain and k[1] < start]
            after = [k for k in fd_keys if k[0] == chain and k[1] > end]
            if before:
                anchors.append(max(before, key=lambda k: k[1]))
            if after:
                anchors.append(min(after, key=lambda k: k[1]))
        # Unique while preserving order.
        seen = set()
        out = []
        for k in anchors:
            if k not in seen:
                seen.add(k)
                out.append(k)
        return out


def patch_keys_around_anchors(
    residues: Dict[ResidueKey, Residue],
    candidate_keys: set,
    anchor_keys: Sequence[ResidueKey],
    radius: float,
    ) -> set:
        anchor_coords = []
        for k in anchor_keys:
            res = residues.get(k)
            if res is None:
                continue
            c = residue_coord(res)
            if c is not None:
                anchor_coords.append(c)
        if not anchor_coords:
            return set()
        anchors = np.vstack(anchor_coords)
        out = set()
        for k in candidate_keys:
            res = residues.get(k)
            if res is None:
                continue
            c = residue_coord(res)
            if c is None:
                continue
            if np.min(np.linalg.norm(anchors - c, axis=1)) <= radius:
                out.add(k)
        return out


def min_sequence_distance_to_intervals(resseq: int, idrs: Sequence[Sequence[int]]) -> float:
    """Minimum sequence distance from a folded-domain residue to any IDR interval."""
    distances = []
    for start, end in idrs:
        start_i = int(start)
        end_i = int(end)
        if resseq < start_i:
            distances.append(start_i - resseq)
        elif resseq > end_i:
            distances.append(resseq - end_i)
        else:
            distances.append(0)
    return float(min(distances)) if distances else float("nan")


def min_key_sequence_distance(key: ResidueKey, anchor_keys: Sequence[ResidueKey]) -> float:
    same_chain = [abs(int(key[1]) - int(a[1])) for a in anchor_keys if a[0] == key[0]]
    return float(min(same_chain)) if same_chain else float("nan")


def min_coord_distance_to_keys(
    key: ResidueKey,
    residues: Dict[ResidueKey, Residue],
    target_keys: Sequence[ResidueKey],
    ) -> float:
        res = residues.get(key)
        if res is None:
            return float("nan")
        c = residue_coord(res)
        if c is None:
            return float("nan")
        coords = []
        for tk in target_keys:
            tres = residues.get(tk)
            if tres is None:
                continue
            tc = residue_coord(tres)
            if tc is not None:
                coords.append(tc)
        if not coords:
            return float("nan")
        arr = np.vstack(coords)
        return float(np.min(np.linalg.norm(arr - c, axis=1)))


def aa_boolean_features(aa: str, histidine_charge: float) -> Dict[str, float]:
    return {
        "charge": charge_of_aa(aa, histidine_charge),
        "is_positive": float(aa in POSITIVE_CANONICAL or (aa == "H" and histidine_charge > 0.0)),
        "is_negative": float(aa in NEGATIVE),
        "is_charged": float(aa in POSITIVE_CANONICAL or aa in NEGATIVE or (aa == "H" and histidine_charge != 0.0)),
        "is_hydrophobic": float(aa in HYDROPHOBIC),
        "is_aromatic": float(aa in AROMATIC),
        "is_pi": float(aa in PI_RESIDUES),
        "kd_hydropathy": float(KYTE_DOOLITTLE.get(aa, float("nan"))),
    }


def union_find_components_by_distance(
    keys: Sequence[ResidueKey],
    coords: Dict[ResidueKey, np.ndarray],
    cutoff: float,
    ) -> List[List[ResidueKey]]:
        """Cluster keys by spatial connected components without requiring scipy."""
        keys = [k for k in keys if k in coords]
        if not keys:
            return []
        cutoff = float(cutoff)
        if cutoff <= 0:
            return [[k] for k in keys]
        parent = {k: k for k in keys}
        rank = {k: 0 for k in keys}

        def find(x: ResidueKey) -> ResidueKey:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a: ResidueKey, b: ResidueKey) -> None:
            ra, rb = find(a), find(b)
            if ra == rb:
                return
            if rank[ra] < rank[rb]:
                parent[ra] = rb
            elif rank[ra] > rank[rb]:
                parent[rb] = ra
            else:
                parent[rb] = ra
                rank[ra] += 1

        # Grid hashing: only compare residues in the same or adjacent grid cells.
        grid: Dict[Tuple[int, int, int], List[ResidueKey]] = defaultdict(list)
        for k in keys:
            cell = tuple(np.floor(coords[k] / cutoff).astype(int).tolist())
            grid[cell].append(k)

        neighbor_offsets = [(dx, dy, dz) for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1)]
        cutoff2 = cutoff * cutoff
        for cell, members in grid.items():
            for k in members:
                ck = coords[k]
                for off in neighbor_offsets:
                    neigh = (cell[0] + off[0], cell[1] + off[1], cell[2] + off[2])
                    for j in grid.get(neigh, []):
                        if j <= k:
                            continue
                        diff = ck - coords[j]
                        if float(np.dot(diff, diff)) <= cutoff2:
                            union(k, j)

        comps: Dict[ResidueKey, List[ResidueKey]] = defaultdict(list)
        for k in keys:
            comps[find(k)].append(k)
        return list(comps.values())


def make_fd_surface_residue_rows(
    protein_id: str,
    pdb_path: Path,
    model_index: int,
    residues: Dict[ResidueKey, Residue],
    fd_surface_keys: set,
    fd_sasa: Dict[ResidueKey, float],
    idrs: Sequence[Sequence[int]],
    anchor_keys: Sequence[ResidueKey],
    histidine_charge: float,
    ) -> List[dict]:
        rows: List[dict] = []
        for k in sorted(fd_surface_keys, key=lambda x: (x[0], x[1], x[2])):
            r = residues.get(k)
            if r is None:
                continue
            c = residue_coord(r)
            if c is None:
                x = y = z = float("nan")
            else:
                x, y, z = map(float, c.tolist())
            row = {
                "protein_id": protein_id,
                "pdb_file": str(pdb_path),
                "model_index": model_index,
                "chain": k[0],
                "resseq": int(k[1]),
                "icode": k[2],
                "resname": r.resname,
                "aa": r.aa,
                "region": "FD",
                "is_fd_surface": 1,
                "sasa_fd_only": float(fd_sasa.get(k, float("nan"))),
                "rsa_fd_only": float(rsa_for_key(k, fd_sasa, residues)),
                "coord_x": x,
                "coord_y": y,
                "coord_z": z,
                "min_seq_distance_to_any_idr": min_sequence_distance_to_intervals(int(k[1]), idrs),
                "min_seq_distance_to_any_anchor": min_key_sequence_distance(k, anchor_keys),
                "min_spatial_distance_to_any_anchor_A": min_coord_distance_to_keys(k, residues, anchor_keys),
                "is_anchor_residue": int(k in set(anchor_keys)),
            }
            row.update(aa_boolean_features(r.aa, histidine_charge))
            rows.append(row)
        return rows


def make_fd_surface_patch_rows(
    protein_id: str,
    pdb_path: Path,
    model_index: int,
    residues: Dict[ResidueKey, Residue],
    fd_surface_keys: set,
    fd_sasa: Dict[ResidueKey, float],
    idrs: Sequence[Sequence[int]],
    anchor_keys: Sequence[ResidueKey],
    histidine_charge: float,
    distance_cutoff: float,
    min_patch_residues: int,
    ) -> List[dict]:
        coords: Dict[ResidueKey, np.ndarray] = {}
        for k in fd_surface_keys:
            r = residues.get(k)
            if r is None:
                continue
            c = residue_coord(r)
            if c is not None:
                coords[k] = c
        components = union_find_components_by_distance(
            sorted(fd_surface_keys, key=lambda x: (x[0], x[1], x[2])), coords, distance_cutoff
        )
        rows: List[dict] = []
        patch_idx = 0
        for comp in sorted(components, key=lambda cc: (-len(cc), min(k[1] for k in cc), min(k[0] for k in cc))):
            if len(comp) < int(min_patch_residues):
                continue
            patch_idx += 1
            comp = sorted(comp, key=lambda x: (x[0], x[1], x[2]))
            comp_res = [residues[k] for k in comp if k in residues]
            comp_coords = np.vstack([coords[k] for k in comp if k in coords])
            centroid = comp_coords.mean(axis=0) if len(comp_coords) else np.array([np.nan, np.nan, np.nan])
            residue_numbers = ";".join(f"{k[0]}:{k[1]}{k[2]}" for k in comp)
            seq_dists = [min_sequence_distance_to_intervals(int(k[1]), idrs) for k in comp]
            anchor_seq_dists = [min_key_sequence_distance(k, anchor_keys) for k in comp]
            anchor_xyz_dists = [min_coord_distance_to_keys(k, residues, anchor_keys) for k in comp]
            valid_anchor_xyz = [d for d in anchor_xyz_dists if math.isfinite(d)]
            row = {
                "protein_id": protein_id,
                "pdb_file": str(pdb_path),
                "model_index": model_index,
                "fd_patch_id": f"FDpatch{patch_idx}",
                "fd_patch_distance_cutoff_A": float(distance_cutoff),
                "n_fd_surface_residues": len(comp),
                "chains": ";".join(sorted(set(k[0] for k in comp))),
                "patch_residue_keys": residue_numbers,
                "patch_seq_min": int(min(k[1] for k in comp)),
                "patch_seq_max": int(max(k[1] for k in comp)),
                "centroid_x": float(centroid[0]),
                "centroid_y": float(centroid[1]),
                "centroid_z": float(centroid[2]),
                "mean_fd_surface_rsa": safe_mean([rsa_for_key(k, fd_sasa, residues) for k in comp]),
                "min_seq_distance_to_any_idr": float(np.nanmin(seq_dists)) if seq_dists else float("nan"),
                "min_seq_distance_to_any_anchor": float(np.nanmin(anchor_seq_dists)) if anchor_seq_dists else float("nan"),
                "min_spatial_distance_to_any_anchor_A": float(min(valid_anchor_xyz)) if valid_anchor_xyz else float("nan"),
            }
            row.update(chemistry_features_from_residues(comp_res, histidine_charge, prefix="patch_"))
            rows.append(row)
        return rows


def process_one_pdb(payload: Tuple[str, dict, dict]) -> dict:
    pdb_path_s, master, opts = payload
    pdb_path = Path(pdb_path_s)
    pid = infer_protein_id(pdb_path, list(master.keys()))
    warnings = []
    if pid is None:
        return {"protein_id": None, "pdb": str(pdb_path), "model_rows": [], "idr_rows": [], "warnings": ["Could not infer protein ID from filename."]}
    if "idrs" not in master[pid]:
        return {"protein_id": pid, "pdb": str(pdb_path), "model_rows": [], "idr_rows": [], "warnings": ["No 'idrs' field in master JSON."]}
    idrs = master[pid].get("idrs", [])
    models = split_models(pdb_path)
    if opts["model_stride"] > 1:
        models = models[:: opts["model_stride"]]
    if opts["max_models"] is not None:
        models = models[: opts["max_models"]]
    model_rows = []
    idr_rows = []
    fd_surface_residue_rows = []
    fd_patch_rows = []

    with tempfile.TemporaryDirectory(prefix="afx_sasa_") as tmpdir:
        for m_idx, lines in enumerate(models, start=1):
            residues = parse_residues(lines, chain_filter=opts.get("chain"))
            if not residues:
                warnings.append(f"model {m_idx}: no protein residues parsed")
                continue
            keys_all = set(residues)
            idr_keys = {k for k, r in residues.items() if is_in_idr(r.resseq, idrs)}
            fd_keys = keys_all - idr_keys
            missing_intervals = []
            for ii, (start, end) in enumerate(idrs, start=1):
                present = [k for k in idr_keys if int(start) <= k[1] <= int(end)]
                if not present:
                    missing_intervals.append(f"IDR{ii}:{start}-{end}")
            if missing_intervals:
                warnings.append(f"model {m_idx}: no residues found for {','.join(missing_intervals)}")
            if not fd_keys:
                warnings.append(f"model {m_idx}: no folded-domain residues after applying IDR intervals")

            try:
                fd_sasa = calc_sasa(lines, fd_keys, tmpdir) if fd_keys else {}
                full_sasa = calc_sasa(lines, keys_all, tmpdir) if keys_all else {}
            except Exception as exc:
                warnings.append(
                    f"model {m_idx}: FreeSASA failed after PDB sanitization; skipping model: "
                    f"{type(exc).__name__}: {exc}"
                )
                continue

            fd_surface_keys = {
                k for k in fd_keys
                if k in fd_sasa and rsa_for_key(k, fd_sasa, residues) >= opts["surface_rsa"]
            }
            idr_complex_surface_keys = {
                k for k in idr_keys
                if k in full_sasa and rsa_for_key(k, full_sasa, residues) >= opts["surface_rsa"]
            }

            fd_surface_res = [residues[k] for k in fd_surface_keys]
            idr_surface_res = [residues[k] for k in idr_complex_surface_keys]
            fd_all_res = [residues[k] for k in fd_keys]
            idr_all_res = [residues[k] for k in idr_keys]

            row = {
                "protein_id": pid,
                "pdb_file": str(pdb_path),
                "model_index": m_idx,
                "n_models_in_file_analyzed": len(models),
                "n_residues_total": len(keys_all),
                "n_fd_residues": len(fd_keys),
                "n_idr_residues": len(idr_keys),
                "n_fd_surface_residues": len(fd_surface_keys),
                "n_idr_complex_surface_residues": len(idr_complex_surface_keys),
                "fd_surface_fraction": len(fd_surface_keys) / len(fd_keys) if fd_keys else float("nan"),
                "idr_complex_surface_fraction": len(idr_complex_surface_keys) / len(idr_keys) if idr_keys else float("nan"),
                "mean_fd_surface_rsa": safe_mean([rsa_for_key(k, fd_sasa, residues) for k in fd_surface_keys]),
                "mean_idr_complex_surface_rsa": safe_mean([rsa_for_key(k, full_sasa, residues) for k in idr_complex_surface_keys]),
            }
            row.update(chemistry_features_from_residues(fd_all_res, opts["histidine_charge"], prefix="fd_all_"))
            row.update(chemistry_features_from_residues(fd_surface_res, opts["histidine_charge"], prefix="fd_surface_"))
            row.update(chemistry_features_from_residues(idr_all_res, opts["histidine_charge"], prefix="idr_all_"))
            row.update(chemistry_features_from_residues(idr_surface_res, opts["histidine_charge"], prefix="idr_complex_surface_"))
            model_rows.append(row)

            # Precompute all folded anchor residues for this model. These are
            # used only to annotate distances; FD surface residue/patch rows
            # are still strictly FD-only because they are drawn from fd_surface_keys.
            anchor_keys_by_idr = {}
            all_anchor_keys = []
            for ii_tmp, (start_tmp, end_tmp) in enumerate(idrs, start=1):
                these_anchor_keys = find_anchor_keys(residues, fd_keys, int(start_tmp), int(end_tmp))
                anchor_keys_by_idr[f"IDR{ii_tmp}"] = these_anchor_keys
                all_anchor_keys.extend(these_anchor_keys)
            seen_anchor = set()
            all_anchor_keys = [k for k in all_anchor_keys if not (k in seen_anchor or seen_anchor.add(k))]

            if not opts.get("skip_fd_surface_residue_table", False):
                fd_surface_residue_rows.extend(make_fd_surface_residue_rows(
                    pid, pdb_path, m_idx, residues, fd_surface_keys, fd_sasa, idrs,
                    all_anchor_keys, opts["histidine_charge"]
                ))
            fd_patch_rows.extend(make_fd_surface_patch_rows(
                pid, pdb_path, m_idx, residues, fd_surface_keys, fd_sasa, idrs,
                all_anchor_keys, opts["histidine_charge"],
                opts["fd_patch_distance_cutoff"], opts["min_fd_patch_residues"]
            ))

            for ii, (start, end) in enumerate(idrs, start=1):
                interval_keys = {k for k in idr_keys if int(start) <= k[1] <= int(end)}
                interval_surface_keys = interval_keys & idr_complex_surface_keys
                anchor_keys = anchor_keys_by_idr.get(f"IDR{ii}", find_anchor_keys(residues, fd_keys, int(start), int(end)))
                patch_keys = patch_keys_around_anchors(
                    residues, fd_surface_keys, anchor_keys, opts["anchor_radius"]
                )
                interval_res = [residues[k] for k in interval_keys]
                interval_surface_res = [residues[k] for k in interval_surface_keys]
                patch_res = [residues[k] for k in patch_keys]
                anchor_labels = ";".join([f"{k[0]}:{k[1]}{k[2]}" for k in anchor_keys])
                idr_row = {
                    "protein_id": pid,
                    "pdb_file": str(pdb_path),
                    "model_index": m_idx,
                    "idr_label": f"IDR{ii}",
                    "idr_start": int(start),
                    "idr_end": int(end),
                    "n_idr_residues_present": len(interval_keys),
                    "n_idr_complex_surface_residues": len(interval_surface_keys),
                    "idr_complex_surface_fraction": len(interval_surface_keys) / len(interval_keys) if interval_keys else float("nan"),
                    "anchor_keys": anchor_labels,
                    "n_anchor_keys": len(anchor_keys),
                    "anchor_patch_radius_A": opts["anchor_radius"],
                    "n_fd_anchor_patch_surface_residues": len(patch_keys),
                    "mean_fd_anchor_patch_surface_rsa": safe_mean([rsa_for_key(k, fd_sasa, residues) for k in patch_keys]),
                }
                idr_row.update(chemistry_features_from_residues(interval_res, opts["histidine_charge"], prefix="idr_seq_"))
                idr_row.update(chemistry_features_from_residues(interval_surface_res, opts["histidine_charge"], prefix="idr_complex_surface_"))
                idr_row.update(chemistry_features_from_residues(patch_res, opts["histidine_charge"], prefix="fd_anchor_patch_surface_"))
                idr_rows.append(idr_row)

    return {
        "protein_id": pid,
        "pdb": str(pdb_path),
        "model_rows": model_rows,
        "idr_rows": idr_rows,
        "fd_surface_residue_rows": fd_surface_residue_rows,
        "fd_patch_rows": fd_patch_rows,
        "warnings": warnings,
    }


def init_worker(master: Dict[str, dict], opts: dict) -> None:
    """Initialize per-process worker state to avoid re-sending large payloads per task."""
    global _WORKER_MASTER, _WORKER_OPTS
    _WORKER_MASTER = master
    _WORKER_OPTS = opts


def process_one_pdb_in_worker(pdb_path_s: str) -> dict:
    if _WORKER_MASTER is None or _WORKER_OPTS is None:
        raise RuntimeError("worker not initialized")
    return process_one_pdb((pdb_path_s, _WORKER_MASTER, _WORKER_OPTS))


def summarize_numeric(df: pd.DataFrame, group_cols: List[str]) -> pd.DataFrame:
    if df.empty:
        return df
    numeric_cols = [c for c in df.columns if c not in group_cols and pd.api.types.is_numeric_dtype(df[c])]
    if not numeric_cols:
        return df[group_cols].drop_duplicates()
    summary = df.groupby(group_cols, dropna=False)[numeric_cols].agg(["mean", "std", "min", "max"])
    summary.columns = [f"{a}_{b}" for a, b in summary.columns]
    return summary.reset_index()



def append_rows_csv(path: Path, rows: List[dict]) -> None:
    """Append rows to a CSV, creating it with a header if needed."""
    if not rows:
        return
    df = pd.DataFrame(rows)
    header = not path.exists() or path.stat().st_size == 0
    df.to_csv(path, mode="a", header=header, index=False)


def load_existing_csv(path: Path) -> pd.DataFrame:
    """Load an existing CSV if it exists; otherwise return an empty DataFrame."""
    if path.exists() and path.stat().st_size > 0:
        try:
            return pd.read_csv(path)
        except pd.errors.EmptyDataError:
            return pd.DataFrame()
    return pd.DataFrame()


def initialize_outputs(args: argparse.Namespace) -> Dict[str, Path]:
    """Create output file map and optionally remove prior checkpointed outputs."""
    files = {
        "model": args.outdir / "surface_chemistry_by_model.csv",
        "idr": args.outdir / "idr_surface_chemistry_by_model.csv",
        "fd_surface_residues": args.outdir / "fd_surface_residues_by_model.csv",
        "fd_patches": args.outdir / "fd_surface_patches_by_model.csv",
        "warnings": args.outdir / "warnings.csv",
        "manifest": args.outdir / "checkpoint_manifest.csv",
    }
    if args.restart:
        for p in files.values():
            if p.exists():
                p.unlink()
        for p in [
            args.outdir / "surface_chemistry_summary_by_protein.csv",
            args.outdir / "idr_surface_chemistry_summary.csv",
            args.outdir / "fd_surface_patches_summary.csv",
        ]:
            if p.exists():
                p.unlink()
    return files


def load_completed_pdbs(manifest_path: Path) -> set[str]:
    """Return PDB paths already completed in a prior checkpointed run."""
    if not manifest_path.exists() or manifest_path.stat().st_size == 0:
        return set()
    try:
        df = pd.read_csv(manifest_path)
    except Exception:
        return set()
    if "status" not in df.columns or "pdb_file" not in df.columns:
        return set()
    done = df[df["status"].astype(str).str.lower() == "done"]
    return set(done["pdb_file"].astype(str).tolist())


def normalize_pdb_path(path_like: str) -> str:
    try:
        return str(Path(path_like).resolve())
    except Exception:
        return str(Path(path_like))


def load_manifest_statuses(manifest_path: Path) -> Dict[str, str]:
    """Load latest known status per PDB path from checkpoint manifest."""
    if not manifest_path.exists() or manifest_path.stat().st_size == 0:
        return {}
    try:
        df = pd.read_csv(manifest_path)
    except Exception:
        return {}
    if "status" not in df.columns or "pdb_file" not in df.columns:
        return {}
    statuses: Dict[str, str] = {}
    for _, row in df.iterrows():
        pdb_file = normalize_pdb_path(str(row.get("pdb_file", "")))
        status = str(row.get("status", "")).strip().lower()
        if pdb_file:
            statuses[pdb_file] = status
    return statuses


def failure_result(pdb_path_s: str, exc: Exception) -> dict:
    return {
        "protein_id": None,
        "pdb": str(pdb_path_s),
        "model_rows": [],
        "idr_rows": [],
        "fd_surface_residue_rows": [],
        "fd_patch_rows": [],
        "warnings": [f"worker-level failure: {type(exc).__name__}: {exc}"],
    }


def flush_results(
    batch_results: List[dict],
    args: argparse.Namespace,
    filemap: Dict[str, Path],
    per_protein_dir: Path,
    ) -> Dict[str, int]:
        """Write one checkpoint batch to disk and return row counts."""
        all_model_rows: List[dict] = []
        all_idr_rows: List[dict] = []
        all_fd_surface_residue_rows: List[dict] = []
        all_fd_patch_rows: List[dict] = []
        warning_rows: List[dict] = []
        manifest_rows: List[dict] = []
    
        for res in batch_results:
            pid = res.get("protein_id")
            pdb_file = str(res.get("pdb"))
            model_rows = res.get("model_rows", [])
            idr_rows = res.get("idr_rows", [])
            fd_surface_residue_rows = res.get("fd_surface_residue_rows", [])
            fd_patch_rows = res.get("fd_patch_rows", [])
            warnings = res.get("warnings", [])
    
            all_model_rows.extend(model_rows)
            all_idr_rows.extend(idr_rows)
            all_fd_surface_residue_rows.extend(fd_surface_residue_rows)
            all_fd_patch_rows.extend(fd_patch_rows)
    
            for w in warnings:
                warning_rows.append({"protein_id": pid, "pdb_file": pdb_file, "warning": w})
    
            # Mark as done if the worker returned normally, even when a protein has
            # zero rows but only non-fatal warnings, so resume does not loop forever.
            status = "done"
            if pid is None and not model_rows and not idr_rows and warnings:
                status = "failed"
    
            manifest_rows.append({
                "pdb_file": pdb_file,
                "protein_id": pid,
                "status": status,
                "n_model_rows": len(model_rows),
                "n_idr_rows": len(idr_rows),
                "n_fd_surface_residue_rows": len(fd_surface_residue_rows),
                "n_fd_patch_rows": len(fd_patch_rows),
                "n_warnings": len(warnings),
                "timestamp": pd.Timestamp.now().isoformat(),
            })
    
            if args.write_per_protein and pid:
                if model_rows:
                    pd.DataFrame(model_rows).to_csv(
                        per_protein_dir / f"{pid}_surface_chemistry_by_model.csv",
                        index=False,
                    )
                if idr_rows:
                    pd.DataFrame(idr_rows).to_csv(
                        per_protein_dir / f"{pid}_idr_surface_chemistry_by_model.csv",
                        index=False,
                    )
                if fd_surface_residue_rows:
                    pd.DataFrame(fd_surface_residue_rows).to_csv(
                        per_protein_dir / f"{pid}_fd_surface_residues_by_model.csv",
                        index=False,
                    )
                if fd_patch_rows:
                    pd.DataFrame(fd_patch_rows).to_csv(
                        per_protein_dir / f"{pid}_fd_surface_patches_by_model.csv",
                        index=False,
                    )
    
        append_rows_csv(filemap["model"], all_model_rows)
        append_rows_csv(filemap["idr"], all_idr_rows)
        append_rows_csv(filemap["fd_surface_residues"], all_fd_surface_residue_rows)
        append_rows_csv(filemap["fd_patches"], all_fd_patch_rows)
        append_rows_csv(filemap["warnings"], warning_rows)
        append_rows_csv(filemap["manifest"], manifest_rows)
    
        return {
            "proteins": len(batch_results),
            "model_rows": len(all_model_rows),
            "idr_rows": len(all_idr_rows),
            "fd_surface_residue_rows": len(all_fd_surface_residue_rows),
            "fd_patch_rows": len(all_fd_patch_rows),
            "warnings": len(warning_rows),
        }


def main() -> None:
    args = parse_args()
    if freesasa is None:
        sys.exit("ERROR: freesasa is required. Install with: pip install freesasa")
    args.outdir.mkdir(parents=True, exist_ok=True)
    per_protein_dir = args.outdir / "per_protein"
    if args.write_per_protein:
        per_protein_dir.mkdir(parents=True, exist_ok=True)

    filemap = initialize_outputs(args)
    manifest_status = {} if args.restart else load_manifest_statuses(filemap["manifest"])

    master = load_master(args.master_json)
    pdbs = find_pdbs(args)
    if not pdbs:
        sys.exit("ERROR: no PDB files found.")

    if args.retry_failed_only and not args.restart:
        failed_states = {"failed", "error"}
        pdbs = [p for p in pdbs if manifest_status.get(normalize_pdb_path(str(p))) in failed_states]
        print(f"Resume mode: retry-failed-only. Scheduled {len(pdbs)} failed PDB(s) from checkpoint manifest.")
    elif not args.restart:
        pdbs = [p for p in pdbs if manifest_status.get(normalize_pdb_path(str(p))) != "done"]

    if not pdbs:
        if args.retry_failed_only and not args.restart:
            print(f"Nothing to do. No failed PDB entries found in {filemap['manifest']} for the current input selection.")
        else:
            print(f"Nothing to do. All requested PDBs already processed according to {filemap['manifest']}")
        return

    opts = {
        "surface_rsa": args.surface_rsa,
        "fd_patch_distance_cutoff": args.fd_patch_distance_cutoff,
        "min_fd_patch_residues": args.min_fd_patch_residues,
        "skip_fd_surface_residue_table": args.skip_fd_surface_residue_table,
        "anchor_radius": args.anchor_radius,
        "histidine_charge": args.histidine_charge,
        "model_stride": max(1, args.model_stride),
        "max_models": args.max_models,
        "chain": args.chain,
    }

    payloads = [str(p) for p in pdbs]
    workers = max(1, args.n_workers)
    checkpoint_every = max(1, args.checkpoint_every)
    pending_results: List[dict] = []
    total_stats = {"proteins": 0, "model_rows": 0, "idr_rows": 0, "fd_surface_residue_rows": 0, "fd_patch_rows": 0, "warnings": 0}

    def maybe_flush(force: bool = False) -> None:
        nonlocal pending_results, total_stats
        if pending_results and (force or len(pending_results) >= checkpoint_every):
            stats = flush_results(pending_results, args, filemap, per_protein_dir)
            for k, v in stats.items():
                total_stats[k] += v
            print(f"[checkpoint] wrote {stats['proteins']} PDBs | +{stats['model_rows']} model rows | +{stats['idr_rows']} IDR rows | +{stats['fd_surface_residue_rows']} FD surface residue rows | +{stats['fd_patch_rows']} FD patch rows | +{stats['warnings']} warnings", flush=True)
            pending_results = []

    if workers == 1:
        for pdb_path_s in tqdm(payloads, desc="Profiling PDBs"):
            try:
                pending_results.append(process_one_pdb((pdb_path_s, master, opts)))
            except Exception as exc:
                pending_results.append(failure_result(pdb_path_s, exc))
            maybe_flush()
    else:
        chunk_size = max(workers * 4, 1)
        for i in range(0, len(payloads), chunk_size):
            chunk = payloads[i:i + chunk_size]
            processed_in_chunk: set[str] = set()
            ex_kwargs = {"max_workers": workers, "initializer": init_worker, "initargs": (master, opts)}
            if args.max_tasks_per_child and args.max_tasks_per_child > 0:
                ex_kwargs["max_tasks_per_child"] = args.max_tasks_per_child

            try:
                with cf.ProcessPoolExecutor(**ex_kwargs) as ex:
                    fut_to_pdb = {ex.submit(process_one_pdb_in_worker, pdb_path_s): pdb_path_s for pdb_path_s in chunk}
                    for fut in tqdm(cf.as_completed(fut_to_pdb), total=len(fut_to_pdb), desc="Profiling PDBs", leave=False):
                        pdb_path_s = fut_to_pdb[fut]
                        processed_in_chunk.add(pdb_path_s)
                        try:
                            pending_results.append(fut.result())
                        except Exception as exc:
                            if isinstance(exc, BrokenProcessPool):
                                raise
                            pending_results.append(failure_result(pdb_path_s, exc))
                        maybe_flush()
            except BrokenProcessPool as exc:
                print(
                    f"[warning] Process pool failed ({type(exc).__name__}: {exc}). "
                    f"Retrying unfinished files from this chunk serially.",
                    flush=True,
                )
                for pdb_path_s in chunk:
                    if pdb_path_s in processed_in_chunk:
                        continue
                    try:
                        pending_results.append(process_one_pdb((pdb_path_s, master, opts)))
                    except Exception as serial_exc:
                        pending_results.append(failure_result(pdb_path_s, serial_exc))
                    maybe_flush()

    maybe_flush(force=True)

    model_df = load_existing_csv(filemap["model"])
    idr_df = load_existing_csv(filemap["idr"])
    fd_patch_df = load_existing_csv(filemap["fd_patches"])
    warn_df = load_existing_csv(filemap["warnings"])

    if not model_df.empty:
        summarize_numeric(model_df, ["protein_id"]).to_csv(args.outdir / "surface_chemistry_summary_by_protein.csv", index=False)
    if not idr_df.empty:
        summarize_numeric(idr_df, ["protein_id", "idr_label", "idr_start", "idr_end"]).to_csv(
            args.outdir / "idr_surface_chemistry_summary.csv", index=False
        )
    if not fd_patch_df.empty:
        summarize_numeric(fd_patch_df, ["protein_id", "fd_patch_id"]).to_csv(
            args.outdir / "fd_surface_patches_summary.csv", index=False
        )

    print(f"Done. Wrote outputs to: {args.outdir}")
    print(
        f"Newly processed PDB files this run: {total_stats['proteins']} | "
        f"Remaining aggregate model rows: {len(model_df)} | IDR rows: {len(idr_df)} | "
        f"FD patch rows: {len(fd_patch_df)} | Warnings: {len(warn_df)}"
    )


if __name__ == "__main__":
    main()
