import argparse
import concurrent.futures as cf
import json
import math
import re
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple, Set

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
from scipy.spatial import cKDTree
from tqdm import tqdm

AA3_TO_1 = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "HID": "H",
    "HIE": "H", "HIP": "H", "ILE": "I", "LEU": "L", "LYS": "K",
    "MET": "M", "MSE": "M", "PHE": "F", "PRO": "P", "SER": "S",
    "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V",
}

BACKBONE_ATOMS = {"N", "CA", "C", "O", "OXT"}
NEGATIVE = {"D", "E"}
POSITIVE = {"K", "R"}
HYDROPHOBIC = set("AVILMFWYPC")
AROMATIC = set("FYWH")
PI_SYSTEM = set("FYWHR")
PI_STACK_ANCHOR = set("FYWH")  # Require at least one aromatic/imidazole partner

# Ring atom definitions. For Trp, use one combined indole centroid for simplicity.
RING_ATOMS = {
    "F": {"CG", "CD1", "CD2", "CE1", "CE2", "CZ"},
    "Y": {"CG", "CD1", "CD2", "CE1", "CE2", "CZ"},
    "W": {"CG", "CD1", "CD2", "NE1", "CE2", "CE3", "CZ2", "CZ3", "CH2"},
    "H": {"CG", "ND1", "CD2", "CE1", "NE2"},
}

# Atom sets used to define residue-level cation centers for cation-pi scoring.
# This is intentionally more specific than a generic side-chain centroid:
# Lys uses the terminal ammonium N, Arg uses the guanidinium group, and
# protonated/effectively cationic His uses the imidazole ring center.
CATION_CENTER_ATOMS = {
    "K": {"NZ"},
    "R": {"NE", "CZ", "NH1", "NH2"},
    "H": RING_ATOMS["H"],
}

# Pi-system centers for pi-pi scoring. In this heuristic, Arg contributes via
# its delocalized guanidinium group, His via its imidazole, and F/Y/W via
# aromatic ring centroids. A pi-pi pair must include at least one aromatic or
# imidazole partner so Arg-Arg like-charge proximity is not rewarded as pi-pi.
PI_SYSTEM_CENTER_ATOMS = {
    "F": RING_ATOMS["F"],
    "Y": RING_ATOMS["Y"],
    "W": RING_ATOMS["W"],
    "H": RING_ATOMS["H"],
    "R": {"NE", "CZ", "NH1", "NH2"},
}

ResidueKey = Tuple[str, int, str]
ResiduePair = Tuple[ResidueKey, ResidueKey]


@dataclass(frozen=True)
class Atom:
    record: str
    serial: int
    atom_name: str
    resname: str
    chain: str
    resseq: int
    icode: str
    element: str
    xyz: Tuple[float, float, float]

    @property
    def key(self) -> ResidueKey:
        return (self.chain, self.resseq, self.icode)


@dataclass
class Residue:
    key: ResidueKey
    chain: str
    resseq: int
    icode: str
    resname: str
    aa: str
    atoms: List[Atom]


def load_json(path: Path) -> dict:
    with open(path, "r") as handle:
        return json.load(handle)


def find_pdbs(args: argparse.Namespace) -> List[Path]:
    if args.pdb_file:
        return [args.pdb_file]
    globber = args.pdb_dir.rglob if args.recursive else args.pdb_dir.glob
    pdbs = sorted([p for p in globber(args.pattern) if p.is_file()])
    if pdbs:
        return pdbs

    # Convenience fallback: many ensemble layouts are nested by protein/variant.
    # If the user did not pass --recursive and no files were found, retry with
    # a recursive search using common PDB extension variants.
    if not args.recursive:
        seen: Set[Path] = set()
        out: List[Path] = []
        for patt in (args.pattern, "*.pdb", "*.PDB"):
            for p in args.pdb_dir.rglob(patt):
                if p.is_file() and p not in seen:
                    out.append(p)
                    seen.add(p)
        return sorted(out)
    return []


def infer_protein_id(pdb_path: Path, master_ids: Sequence[str]) -> Optional[str]:
    stem = pdb_path.stem
    if stem in master_ids:
        return stem
    first = re.split(r"[_\-.]", stem)[0]
    if first in master_ids:
        return first
    hits = [mid for mid in master_ids if mid in stem]
    if hits:
        return sorted(hits, key=len, reverse=True)[0]
    return None


def infer_variant_name(pdb_path: Path, protein_id: Optional[str]) -> str:
    stem = pdb_path.stem
    # Remove common suffixes first.
    stem = re.sub(r"_idpcg_n\d+$", "", stem)
    stem = re.sub(r"_n\d+$", "", stem)
    if protein_id and stem.startswith(protein_id):
        rest = stem[len(protein_id):].strip("_-. ")
        return rest if rest else "ensemble"
    return stem


def clean_line(line: str) -> str:
    # FreeSASA/PDB-generating pipelines sometimes produce unicode-ish minus signs.
    return (
        line.rstrip("\n")
        .replace("¯", "-")
        .replace("−", "-")
        .replace("–", "-")
        .replace("—", "-")
    )


def parse_atom_line(line: str) -> Optional[Atom]:
    line = clean_line(line)
    if not (line.startswith("ATOM") or line.startswith("HETATM")):
        return None

    record = line[:6].strip() or "ATOM"
    # Fixed-width first.
    try:
        serial = int(line[6:11])
        atom_name = line[12:16].strip()
        resname = line[17:20].strip().upper()
        chain = line[21].strip() or "A"
        resseq = int(line[22:26])
        icode = line[26].strip()
        x = float(line[30:38])
        y = float(line[38:46])
        z = float(line[46:54])
        element = line[76:78].strip().upper() if len(line) >= 78 else ""
        if not element:
            element = re.sub(r"[^A-Za-z]", "", atom_name)[:1].upper()
        if resname in AA3_TO_1 and atom_name:
            return Atom(record, serial, atom_name, resname, chain, resseq, icode, element, (x, y, z))
    except Exception:
        pass

    # Whitespace fallback for malformed coordinate columns.
    toks = line.split()
    if len(toks) < 8:
        return None
    try:
        record = toks[0]
        serial = int(toks[1])
        atom_name = toks[2]
        resname = toks[3].upper()
        chain_token = toks[4]
        if len(toks) >= 9 and re.fullmatch(r"-?\d+[A-Za-z]?", toks[5]):
            chain = chain_token if chain_token else "A"
            m = re.match(r"(-?\d+)([A-Za-z]?)", toks[5])
            assert m is not None
            resseq = int(m.group(1))
            icode = m.group(2)
            coord_i = 6
        else:
            m = re.match(r"([A-Za-z]?)(-?\d+)([A-Za-z]?)", chain_token)
            if not m:
                return None
            chain = m.group(1) or "A"
            resseq = int(m.group(2))
            icode = m.group(3) or ""
            coord_i = 5
        x = float(toks[coord_i])
        y = float(toks[coord_i + 1])
        z = float(toks[coord_i + 2])
        element = toks[-1].upper() if toks[-1].isalpha() and len(toks[-1]) <= 2 else re.sub(r"[^A-Za-z]", "", atom_name)[:1].upper()
        if resname in AA3_TO_1 and atom_name:
            return Atom(record, serial, atom_name, resname, chain, resseq, icode, element, (x, y, z))
    except Exception:
        return None
    return None


def split_models(pdb_path: Path) -> List[List[str]]:
    models: List[List[str]] = []
    current: List[str] = []
    with open(pdb_path, "r", errors="replace") as fh:
        for line in fh:
            rec = line[:6].strip()
            if rec == "MODEL":
                if current:
                    models.append(current)
                    current = []
            elif rec in {"ATOM", "HETATM"}:
                current.append(line.rstrip("\n"))
            elif rec == "ENDMDL":
                if current:
                    models.append(current)
                    current = []
    if current:
        models.append(current)
    return models


def model_to_residues(lines: Sequence[str], chain_filter: Optional[str] = None) -> Dict[ResidueKey, Residue]:
    grouped: Dict[ResidueKey, List[Atom]] = defaultdict(list)
    for line in lines:
        atom = parse_atom_line(line)
        if atom is None:
            continue
        if chain_filter is not None and atom.chain != chain_filter:
            continue
        if atom.element.upper() == "H" or atom.atom_name.startswith("H"):
            continue
        grouped[atom.key].append(atom)

    residues: Dict[ResidueKey, Residue] = {}
    for key, atoms in grouped.items():
        if not atoms:
            continue
        resname = atoms[0].resname
        aa = AA3_TO_1.get(resname)
        if aa is None:
            continue
        chain, resseq, icode = key
        residues[key] = Residue(key, chain, resseq, icode, resname, aa, atoms)
    return residues


def normalize_idr_ranges(details: Sequence[Sequence[int]]) -> List[Tuple[int, int]]:
    return sorted([(int(s), int(e)) for s, e in details], key=lambda x: (x[0], x[1]))


def residue_in_ranges(resseq: int, ranges: Sequence[Tuple[int, int]]) -> bool:
    return any(start <= resseq <= end for start, end in ranges)


def select_target_ranges(
    all_ranges: Sequence[Tuple[int, int]],
    args: argparse.Namespace,
    max_resseq: int,
    ) -> List[Tuple[int, int]]:
        all_ranges = list(all_ranges)
        if args.target_idrs:
            selected: List[Tuple[int, int]] = []
            for token in [t.strip() for t in args.target_idrs.split(",") if t.strip()]:
                m = re.fullmatch(r"IDR(\d+)", token, flags=re.I)
                if m:
                    idx = int(m.group(1)) - 1
                    if idx < 0 or idx >= len(all_ranges):
                        raise ValueError(f"Requested {token}, but only {len(all_ranges)} IDR ranges are present: {all_ranges}")
                    selected.append(all_ranges[idx])
                    continue
                m = re.fullmatch(r"(-?\d+)\s*-\s*(-?\d+)", token)
                if m:
                    s, e = int(m.group(1)), int(m.group(2))
                    selected.append((min(s, e), max(s, e)))
                    continue
                raise ValueError(f"Could not parse --target-idrs token: {token}")
            return selected

        if args.target_terminal == "N":
            return [r for r in all_ranges if r[0] == 1]
        if args.target_terminal == "C":
            # Use PDB max residue as fallback for full-length C-terminal boundary.
            return [r for r in all_ranges if r[1] == max_resseq]
        return all_ranges


def residue_center(res: Residue, sidechain_preferred: bool = True) -> Optional[np.ndarray]:
    atoms = res.atoms
    if sidechain_preferred:
        sc = [a for a in atoms if a.atom_name.strip() not in BACKBONE_ATOMS]
        if sc:
            atoms = sc
    if not atoms:
        return None
    return np.array([a.xyz for a in atoms], dtype=float).mean(axis=0)


def residue_charge(res: Residue, histidine_charge: float) -> float:
    if res.aa in POSITIVE:
        return 1.0
    if res.aa in NEGATIVE:
        return -1.0
    if res.aa == "H":
        return float(histidine_charge)
    return 0.0


def atom_arrays(residues: Sequence[Residue], *, sidechain_only: bool = False, aa_filter: Optional[Set[str]] = None) -> Tuple[np.ndarray, List[ResidueKey]]:
    coords: List[Tuple[float, float, float]] = []
    keys: List[ResidueKey] = []
    for res in residues:
        if aa_filter is not None and res.aa not in aa_filter:
            continue
        for atom in res.atoms:
            if sidechain_only and atom.atom_name.strip() in BACKBONE_ATOMS:
                continue
            coords.append(atom.xyz)
            keys.append(res.key)
    if not coords:
        return np.zeros((0, 3), dtype=float), []
    return np.array(coords, dtype=float), keys


def contact_pairs_from_atoms(
    idr_residues: Sequence[Residue],
    fd_residues: Sequence[Residue],
    cutoff: float,
    *,
    sidechain_only: bool = False,
    aa_filter: Optional[Set[str]] = None,
    ) -> Tuple[Set[ResiduePair], int]:
        idr_xyz, idr_keys = atom_arrays(idr_residues, sidechain_only=sidechain_only, aa_filter=aa_filter)
        fd_xyz, fd_keys = atom_arrays(fd_residues, sidechain_only=sidechain_only, aa_filter=aa_filter)
        if len(idr_xyz) == 0 or len(fd_xyz) == 0:
            return set(), 0
        tree = cKDTree(fd_xyz)
        pair_set: Set[ResiduePair] = set()
        atom_pair_count = 0
        hits = tree.query_ball_point(idr_xyz, r=cutoff)
        for i, js in enumerate(hits):
            if not js:
                continue
            ikey = idr_keys[i]
            for j in js:
                pair_set.add((ikey, fd_keys[j]))
                atom_pair_count += 1
        return pair_set, atom_pair_count


def is_backbone_atom(atom: Atom) -> bool:
    return atom.atom_name.upper() in BACKBONE_ATOMS


def is_hydrogen_atom(atom: Atom) -> bool:
    name = atom.atom_name.upper().strip()
    elem = (atom.element or "").upper().strip()
    return elem == "H" or name.startswith("H")


def is_backbone_heavy_atom_name(name: str) -> bool:
    return name.upper().strip() in BACKBONE_ATOMS


def is_hbond_donor_atom(atom: Atom) -> bool:
    """Approximate heavy-atom H-bond donor classifier.

    Donors are N/O/S heavy atoms that can plausibly carry a proton. Proline
    backbone N is excluded. This donor list is intentionally permissive because
    PDB hydrogen naming/protonation can vary after model post-processing.
    """
    name = atom.atom_name.upper().strip()
    elem = (atom.element or "").upper().strip()
    if is_hydrogen_atom(atom):
        return False
    if atom.resname == "PRO" and name == "N":
        return False
    if elem in {"N", "O", "S"}:
        return True
    return name.startswith(("N", "O", "S"))


def is_hbond_acceptor_atom(atom: Atom) -> bool:
    """Approximate heavy-atom H-bond acceptor classifier.

    Backbone amide N is excluded as an acceptor. O and S atoms are acceptors.
    Some neutral side-chain nitrogens in His/Asn/Gln are included permissively.
    Lys/Arg cationic nitrogens are not treated as acceptors.
    """
    name = atom.atom_name.upper().strip()
    elem = (atom.element or "").upper().strip()
    if is_hydrogen_atom(atom):
        return False
    if name == "N":
        return False
    if elem in {"O", "S"}:
        return True
    if elem == "N" and atom.resname in {"HIS", "HID", "HIE", "ASN", "GLN"}:
        return True
    if not elem:
        if name.startswith(("O", "S")):
            return True
        if name.startswith("N") and atom.resname in {"HIS", "HID", "HIE", "ASN", "GLN"}:
            return True
    return False


def donor_hydrogens_for_atom(res: Residue, donor: Atom) -> List[Atom]:
    """Find explicit hydrogens likely attached to donor by intra-residue distance.

    This avoids relying on PDB hydrogen names/bond tables. N/O-H distances are
    usually ~1.0 Å; S-H is longer, so use a slightly larger fallback cutoff.
    """
    dxyz = np.asarray(donor.xyz, dtype=float)
    elem = (donor.element or "").upper().strip()
    cutoff = 1.45 if elem == "S" or donor.atom_name.upper().startswith("S") else 1.25
    hs = []
    for atom in res.atoms:
        if not is_hydrogen_atom(atom):
            continue
        dist = float(np.linalg.norm(np.asarray(atom.xyz, dtype=float) - dxyz))
        if dist <= cutoff:
            hs.append(atom)
    return hs


def hbond_atom_records(
    residues: Sequence[Residue],
    mode: str,
    ) -> Tuple[List[Tuple[ResidueKey, Atom, List[Atom], bool]], List[Tuple[ResidueKey, Atom, bool]]]:
        donors: List[Tuple[ResidueKey, Atom, List[Atom], bool]] = []
        acceptors: List[Tuple[ResidueKey, Atom, bool]] = []
        for res in residues:
            for atom in res.atoms:
                atom_is_bb = is_backbone_atom(atom)
                if mode == "sidechain_only" and atom_is_bb:
                    continue
                if is_hbond_donor_atom(atom):
                    donors.append((res.key, atom, donor_hydrogens_for_atom(res, atom), atom_is_bb))
                if is_hbond_acceptor_atom(atom):
                    acceptors.append((res.key, atom, atom_is_bb))
        return donors, acceptors


def dha_angle_degrees(donor_xyz: np.ndarray, hydrogen_xyz: np.ndarray, acceptor_xyz: np.ndarray) -> float:
    """Return D-H-A angle in degrees."""
    v1 = donor_xyz - hydrogen_xyz
    v2 = acceptor_xyz - hydrogen_xyz
    n1 = float(np.linalg.norm(v1))
    n2 = float(np.linalg.norm(v2))
    if n1 < 1e-8 or n2 < 1e-8:
        return 0.0
    cosang = float(np.dot(v1, v2) / (n1 * n2))
    cosang = max(-1.0, min(1.0, cosang))
    return float(np.degrees(np.arccos(cosang)))


def hbond_atom_pair_passes(
    donor: Atom,
    donor_hs: List[Atom],
    acceptor: Atom,
    *,
    da_cutoff: float,
    ha_cutoff: float,
    angle_cutoff: float,
    geometry: str,
    ) -> bool:
        d = np.asarray(donor.xyz, dtype=float)
        a = np.asarray(acceptor.xyz, dtype=float)
        da = float(np.linalg.norm(d - a))
        if da > da_cutoff:
            return False

        if geometry == "heavy_only":
            return True

        if donor_hs:
            for h_atom in donor_hs:
                h = np.asarray(h_atom.xyz, dtype=float)
                ha = float(np.linalg.norm(h - a))
                if ha > ha_cutoff:
                    continue
                angle = dha_angle_degrees(d, h, a)
                if angle >= angle_cutoff:
                    return True
            return False

        # Hydrogen-free PDB fallback. This keeps compatibility with ensembles that
        # lack explicit hydrogens but makes the behavior explicit in the output args.
        return geometry == "angle_if_hydrogens"


def hbond_like_pairs(
    idr_residues: Sequence[Residue],
    fd_residues: Sequence[Residue],
    cutoff: float,
    mode: str = "no_backbone_backbone",
    geometry: str = "angle_if_hydrogens",
    h_a_cutoff: float = 2.5,
    angle_cutoff: float = 120.0,
    ) -> Tuple[Set[ResiduePair], int]:
        """Count approximate hydrogen-bond residue pairs.

        A residue pair is counted once if any donor/acceptor atom pair between the
        two residues satisfies the requested H-bond rule. ``atom_pair_count`` reports
        the number of donor/acceptor atom pairs and can be larger than the residue
        pair count.
        """
        idr_donors, idr_acceptors = hbond_atom_records(idr_residues, mode)
        fd_donors, fd_acceptors = hbond_atom_records(fd_residues, mode)

        pair_set: Set[ResiduePair] = set()
        atom_pair_count = 0

        def add_direction(donors, acceptors, reverse: bool = False) -> None:
            nonlocal atom_pair_count
            for d_key, donor, donor_hs, donor_bb in donors:
                for a_key, acceptor, acceptor_bb in acceptors:
                    if mode == "no_backbone_backbone" and bool(donor_bb) and bool(acceptor_bb):
                        continue
                    if not hbond_atom_pair_passes(
                        donor,
                        donor_hs,
                        acceptor,
                        da_cutoff=cutoff,
                        ha_cutoff=h_a_cutoff,
                        angle_cutoff=angle_cutoff,
                        geometry=geometry,
                    ):
                        continue
                    atom_pair_count += 1
                    if reverse:
                        pair_set.add((a_key, d_key))  # acceptor is IDR, donor is FD
                    else:
                        pair_set.add((d_key, a_key))  # donor is IDR, acceptor is FD

        add_direction(idr_donors, fd_acceptors, reverse=False)
        add_direction(fd_donors, idr_acceptors, reverse=True)
        return pair_set, atom_pair_count


def center_dict(residues: Sequence[Residue]) -> Dict[ResidueKey, np.ndarray]:
    out: Dict[ResidueKey, np.ndarray] = {}
    for res in residues:
        c = residue_center(res, sidechain_preferred=True)
        if c is not None:
            out[res.key] = c
    return out


def pair_centers_by_cutoff(
    left: Sequence[Residue],
    right: Sequence[Residue],
    cutoff: float,
    *,
    left_filter: Optional[Set[str]] = None,
    right_filter: Optional[Set[str]] = None,
    ) -> List[Tuple[Residue, Residue, float]]:
        l_res = [r for r in left if left_filter is None or r.aa in left_filter]
        r_res = [r for r in right if right_filter is None or r.aa in right_filter]
        l_centers: List[np.ndarray] = []
        r_centers: List[np.ndarray] = []
        l_keep: List[Residue] = []
        r_keep: List[Residue] = []
        for r in l_res:
            c = residue_center(r, sidechain_preferred=True)
            if c is not None:
                l_keep.append(r)
                l_centers.append(c)
        for r in r_res:
            c = residue_center(r, sidechain_preferred=True)
            if c is not None:
                r_keep.append(r)
                r_centers.append(c)
        if not l_centers or not r_centers:
            return []
        l_xyz = np.vstack(l_centers)
        r_xyz = np.vstack(r_centers)
        tree = cKDTree(r_xyz)
        out = []
        hits = tree.query_ball_point(l_xyz, r=cutoff)
        for i, js in enumerate(hits):
            if not js:
                continue
            for j in js:
                d = float(np.linalg.norm(l_xyz[i] - r_xyz[j]))
                out.append((l_keep[i], r_keep[j], d))
        return out


def atom_name_centroid(res: Residue, atom_names: Set[str]) -> Optional[np.ndarray]:
    """Return the centroid of a named atom set, ignoring absent atoms."""
    wanted = {name.upper().strip() for name in atom_names}
    atoms = [a for a in res.atoms if a.atom_name.upper().strip() in wanted]
    if not atoms:
        return None
    return np.array([a.xyz for a in atoms], dtype=float).mean(axis=0)


def aromatic_centroid(res: Residue) -> Optional[np.ndarray]:
    names = RING_ATOMS.get(res.aa)
    if not names:
        return None
    c = atom_name_centroid(res, names)
    if c is not None:
        return c
    # Fallback for non-standard aromatic atom naming: use non-backbone side-chain centroid.
    atoms = [a for a in res.atoms if a.atom_name.upper().strip() not in BACKBONE_ATOMS]
    if not atoms:
        return None
    return np.array([a.xyz for a in atoms], dtype=float).mean(axis=0)


def cation_center(res: Residue, histidine_charge: float) -> Optional[np.ndarray]:
    """Return a chemically specific cation center for cation-pi scoring.

    Residues counted as cation-pi donors:
      - Lys: terminal ammonium NZ
      - Arg: guanidinium group centroid (NE/CZ/NH1/NH2)
      - His: imidazole centroid only when histidine_charge makes it cationic

    A residue can still be counted in additional contact classes independently;
    e.g. Arg can be charge-charge, cation-pi, pi-pi, and H-bond competent.
    """
    if res.aa == "K":
        center = atom_name_centroid(res, CATION_CENTER_ATOMS["K"])
        return center if center is not None else residue_center(res, sidechain_preferred=True)
    if res.aa == "R":
        center = atom_name_centroid(res, CATION_CENTER_ATOMS["R"])
        return center if center is not None else residue_center(res, sidechain_preferred=True)
    if res.aa == "H" and histidine_charge > 0:
        center = atom_name_centroid(res, CATION_CENTER_ATOMS["H"])
        return center if center is not None else residue_center(res, sidechain_preferred=True)
    return None


def pi_system_center(res: Residue) -> Optional[np.ndarray]:
    """Return a centroid for side-chain pi systems used in pi-pi scoring.

    This intentionally includes Arg guanidinium and His imidazole in addition to
    Phe/Tyr/Trp aromatic rings. It does not make contact classes mutually
    exclusive: the same residue pair may be counted as pi-pi and as cation-pi,
    charge-charge, hydrophobic, and/or H-bond-like when each rule is satisfied.
    """
    atom_names = PI_SYSTEM_CENTER_ATOMS.get(res.aa)
    if not atom_names:
        return None
    center = atom_name_centroid(res, atom_names)
    return center if center is not None else residue_center(res, sidechain_preferred=True)


def special_center_pairs(
    left: Sequence[Residue],
    right: Sequence[Residue],
    cutoff: float,
    *,
    left_kind: str,
    right_kind: str,
    histidine_charge: float,
    ) -> Set[ResiduePair]:
        def get_center(res: Residue, kind: str) -> Optional[np.ndarray]:
            if kind == "cation":
                if residue_charge(res, histidine_charge) <= 0:
                    return None
                return cation_center(res, histidine_charge)
            if kind == "aromatic":
                if res.aa not in AROMATIC:
                    return None
                return aromatic_centroid(res)
            if kind == "pi_system":
                if res.aa not in PI_SYSTEM:
                    return None
                return pi_system_center(res)
            raise ValueError(kind)

        l_centers: List[np.ndarray] = []
        r_centers: List[np.ndarray] = []
        l_res: List[Residue] = []
        r_res: List[Residue] = []
        for r in left:
            c = get_center(r, left_kind)
            if c is not None:
                l_res.append(r)
                l_centers.append(c)
        for r in right:
            c = get_center(r, right_kind)
            if c is not None:
                r_res.append(r)
                r_centers.append(c)
        if not l_centers or not r_centers:
            return set()
        l_xyz = np.vstack(l_centers)
        r_xyz = np.vstack(r_centers)
        tree = cKDTree(r_xyz)
        pairs: Set[ResiduePair] = set()
        hits = tree.query_ball_point(l_xyz, r=cutoff)
        for i, js in enumerate(hits):
            for j in js:
                pairs.add((l_res[i].key, r_res[j].key))
        return pairs


def filter_pipi_pairs_with_pi_anchor(
    pairs: Set[ResiduePair],
    residues_by_key: Dict[ResidueKey, Residue],
    ) -> Set[ResiduePair]:
        """Keep pi-pi pairs that include at least one aromatic/imidazole partner.

        This allows Arg guanidinium--aromatic/His and His--aromatic/His contacts,
        but avoids assigning a favorable pi-pi term to Arg--Arg contacts, which are
        better represented by the charge terms.
        """
        kept: Set[ResiduePair] = set()
        for ik, fk in pairs:
            iaa = residues_by_key.get(ik).aa if residues_by_key.get(ik) is not None else "X"
            faa = residues_by_key.get(fk).aa if residues_by_key.get(fk) is not None else "X"
            if iaa in PI_STACK_ANCHOR or faa in PI_STACK_ANCHOR:
                kept.add((ik, fk))
        return kept


def _contains_residue(resseq: int, ranges: Sequence[Tuple[int, int]]) -> Optional[Tuple[int, int]]:
    for start, end in ranges:
        if int(start) <= int(resseq) <= int(end):
            return int(start), int(end)
    return None


def idr_distance_from_selected_fd_boundary(
    resseq: int,
    target_ranges: Sequence[Tuple[int, int]],
    max_resseq: int,
    ) -> Optional[int]:
        """Distance, in sequence residues, from an IDR residue to its selected FD boundary.

        The boundary-adjacent IDR residue has distance 0. For terminal IDRs, only the
        boundary connected to the folded domain is used. For internal IDRs, the nearer
        of the two IDR:FD boundaries is used.
        """
        hit = _contains_residue(resseq, target_ranges)
        if hit is None:
            return None
        start, end = hit
        boundary_positions: List[int] = []
        if start > 1:
            boundary_positions.append(start)
        if end < max_resseq:
            boundary_positions.append(end)
        if not boundary_positions:
            boundary_positions = [start, end]
        return int(min(abs(int(resseq) - b) for b in boundary_positions))


def fd_distance_from_selected_idr_boundary(
    resseq: int,
    target_ranges: Sequence[Tuple[int, int]],
    ) -> Optional[int]:
        """Distance, in sequence residues, from an FD residue to the nearest selected IDR boundary.

        The FD residue immediately adjacent to a selected IDR has distance 0. This is
        a sequence-local anchor diagnostic, not a 3D distance.
        """
        distances: List[int] = []
        for start, end in target_ranges:
            start = int(start)
            end = int(end)
            if int(resseq) < start:
                distances.append(start - 1 - int(resseq))
            elif int(resseq) > end:
                distances.append(int(resseq) - (end + 1))
        if not distances:
            return None
        return int(min(max(0, d) for d in distances))


def boundary_distance_summary(prefix: str, pairs: Set[ResiduePair], target_ranges: Sequence[Tuple[int, int]], max_resseq: int) -> Dict[str, float]:
    """Return compact per-model contact-location diagnostics for one pair set."""
    idr_dists: List[int] = []
    fd_dists: List[int] = []
    pair_min_dists: List[int] = []
    for ik, fk in pairs:
        idr_d = idr_distance_from_selected_fd_boundary(ik[1], target_ranges, max_resseq)
        fd_d = fd_distance_from_selected_idr_boundary(fk[1], target_ranges)
        if idr_d is not None:
            idr_dists.append(idr_d)
        if fd_d is not None:
            fd_dists.append(fd_d)
        if idr_d is not None and fd_d is not None:
            pair_min_dists.append(min(idr_d, fd_d))
    def frac_gt(vals: List[int], threshold: int) -> float:
        return float(np.mean([v > threshold for v in vals])) if vals else float("nan")
    def mean(vals: List[int]) -> float:
        return float(np.mean(vals)) if vals else float("nan")
    def median(vals: List[int]) -> float:
        return float(np.median(vals)) if vals else float("nan")
    out: Dict[str, float] = {
        f"n_{prefix}_contact_pairs_for_boundary_diagnostic": int(len(pairs)),
        f"mean_{prefix}_idr_boundary_distance": mean(idr_dists),
        f"median_{prefix}_idr_boundary_distance": median(idr_dists),
        f"frac_{prefix}_idr_distance_gt5": frac_gt(idr_dists, 5),
        f"frac_{prefix}_idr_distance_gt10": frac_gt(idr_dists, 10),
        f"mean_{prefix}_fd_boundary_distance": mean(fd_dists),
        f"median_{prefix}_fd_boundary_distance": median(fd_dists),
        f"frac_{prefix}_fd_distance_gt5": frac_gt(fd_dists, 5),
        f"frac_{prefix}_fd_distance_gt10": frac_gt(fd_dists, 10),
        f"mean_{prefix}_pair_min_boundary_distance": mean(pair_min_dists),
        f"median_{prefix}_pair_min_boundary_distance": median(pair_min_dists),
        f"frac_{prefix}_pair_min_distance_gt5": frac_gt(pair_min_dists, 5),
        f"frac_{prefix}_pair_min_distance_gt10": frac_gt(pair_min_dists, 10),
    }
    return out


def contact_location_rows_for_model(
    *,
    pair_sets: Dict[str, Set[ResiduePair]],
    residues_by_key: Dict[ResidueKey, Residue],
    protein_id: str,
    ensemble_name: str,
    variant_name: str,
    model_index: int,
    target_ranges: Sequence[Tuple[int, int]],
    max_resseq: int,
    ) -> List[dict]:
        """Expand contact pair sets into a residue-level contact-localization table."""
        target_ranges_text = ";".join(f"{s}-{e}" for s, e in target_ranges)
        rows: List[dict] = []
        for contact_type, pairs in pair_sets.items():
            for ik, fk in sorted(pairs, key=lambda p: (p[0][0], p[0][1], p[1][0], p[1][1])):
                ires = residues_by_key.get(ik)
                fres = residues_by_key.get(fk)
                idr_d = idr_distance_from_selected_fd_boundary(ik[1], target_ranges, max_resseq)
                fd_d = fd_distance_from_selected_idr_boundary(fk[1], target_ranges)
                pair_min = min(idr_d, fd_d) if idr_d is not None and fd_d is not None else None
                rows.append({
                    "ensemble_name": ensemble_name,
                    "protein_id": protein_id,
                    "variant_name": variant_name,
                    "model_index": model_index,
                    "target_ranges": target_ranges_text,
                    "contact_type": contact_type,
                    "idr_chain": ik[0],
                    "idr_resseq": ik[1],
                    "idr_icode": ik[2],
                    "idr_aa": ires.aa if ires is not None else "X",
                    "fd_chain": fk[0],
                    "fd_resseq": fk[1],
                    "fd_icode": fk[2],
                    "fd_aa": fres.aa if fres is not None else "X",
                    "idr_boundary_distance": idr_d,
                    "fd_boundary_distance": fd_d,
                    "pair_min_boundary_distance": pair_min,
                    "idr_distance_gt5": int(idr_d is not None and idr_d > 5),
                    "idr_distance_gt10": int(idr_d is not None and idr_d > 10),
                    "fd_distance_gt5": int(fd_d is not None and fd_d > 5),
                    "fd_distance_gt10": int(fd_d is not None and fd_d > 10),
                    "pair_min_distance_gt5": int(pair_min is not None and pair_min > 5),
                    "pair_min_distance_gt10": int(pair_min is not None and pair_min > 10),
                })
        return rows


def score_model(
    model_lines: Sequence[str],
    *,
    model_index: int,
    protein_id: str,
    ensemble_name: str,
    variant_name: str,
    all_idr_ranges: Sequence[Tuple[int, int]],
    target_ranges: Sequence[Tuple[int, int]],
    args: argparse.Namespace,
    ) -> Tuple[Optional[dict], List[str], List[dict]]:
        warnings: List[str] = []
        residues_by_key = model_to_residues(model_lines, chain_filter=args.chain)
        if not residues_by_key:
            return None, ["no protein residues parsed"], []

        residues = sorted(residues_by_key.values(), key=lambda r: (r.chain, r.resseq, r.icode))
        max_resseq = max([r.resseq for r in residues], default=max(e for _, e in all_idr_ranges))
        target_idr_res_all = [r for r in residues if residue_in_ranges(r.resseq, target_ranges)]
        anchor_cutoff = max(0, int(getattr(args, "anchor_cutoff", 5)))
        target_idr_res = [
            r for r in target_idr_res_all
            if (idr_distance_from_selected_fd_boundary(r.resseq, target_ranges, max_resseq) is not None
                and idr_distance_from_selected_fd_boundary(r.resseq, target_ranges, max_resseq) >= anchor_cutoff)
        ]
        folded_res = [r for r in residues if not residue_in_ranges(r.resseq, all_idr_ranges)]
        other_idr_res = [r for r in residues if residue_in_ranges(r.resseq, all_idr_ranges) and not residue_in_ranges(r.resseq, target_ranges)]

        if not target_idr_res_all:
            return None, [f"no target IDR residues found for ranges={target_ranges}"], []
        if not target_idr_res:
            return None, [f"no target IDR residues remained after applying anchor_cutoff={anchor_cutoff}"], []
        if not folded_res:
            return None, ["no folded-domain residues found after excluding all IDR ranges"], []

        heavy_pairs, heavy_atom_contacts = contact_pairs_from_atoms(
            target_idr_res, folded_res, args.heavy_cutoff, sidechain_only=False, aa_filter=None
        )
        clash_pairs, clash_atom_contacts = contact_pairs_from_atoms(
            target_idr_res, folded_res, args.clash_cutoff, sidechain_only=False, aa_filter=None
        )
        hydro_pairs, hydro_atom_contacts = contact_pairs_from_atoms(
            target_idr_res, folded_res, args.hydrophobic_cutoff, sidechain_only=True, aa_filter=HYDROPHOBIC
        )

        # Charge contacts and screened electrostatic contact score.
        charged_pairs_contact: Set[ResiduePair] = set()
        opposite_pairs: Set[ResiduePair] = set()
        like_pairs: Set[ResiduePair] = set()
        screened_charge_score = 0.0
        screened_charge_favorable_abs = 0.0
        screened_charge_unfavorable = 0.0

        charged_idr = [r for r in target_idr_res if abs(residue_charge(r, args.histidine_charge)) > 1e-8]
        charged_fd = [r for r in folded_res if abs(residue_charge(r, args.histidine_charge)) > 1e-8]
        for ri, rj, dist in pair_centers_by_cutoff(charged_idr, charged_fd, args.electro_cutoff):
            qi = residue_charge(ri, args.histidine_charge)
            qj = residue_charge(rj, args.histidine_charge)
            prod = qi * qj
            if abs(prod) < 1e-8:
                continue
            contribution = prod * math.exp(-dist / max(args.debye_length, 1e-6)) / max(dist, 2.0)
            screened_charge_score += contribution
            if contribution < 0:
                screened_charge_favorable_abs += -contribution
            else:
                screened_charge_unfavorable += contribution
            if dist <= args.charge_contact_cutoff:
                pair = (ri.key, rj.key)
                charged_pairs_contact.add(pair)
                if prod < 0:
                    opposite_pairs.add(pair)
                else:
                    like_pairs.add(pair)

        # Cation-pi in both orientations: IDR cation to FD aromatic and FD cation to IDR aromatic.
        cationpi_pairs = set()
        cationpi_pairs |= special_center_pairs(
            target_idr_res, folded_res, args.cationpi_cutoff,
            left_kind="cation", right_kind="aromatic", histidine_charge=args.histidine_charge,
        )
        # Reverse orientation needs pair orientation as IDR,FD.
        reverse_cpi = special_center_pairs(
            folded_res, target_idr_res, args.cationpi_cutoff,
            left_kind="cation", right_kind="aromatic", histidine_charge=args.histidine_charge,
        )
        for fd_key, idr_key in reverse_cpi:
            cationpi_pairs.add((idr_key, fd_key))

        # Pi-pi / pi-system contacts. This includes Arg guanidinium and His imidazole
        # pi systems in addition to Phe/Tyr/Trp aromatic rings. At least one partner
        # must be aromatic/imidazole; Arg-Arg proximity is left to charge terms.
        pipi_raw_pairs = special_center_pairs(
            target_idr_res, folded_res, args.pipi_cutoff,
            left_kind="pi_system", right_kind="pi_system", histidine_charge=args.histidine_charge,
        )
        pipi_pairs = filter_pipi_pairs_with_pi_anchor(pipi_raw_pairs, residues_by_key)

        # Arg-Arg guanidinium/π-stacking-like contacts. These are kept separate
        # from the aromatic/imidazole pi-pi term above so Arg-Arg contacts remain
        # explicitly visible and tunable while still being allowed to overlap with
        # like-charge/screened-charge terms.
        argarg_pairs = special_center_pairs(
            [r for r in target_idr_res if r.aa == "R"],
            [r for r in folded_res if r.aa == "R"],
            args.argarg_cutoff,
            left_kind="pi_system", right_kind="pi_system", histidine_charge=args.histidine_charge,
        )

        # Hydrogen-bond-like contacts, counted as donor/acceptor heavy-atom pairs.
        hbond_pairs, hbond_atom_contacts = hbond_like_pairs(
            target_idr_res,
            folded_res,
            args.hbond_cutoff,
            mode=args.hbond_mode,
            geometry=args.hbond_geometry,
            h_a_cutoff=args.hbond_h_a_cutoff,
            angle_cutoff=args.hbond_angle_cutoff,
        )

        scored_any_pairs = set().union(
            opposite_pairs, like_pairs, hydro_pairs, cationpi_pairs, pipi_pairs, argarg_pairs, hbond_pairs
        )
        contact_location_pair_sets = {
            "scored_any": scored_any_pairs,
            "heavy": heavy_pairs,
            "opposite_charge": opposite_pairs,
            "like_charge": like_pairs,
            "hydrophobic": hydro_pairs,
            "cationpi": cationpi_pairs,
            "pipi": pipi_pairs,
            "argarg": argarg_pairs,
            "hbond": hbond_pairs,
            "clash": clash_pairs,
        }
        location_rows = contact_location_rows_for_model(
            pair_sets=contact_location_pair_sets,
            residues_by_key=residues_by_key,
            protein_id=protein_id,
            ensemble_name=ensemble_name,
            variant_name=variant_name,
            model_index=model_index,
            target_ranges=target_ranges,
            max_resseq=max_resseq,
        )

        n_opp = len(opposite_pairs)
        n_like = len(like_pairs)
        n_hydro = len(hydro_pairs)
        n_cationpi = len(cationpi_pairs)
        n_pipi = len(pipi_pairs)
        n_argarg = len(argarg_pairs)
        n_hbond = len(hbond_pairs)
        n_clash = len(clash_pairs)

        # Decomposed contact score. Higher is better/more favorable.
        # Positive terms reward favorable contacts; negative terms penalize like-charge,
        # unfavorable screened-charge proximity, and optional clashes. This is a
        # heuristic score, not a thermodynamic quantity.
        score_charge_contacts = args.w_opposite_charge * n_opp - args.w_like_charge * n_like
        score_screened_charge = args.w_screened_charge * (
            screened_charge_favorable_abs - screened_charge_unfavorable
        )
        score_hydrophobic = args.w_hydrophobic * n_hydro
        score_cationpi = args.w_cationpi * n_cationpi
        score_pipi = args.w_pipi * n_pipi
        score_argarg = args.w_argarg * n_argarg
        score_hbond = args.w_hbond * n_hbond
        score_clash_penalty = -args.w_clash * n_clash
        total_score_raw = (
            score_charge_contacts
            + score_screened_charge
            + score_hydrophobic
            + score_cationpi
            + score_pipi
            + score_argarg
            + score_hbond
            + score_clash_penalty
        )

        favorable_contact_score = (
            args.w_opposite_charge * n_opp
            + args.w_hydrophobic * n_hydro
            + args.w_cationpi * n_cationpi
            + args.w_pipi * n_pipi
            + args.w_argarg * n_argarg
            + args.w_hbond * n_hbond
            + args.w_screened_charge * screened_charge_favorable_abs
        )
        unfavorable_contact_score = (
            args.w_like_charge * n_like
            + args.w_screened_charge * screened_charge_unfavorable
            + args.w_clash * n_clash
        )

        equivalent_weight_contact_score = (
            n_opp
            - n_like
            - screened_charge_score
            + n_hydro
            + n_cationpi
            + n_pipi
            + n_argarg
            + n_hbond
            - n_clash if args.w_clash != 0 else
            n_opp - n_like - screened_charge_score + n_hydro + n_cationpi + n_pipi + n_argarg + n_hbond
        )

        target_idr_seq = "".join(r.aa for r in sorted(target_idr_res, key=lambda r: (r.chain, r.resseq, r.icode)))
        fd_seq_len = len(folded_res)

        row = {
            "ensemble_name": ensemble_name,
            "protein_id": protein_id,
            "variant_name": variant_name,
            "model_index": model_index,
            "target_ranges": ";".join(f"{s}-{e}" for s, e in target_ranges),
            "all_idr_ranges": ";".join(f"{s}-{e}" for s, e in all_idr_ranges),
            "n_target_idr_residues": len(target_idr_res),
            "n_target_idr_residues_total": len(target_idr_res_all),
            "n_target_idr_residues_scored_after_anchor_cutoff": len(target_idr_res),
            "anchor_cutoff_residues": anchor_cutoff,
            "n_folded_domain_residues": fd_seq_len,
            "n_other_idr_residues_excluded": len(other_idr_res),
            "target_idr_ncpr": sum(residue_charge(r, args.histidine_charge) for r in target_idr_res) / max(len(target_idr_res), 1),
            "target_idr_fcr": sum(1 for r in target_idr_res if abs(residue_charge(r, args.histidine_charge)) > 1e-8) / max(len(target_idr_res), 1),
            "target_idr_hydrophobic_frac": sum(1 for r in target_idr_res if r.aa in HYDROPHOBIC) / max(len(target_idr_res), 1),
            "target_idr_aromatic_frac": sum(1 for r in target_idr_res if r.aa in AROMATIC) / max(len(target_idr_res), 1),
            "n_heavy_residue_pairs": len(heavy_pairs),
            "n_heavy_atom_contacts": heavy_atom_contacts,
            "n_opposite_charge_pairs": n_opp,
            "n_like_charge_pairs": n_like,
            "n_charged_contact_pairs": len(charged_pairs_contact),
            "n_hydrophobic_pairs": n_hydro,
            "n_hydrophobic_atom_contacts": hydro_atom_contacts,
            "n_cationpi_pairs": n_cationpi,
            "n_pipi_pairs": n_pipi,
            "n_argarg_pairs": n_argarg,
            "n_hbond_pairs": n_hbond,
            "n_hbond_atom_contacts": hbond_atom_contacts,
            "n_clash_residue_pairs": n_clash,
            "n_clash_atom_contacts": clash_atom_contacts,
            "screened_charge_signed_score_raw": screened_charge_score,
            "screened_charge_favorable_abs_raw": screened_charge_favorable_abs,
            "screened_charge_unfavorable_raw": screened_charge_unfavorable,
            "score_charge_contacts": score_charge_contacts,
            "score_screened_charge": score_screened_charge,
            "score_hydrophobic": score_hydrophobic,
            "score_cationpi": score_cationpi,
            "score_pipi": score_pipi,
            "score_argarg": score_argarg,
            "score_hbond": score_hbond,
            "score_clash_penalty": score_clash_penalty,
            "favorable_contact_score": favorable_contact_score,
            "unfavorable_contact_score": unfavorable_contact_score,
            "total_score_raw": total_score_raw,
            "equivalent_weight_contact_score": equivalent_weight_contact_score,
            "sequence_preview": target_idr_seq[:30] + ("..." if len(target_idr_seq) > 30 else ""),
        }
        row.update(boundary_distance_summary("scored_any", scored_any_pairs, target_ranges, max_resseq))
        row.update(boundary_distance_summary("heavy", heavy_pairs, target_ranges, max_resseq))
        return row, warnings, location_rows


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Analyze score-matched IDR:folded-domain contacts in AFX multi-model PDB ensembles. Contact definitions mirror afx_score_reweight_contacts.py."
    )
    inp = p.add_mutually_exclusive_group(required=True)
    inp.add_argument("--pdb-dir", type=Path, help="Directory containing multi-model PDB files.")
    inp.add_argument("--pdb-file", type=Path, help="Single multi-model PDB file.")
    p.add_argument("--master-json", type=Path, required=True, help="Master JSON with IDR intervals keyed by UniProt ID.")
    p.add_argument("--outdir", type=Path, required=True, help="Output directory.")
    p.add_argument("--pattern", default="*.pdb", help="PDB glob pattern if --pdb-dir is used. Default: *.pdb")
    p.add_argument("--recursive", action="store_true", help="Recursively search --pdb-dir for PDB files.")
    p.add_argument("--chain", default=None, help="Optional chain ID to analyze. Default: all chains.")
    p.add_argument("--n-workers", type=int, default=1, help="Number of PDB files to process in parallel.")
    p.add_argument("--model-stride", type=int, default=1, help="Analyze every Nth model. Default: 1")
    p.add_argument("--max-models", type=int, default=None, help="Maximum number of models to analyze per PDB.")
    p.add_argument("--checkpoint-every", type=int, default=100, help="Flush results to disk every N processed PDB files. Default: 100")
    p.add_argument("--restart", action="store_true", help="Start fresh in --outdir instead of resuming from an existing checkpoint.")
    p.add_argument("--retry-failed-only", action="store_true", help="When resuming, process only PDBs marked failed in checkpoint_manifest.csv.")
    p.add_argument("--max-tasks-per-child", type=int, default=25, help="Recycle workers after N tasks. Set 0 to disable. Default: 25")
    p.add_argument("--write-per-protein", action="store_true", help="Also write per-protein CSV files.")
    p.add_argument("--make-plots", action="store_true", help="Write simple residue-pair occupancy heatmaps.")

    target = p.add_argument_group("IDR targeting")
    target.add_argument("--target-terminal", choices=["all", "N", "C"], default="all", help="Which terminal IDR(s) to analyze. Default: all selected IDRs.")
    target.add_argument("--target-idrs", default=None, help="Comma-separated IDR labels or intervals, e.g. IDR1,IDR3 or 1-132. Overrides --target-terminal.")
    target.add_argument("--anchor-cutoff", type=int, default=10, help="Only analyze IDR:FD contacts made by IDR residues at least this many residues away from the selected IDR:FD junction. Default: 10")

    cut = p.add_argument_group("contact cutoffs")
    cut.add_argument("--heavy-cutoff", type=float, default=4.5, help="Heavy-atom residue contact cutoff in Å. Default: 4.5")
    cut.add_argument("--charge-contact-cutoff", type=float, default=6.0, help="Charged residue contact cutoff in Å. Default: 6")
    cut.add_argument("--electro-cutoff", type=float, default=20.0, help="Screened electrostatic residue-center cutoff in Å. Default: 20")
    cut.add_argument("--hydrophobic-cutoff", type=float, default=4.5, help="Hydrophobic sidechain atom cutoff in Å. Default: 4.5")
    cut.add_argument("--cationpi-cutoff", type=float, default=6.0, help="Cation to aromatic-centroid cutoff in Å. Default: 6")
    cut.add_argument("--pipi-cutoff", type=float, default=6.0, help="Pi-system centroid cutoff in Å. Default: 6")
    cut.add_argument("--argarg-cutoff", type=float, default=6.0, help="Arg guanidinium-centroid cutoff in Å. Default: 6")
    cut.add_argument("--hbond-cutoff", type=float, default=3.5, help="Donor/acceptor heavy-atom cutoff for H-bond-like contacts in Å. Default: 3.5")
    cut.add_argument("--hbond-h-a-cutoff", type=float, default=2.5, help="Hydrogen-acceptor cutoff when explicit H atoms are present. Default: 2.5 Å")
    cut.add_argument("--hbond-angle-cutoff", type=float, default=120.0, help="Minimum D-H-A angle when explicit H atoms are present. Default: 120 degrees")
    cut.add_argument("--hbond-geometry", choices=["heavy_only", "angle_if_hydrogens", "angle_strict"], default="angle_if_hydrogens", help="Hydrogen-bond geometry rule. Default: angle_if_hydrogens")
    cut.add_argument("--hbond-mode", choices=["all", "no_backbone_backbone", "sidechain_only"], default="no_backbone_backbone", help="Which donor/acceptor atom pairs to count. Default: no_backbone_backbone")
    cut.add_argument("--clash-cutoff", type=float, default=2.2, help="Heavy-atom IDR:FD clash cutoff in Å. Default: 2.2")

    score = p.add_argument_group("Score columns included for compatibility")
    score.add_argument("--histidine-charge", type=float, default=0.1, help="Effective His charge. Default: 0.1")
    score.add_argument("--debye-length", type=float, default=10.0, help="Screening length for charge term in Å. Default: 10")
    score.add_argument("--w-opposite-charge", type=float, default=1.0, help="Reward for each opposite-charge contact. Default: 1")
    score.add_argument("--w-like-charge", type=float, default=1.0, help="Penalty for each like-charge contact. Default: 1")
    score.add_argument("--w-screened-charge", type=float, default=1.0, help="Weight for screened charge score. Default: 1")
    score.add_argument("--w-hydrophobic", type=float, default=0.50, help="Reward for each hydrophobic contact. Default: 0.50")
    score.add_argument("--w-cationpi", type=float, default=0.75, help="Reward for each cation-pi contact. Default: 0.75")
    score.add_argument("--w-pipi", type=float, default=0.75, help="Reward for each pi-pi contact. Default: 0.75")
    score.add_argument("--w-argarg", type=float, default=0.50, help="Reward for each Arg-Arg contact. Default: 0.50")
    score.add_argument("--w-hbond", type=float, default=0.25, help="Reward for each H-bond-like pair. Default: 0.25")
    score.add_argument("--w-clash", type=float, default=0.0, help="Optional clash penalty. Default: 0")
    return p.parse_args()


CONTACT_TYPES = [
    "scored_any",
    "heavy",
    "opposite_charge",
    "like_charge",
    "hydrophobic",
    "cationpi",
    "pipi",
    "argarg",
    "hbond",
    "clash",
]

_WORKER_MASTER: Optional[Dict[str, dict]] = None
_WORKER_OPTS: Optional[dict] = None


def normalize_pdb_path(path_like: str) -> str:
    try:
        return str(Path(path_like).resolve())
    except Exception:
        return str(Path(path_like))


def load_manifest_statuses(manifest_path: Path) -> Dict[str, str]:
    if not manifest_path.exists() or manifest_path.stat().st_size == 0:
        return {}
    try:
        df = pd.read_csv(manifest_path)
    except Exception:
        return {}
    if "status" not in df.columns or "pdb_file" not in df.columns:
        return {}
    statuses: Dict[str, str] = {}
    for _, row in df.iterrows():
        pdb_file = normalize_pdb_path(str(row.get("pdb_file", "")))
        status = str(row.get("status", "")).strip().lower()
        if pdb_file:
            statuses[pdb_file] = status
    return statuses


def append_rows_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        return
    df = pd.DataFrame(rows)
    header = not path.exists() or path.stat().st_size == 0
    df.to_csv(path, mode="a", header=header, index=False)


def initialize_outputs(args: argparse.Namespace) -> Dict[str, Path]:
    files = {
        "model": args.outdir / "idr_fd_interactions_by_model.csv",
        "pair": args.outdir / "residue_pair_contact_occupancy.csv",
        "residue": args.outdir / "residue_contact_occupancy.csv",
        "contacts_long": args.outdir / "residue_pair_contacts_by_model_long.csv",
        "summary": args.outdir / "idr_fd_interaction_summary_by_protein.csv",
        "warnings": args.outdir / "warnings.csv",
        "manifest": args.outdir / "checkpoint_manifest.csv",
    }
    if args.restart:
        for pth in files.values():
            if pth.exists():
                pth.unlink()
    return files


def failure_result(pdb_path_s: str, exc: Exception) -> dict:
    return {
        "protein_id": None,
        "pdb": str(pdb_path_s),
        "model_rows": [],
        "contact_rows": [],
        "warnings": [f"worker-level failure: {type(exc).__name__}: {exc}"],
    }


def process_one_pdb_interactions(payload: Tuple[str, dict, dict]) -> dict:
    pdb_path_str, master, opt = payload
    class Opt:
        pass
    args = Opt()
    for k, v in opt.items():
        setattr(args, k, v)

    pdb_path = Path(pdb_path_str)
    protein_id = infer_protein_id(pdb_path, list(master.keys()))
    if protein_id is None:
        return {"pdb": str(pdb_path), "protein_id": None, "model_rows": [], "contact_rows": [], "warnings": ["could not infer protein id from filename"]}
    if protein_id not in master or "idrs" not in master[protein_id]:
        return {"pdb": str(pdb_path), "protein_id": protein_id, "model_rows": [], "contact_rows": [], "warnings": ["protein id missing or has no idrs in master JSON"]}

    all_ranges = normalize_idr_ranges(master[protein_id]["idrs"])
    models = split_models(pdb_path)
    if not models:
        return {"pdb": str(pdb_path), "protein_id": protein_id, "model_rows": [], "contact_rows": [], "warnings": ["no models/ATOM records found"]}

    stride = max(1, int(args.model_stride))
    selected_models = [(i + 1, m) for i, m in enumerate(models) if i % stride == 0]
    if args.max_models is not None:
        selected_models = selected_models[: int(args.max_models)]
    if not selected_models:
        return {"pdb": str(pdb_path), "protein_id": protein_id, "model_rows": [], "contact_rows": [], "warnings": ["no models selected after stride/max-model filters"]}

    first_residues = model_to_residues(selected_models[0][1], chain_filter=args.chain)
    max_resseq = max([r.resseq for r in first_residues.values()], default=max(e for _, e in all_ranges))
    try:
        target_ranges = select_target_ranges(all_ranges, args, max_resseq)
    except Exception as exc:
        return {"pdb": str(pdb_path), "protein_id": protein_id, "model_rows": [], "contact_rows": [], "warnings": [str(exc)]}
    if not target_ranges:
        return {"pdb": str(pdb_path), "protein_id": protein_id, "model_rows": [], "contact_rows": [], "warnings": [f"no target IDR ranges selected from {all_ranges}"]}

    ensemble_name = pdb_path.stem
    variant_name = infer_variant_name(pdb_path, protein_id)
    model_rows: List[dict] = []
    contact_rows: List[dict] = []
    warnings: List[str] = []
    for model_index, model_lines in selected_models:
        row, ws, loc_rows = score_model(
            model_lines,
            model_index=model_index,
            protein_id=protein_id,
            ensemble_name=ensemble_name,
            variant_name=variant_name,
            all_idr_ranges=all_ranges,
            target_ranges=target_ranges,
            args=args,
        )
        warnings.extend([f"model {model_index}: {w}" for w in ws])
        if row is not None:
            row["pdb_file"] = str(pdb_path)
            # Explicit any-contact flags for compatibility with the older interaction profiler.
            for ctype, col in [
                ("heavy", "n_heavy_residue_pairs"),
                ("opposite_charge", "n_opposite_charge_pairs"),
                ("like_charge", "n_like_charge_pairs"),
                ("hydrophobic", "n_hydrophobic_pairs"),
                ("cationpi", "n_cationpi_pairs"),
                ("pipi", "n_pipi_pairs"),
                ("argarg", "n_argarg_pairs"),
                ("hbond", "n_hbond_pairs"),
                ("clash", "n_clash_residue_pairs"),
            ]:
                row[f"any_{ctype}_contact"] = int(float(row.get(col, 0)) > 0)
            model_rows.append(row)
        for lr in loc_rows:
            lr["pdb_file"] = str(pdb_path)
        contact_rows.extend(loc_rows)

    return {"pdb": str(pdb_path), "protein_id": protein_id, "model_rows": model_rows, "contact_rows": contact_rows, "warnings": warnings}


def init_worker(master: Dict[str, dict], opts: dict) -> None:
    global _WORKER_MASTER, _WORKER_OPTS
    _WORKER_MASTER = master
    _WORKER_OPTS = opts


def process_one_pdb_in_worker(pdb_path_s: str) -> dict:
    if _WORKER_MASTER is None or _WORKER_OPTS is None:
        raise RuntimeError("worker not initialized")
    return process_one_pdb_interactions((pdb_path_s, _WORKER_MASTER, _WORKER_OPTS))


def _safe_int(value) -> int:
    try:
        return int(value)
    except Exception:
        return int(float(value))


def _residue_label(chain, aa, resseq, icode) -> str:
    chain = str(chain) if pd.notna(chain) else ""
    aa = str(aa) if pd.notna(aa) else "X"
    icode = "" if pd.isna(icode) else str(icode)
    return f"{chain}:{aa}{_safe_int(resseq)}{icode}"


def make_pair_occupancy(contact_rows: List[dict], model_rows: List[dict]) -> pd.DataFrame:
    if not contact_rows:
        return pd.DataFrame()
    cdf = pd.DataFrame(contact_rows).drop_duplicates(
        subset=["ensemble_name", "model_index", "contact_type", "idr_chain", "idr_resseq", "idr_icode", "fd_chain", "fd_resseq", "fd_icode"]
    )
    mdf = pd.DataFrame(model_rows)
    denom = mdf.groupby(["protein_id", "variant_name", "ensemble_name"], dropna=False)["model_index"].nunique().to_dict() if not mdf.empty else {}
    key_cols = ["protein_id", "variant_name", "ensemble_name", "target_ranges", "idr_chain", "idr_resseq", "idr_icode", "idr_aa", "fd_chain", "fd_resseq", "fd_icode", "fd_aa"]
    base = cdf[key_cols].drop_duplicates().copy()
    for ctype in CONTACT_TYPES:
        sub = cdf[cdf["contact_type"] == ctype]
        counts = sub.groupby(key_cols, dropna=False)["model_index"].nunique().reset_index(name=f"{ctype}_models")
        base = base.merge(counts, on=key_cols, how="left")
        base[f"{ctype}_models"] = base[f"{ctype}_models"].fillna(0).astype(int)
    def n_models_for(row):
        return int(denom.get((row["protein_id"], row["variant_name"], row["ensemble_name"]), 0))
    base["n_models_analyzed"] = base.apply(n_models_for, axis=1)
    for ctype in CONTACT_TYPES:
        base[f"{ctype}_occupancy"] = base.apply(lambda r: float(r[f"{ctype}_models"] / r["n_models_analyzed"]) if r["n_models_analyzed"] else float("nan"), axis=1)
    base["idr_residue_label"] = base.apply(lambda r: _residue_label(r["idr_chain"], r["idr_aa"], r["idr_resseq"], r["idr_icode"]), axis=1)
    base["fd_residue_label"] = base.apply(lambda r: _residue_label(r["fd_chain"], r["fd_aa"], r["fd_resseq"], r["fd_icode"]), axis=1)
    return base.sort_values(["protein_id", "variant_name", "ensemble_name", "idr_chain", "idr_resseq", "fd_chain", "fd_resseq"])


def make_residue_occupancy(contact_rows: List[dict], model_rows: List[dict]) -> pd.DataFrame:
    if not contact_rows:
        return pd.DataFrame()
    cdf = pd.DataFrame(contact_rows).drop_duplicates(
        subset=["ensemble_name", "model_index", "contact_type", "idr_chain", "idr_resseq", "idr_icode", "fd_chain", "fd_resseq", "fd_icode"]
    )
    mdf = pd.DataFrame(model_rows)
    denom = mdf.groupby(["protein_id", "variant_name", "ensemble_name"], dropna=False)["model_index"].nunique().to_dict() if not mdf.empty else {}
    rows = []
    for domain, prefix in [("IDR", "idr"), ("FD", "fd")]:
        cols = ["protein_id", "variant_name", "ensemble_name", "target_ranges", f"{prefix}_chain", f"{prefix}_resseq", f"{prefix}_icode", f"{prefix}_aa"]
        base = cdf[cols].drop_duplicates().copy()
        base = base.rename(columns={f"{prefix}_chain": "chain", f"{prefix}_resseq": "resseq", f"{prefix}_icode": "icode", f"{prefix}_aa": "aa"})
        key_cols = ["protein_id", "variant_name", "ensemble_name", "target_ranges", "chain", "resseq", "icode", "aa"]
        for ctype in CONTACT_TYPES:
            sub = cdf[cdf["contact_type"] == ctype][cols + ["model_index"]].copy()
            sub = sub.rename(columns={f"{prefix}_chain": "chain", f"{prefix}_resseq": "resseq", f"{prefix}_icode": "icode", f"{prefix}_aa": "aa"})
            counts = sub.groupby(key_cols, dropna=False)["model_index"].nunique().reset_index(name=f"{ctype}_models")
            base = base.merge(counts, on=key_cols, how="left")
            base[f"{ctype}_models"] = base[f"{ctype}_models"].fillna(0).astype(int)
        base["domain_class"] = domain
        base["n_models_analyzed"] = base.apply(lambda r: int(denom.get((r["protein_id"], r["variant_name"], r["ensemble_name"]), 0)), axis=1)
        for ctype in CONTACT_TYPES:
            base[f"{ctype}_occupancy"] = base.apply(lambda r: float(r[f"{ctype}_models"] / r["n_models_analyzed"]) if r["n_models_analyzed"] else float("nan"), axis=1)
        base["residue_label"] = base.apply(lambda r: _residue_label(r["chain"], r["aa"], r["resseq"], r["icode"]), axis=1)
        rows.append(base)
    if not rows:
        return pd.DataFrame()
    return pd.concat(rows, ignore_index=True).sort_values(["protein_id", "variant_name", "ensemble_name", "domain_class", "chain", "resseq"])


def make_summary(model_df: pd.DataFrame) -> pd.DataFrame:
    if model_df.empty:
        return pd.DataFrame()
    rows = []
    group_cols = ["protein_id", "variant_name", "ensemble_name"]
    count_cols = [
        "n_heavy_residue_pairs", "n_opposite_charge_pairs", "n_like_charge_pairs", "n_hydrophobic_pairs",
        "n_cationpi_pairs", "n_pipi_pairs", "n_argarg_pairs", "n_hbond_pairs", "n_clash_residue_pairs",
        "screened_charge_signed_score_raw", "screened_charge_favorable_abs_raw", "screened_charge_unfavorable_raw",
        "favorable_contact_score", "unfavorable_contact_score", "total_score_raw", "equivalent_weight_contact_score",
        "mean_scored_any_idr_boundary_distance", "frac_scored_any_idr_distance_gt5", "frac_scored_any_idr_distance_gt10",
    ]
    for keys, g in model_df.groupby(group_cols, dropna=False, sort=False):
        row = dict(zip(group_cols, keys))
        row["n_models_scored"] = int(g["model_index"].nunique())
        for col in count_cols:
            if col in g.columns:
                vals = pd.to_numeric(g[col], errors="coerce")
                row[f"mean_{col}"] = float(vals.mean()) if len(vals.dropna()) else float("nan")
                row[f"std_{col}"] = float(vals.std(ddof=0)) if len(vals.dropna()) else float("nan")
        rows.append(row)
    return pd.DataFrame(rows).sort_values(group_cols)


def make_heatmap(pair_df: pd.DataFrame, out_png: Path, value_col: str, title: str) -> None:
    if pair_df.empty or value_col not in pair_df.columns:
        return
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return
    df = pair_df.copy()
    if pd.to_numeric(df[value_col], errors="coerce").fillna(0).max() <= 0:
        return
    idr_vals = sorted(df["idr_resseq"].dropna().unique())
    fd_vals = sorted(df["fd_resseq"].dropna().unique())
    if not idr_vals or not fd_vals:
        return
    idr_index = {v: i for i, v in enumerate(idr_vals)}
    fd_index = {v: i for i, v in enumerate(fd_vals)}
    mat = np.zeros((len(idr_vals), len(fd_vals)), dtype=float)
    for _, row in df.iterrows():
        mat[idr_index[row["idr_resseq"]], fd_index[row["fd_resseq"]]] = max(mat[idr_index[row["idr_resseq"]], fd_index[row["fd_resseq"]]], float(row[value_col]))
    width = max(5.0, min(16.0, len(fd_vals) / 18.0))
    height = max(4.0, min(12.0, len(idr_vals) / 18.0))
    fig, ax = plt.subplots(figsize=(width, height), dpi=200)
    im = ax.imshow(mat, aspect="auto", origin="lower", interpolation="nearest", vmin=0, vmax=1)
    ax.set_xlabel("Folded-domain residue number")
    ax.set_ylabel("IDR residue number")
    ax.set_title(title)
    def sparse_ticks(vals, max_ticks=10):
        if len(vals) <= max_ticks:
            idx = list(range(len(vals)))
        else:
            idx = np.linspace(0, len(vals) - 1, max_ticks).astype(int).tolist()
        return idx, [str(vals[i]) for i in idx]
    xt, xl = sparse_ticks(fd_vals)
    yt, yl = sparse_ticks(idr_vals)
    ax.set_xticks(xt, xl, rotation=90)
    ax.set_yticks(yt, yl)
    cb = fig.colorbar(im, ax=ax)
    cb.set_label("occupancy")
    fig.tight_layout()
    fig.savefig(out_png)
    plt.close(fig)


def flush_results(batch_results: List[dict], args: argparse.Namespace, filemap: Dict[str, Path], per_protein_dir: Path, plot_dir: Path) -> Dict[str, int]:
    all_model_rows: List[dict] = []
    all_contact_rows: List[dict] = []
    warning_rows: List[dict] = []
    manifest_rows: List[dict] = []
    for res in batch_results:
        pid = res.get("protein_id")
        pdb_file = str(res.get("pdb"))
        model_rows = res.get("model_rows", [])
        contact_rows = res.get("contact_rows", [])
        warnings = res.get("warnings", [])
        all_model_rows.extend(model_rows)
        all_contact_rows.extend(contact_rows)
        for w in warnings:
            warning_rows.append({"protein_id": pid, "pdb_file": pdb_file, "warning": w})
        status = "done"
        if pid is None and not model_rows and not contact_rows and warnings:
            status = "failed"
        manifest_rows.append({
            "pdb_file": pdb_file,
            "protein_id": pid,
            "status": status,
            "n_model_rows": len(model_rows),
            "n_contact_rows": len(contact_rows),
            "n_warnings": len(warnings),
            "timestamp": pd.Timestamp.now().isoformat(),
        })
        if args.write_per_protein and pid:
            if model_rows:
                pd.DataFrame(model_rows).to_csv(per_protein_dir / f"{pid}_idr_fd_interactions_by_model.csv", index=False)
            if contact_rows:
                local_contact_df = pd.DataFrame(contact_rows)
                local_contact_df.to_csv(per_protein_dir / f"{pid}_residue_pair_contacts_by_model_long.csv", index=False)
                local_pair_df = make_pair_occupancy(contact_rows, model_rows)
                if not local_pair_df.empty:
                    local_pair_df.to_csv(per_protein_dir / f"{pid}_residue_pair_contact_occupancy.csv", index=False)
                    if args.make_plots:
                        for ctype in ["heavy", "opposite_charge", "like_charge", "hydrophobic", "cationpi", "pipi", "argarg", "hbond"]:
                            make_heatmap(local_pair_df, plot_dir / f"{pid}_{ctype}_occupancy_heatmap.png", f"{ctype}_occupancy", f"{pid} IDR:FD {ctype} occupancy")
                local_res_df = make_residue_occupancy(contact_rows, model_rows)
                if not local_res_df.empty:
                    local_res_df.to_csv(per_protein_dir / f"{pid}_residue_contact_occupancy.csv", index=False)
    pair_df = make_pair_occupancy(all_contact_rows, all_model_rows)
    residue_df = make_residue_occupancy(all_contact_rows, all_model_rows)
    append_rows_csv(filemap["model"], all_model_rows)
    append_rows_csv(filemap["contacts_long"], all_contact_rows)
    append_rows_csv(filemap["pair"], pair_df.to_dict("records") if not pair_df.empty else [])
    append_rows_csv(filemap["residue"], residue_df.to_dict("records") if not residue_df.empty else [])
    append_rows_csv(filemap["warnings"], warning_rows)
    append_rows_csv(filemap["manifest"], manifest_rows)
    return {"proteins": len(batch_results), "model_rows": len(all_model_rows), "contact_rows": len(all_contact_rows), "pair_rows": len(pair_df), "residue_rows": len(residue_df), "warnings": len(warning_rows)}


def rebuild_final_summary(filemap: Dict[str, Path]) -> None:
    if filemap["model"].exists() and filemap["model"].stat().st_size > 0:
        try:
            model_df = pd.read_csv(filemap["model"])
        except Exception:
            return
        summary = make_summary(model_df)
        if not summary.empty:
            summary.to_csv(filemap["summary"], index=False)


def main() -> None:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    per_protein_dir = args.outdir / "per_protein"
    if args.write_per_protein:
        per_protein_dir.mkdir(parents=True, exist_ok=True)
    plot_dir = args.outdir / "plots"
    if args.make_plots:
        plot_dir.mkdir(parents=True, exist_ok=True)

    filemap = initialize_outputs(args)
    manifest_status = {} if args.restart else load_manifest_statuses(filemap["manifest"])
    master = load_json(args.master_json)
    pdbs = find_pdbs(args)
    if not pdbs:
        sys.exit("ERROR: no PDB files found.")
    if args.retry_failed_only and not args.restart:
        failed_states = {"failed", "error"}
        pdbs = [p for p in pdbs if manifest_status.get(normalize_pdb_path(str(p))) in failed_states]
        print(f"Resume mode: retry-failed-only. Scheduled {len(pdbs)} failed PDB(s) from checkpoint manifest.")
    elif not args.restart:
        pdbs = [p for p in pdbs if manifest_status.get(normalize_pdb_path(str(p))) != "done"]
    if not pdbs:
        print(f"Nothing to do. All requested PDBs already processed according to {filemap['manifest']}")
        rebuild_final_summary(filemap)
        return

    opt_keys = [
        "chain", "model_stride", "max_models", "target_terminal", "target_idrs", "anchor_cutoff",
        "heavy_cutoff", "charge_contact_cutoff", "electro_cutoff", "hydrophobic_cutoff", "cationpi_cutoff", "pipi_cutoff", "argarg_cutoff",
        "hbond_cutoff", "hbond_h_a_cutoff", "hbond_angle_cutoff", "hbond_geometry", "hbond_mode", "clash_cutoff",
        "histidine_charge", "debye_length", "w_opposite_charge", "w_like_charge", "w_screened_charge", "w_hydrophobic", "w_cationpi", "w_pipi", "w_argarg", "w_hbond", "w_clash",
    ]
    opts = {k: getattr(args, k) for k in opt_keys}
    payloads = [str(p) for p in pdbs]
    workers = max(1, args.n_workers)
    checkpoint_every = max(1, args.checkpoint_every)
    pending_results: List[dict] = []
    total_stats = {"proteins": 0, "model_rows": 0, "contact_rows": 0, "pair_rows": 0, "residue_rows": 0, "warnings": 0}

    def maybe_flush(force: bool = False) -> None:
        nonlocal pending_results, total_stats
        if pending_results and (force or len(pending_results) >= checkpoint_every):
            stats = flush_results(pending_results, args, filemap, per_protein_dir, plot_dir)
            for k, v in stats.items():
                total_stats[k] = total_stats.get(k, 0) + v
            print(f"[checkpoint] wrote {stats['proteins']} PDBs | +{stats['model_rows']} model rows | +{stats['contact_rows']} long contact rows | +{stats['pair_rows']} pair rows | +{stats['residue_rows']} residue rows | +{stats['warnings']} warnings", flush=True)
            pending_results = []

    if workers == 1:
        for pdb_path_s in tqdm(payloads, desc="Analyzing PDBs"):
            try:
                pending_results.append(process_one_pdb_interactions((pdb_path_s, master, opts)))
            except Exception as exc:
                pending_results.append(failure_result(pdb_path_s, exc))
            maybe_flush()
    else:
        chunk_size = max(workers * 4, 1)
        for i in range(0, len(payloads), chunk_size):
            chunk = payloads[i:i + chunk_size]
            processed_in_chunk: Set[str] = set()
            ex_kwargs = {"max_workers": workers, "initializer": init_worker, "initargs": (master, opts)}
            if args.max_tasks_per_child and args.max_tasks_per_child > 0:
                ex_kwargs["max_tasks_per_child"] = args.max_tasks_per_child
            try:
                with cf.ProcessPoolExecutor(**ex_kwargs) as ex:
                    fut_to_pdb = {ex.submit(process_one_pdb_in_worker, pdb_path_s): pdb_path_s for pdb_path_s in chunk}
                    for fut in tqdm(cf.as_completed(fut_to_pdb), total=len(fut_to_pdb), desc="Analyzing PDBs", leave=False):
                        pdb_path_s = fut_to_pdb[fut]
                        processed_in_chunk.add(pdb_path_s)
                        try:
                            pending_results.append(fut.result())
                        except Exception as exc:
                            pending_results.append(failure_result(pdb_path_s, exc))
                        maybe_flush()
            except Exception as exc:
                print(f"[warning] Process pool failed ({type(exc).__name__}: {exc}). Retrying unfinished files from this chunk serially.", flush=True)
                for pdb_path_s in chunk:
                    if pdb_path_s in processed_in_chunk:
                        continue
                    try:
                        pending_results.append(process_one_pdb_interactions((pdb_path_s, master, opts)))
                    except Exception as serial_exc:
                        pending_results.append(failure_result(pdb_path_s, serial_exc))
                    maybe_flush()
    maybe_flush(force=True)
    rebuild_final_summary(filemap)
    print(f"Done. Wrote outputs to {args.outdir}")


if __name__ == "__main__":
    main()
