"""
Score and reweight AlphaFlex/AFX multi-model PDB ensembles using an interpretable
knowledge-based contact score for IDR:folded-domain contacts.

The score is intentionally not a physical force-field term. It is a transparent
ranking/reweighting heuristic that decomposes each conformer into:
  - favorable opposite-charge contacts
  - unfavorable like-charge contacts
  - screened charge contact score
  - hydrophobic contacts
  - cation-pi contacts (cationic Lys, Arg guanidinium, and cationic His to aromatic/imidazole pi systems)
  - pi-pi contacts involving aromatic/imidazole pi systems and Arg guanidinium pi systems
  - favorable Arg-Arg guanidinium/π-stacking-like contacts
  - hydrogen-bond-like donor/acceptor contacts
  - optional steric clash diagnostic
  - contact-localization diagnostics relative to IDR:folded-domain sequence boundaries

Higher total_score = more favorable according to the selected weights.

Recommended chimera usage, e.g. score only N-terminal mutated IDRs:
  python afx_score_reweight_contacts.py \
    --pdb-dir ../AF_chimera_ensembles \
    --master-json ../databases/min15_updated_PAE_master_db_fixed.json \
    --outdir ../surface_chemistry/chimera_scored_reweighted \
    --target-terminal N \
    --n-workers 16 \
    --extract-top-n 10 \
    --make-readable-summaries

Dependencies:
  pip install numpy pandas scipy tqdm matplotlib
"""
import argparse
import concurrent.futures as cf
import json
import math
import re
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple, Set

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.spatial import cKDTree
from tqdm import tqdm

AA3_TO_1 = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "HID": "H",
    "HIE": "H", "HIP": "H", "ILE": "I", "LEU": "L", "LYS": "K",
    "MET": "M", "MSE": "M", "PHE": "F", "PRO": "P", "SER": "S",
    "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V",
}

BACKBONE_ATOMS = {"N", "CA", "C", "O", "OXT"}
NEGATIVE = {"D", "E"}
POSITIVE = {"K", "R"}
HYDROPHOBIC = set("AVILMFWYPC")
AROMATIC = set("FYWH")
PI_SYSTEM = set("FYWHR")
PI_STACK_ANCHOR = set("FYWH")

# Ring atom definitions. For Trp, use one combined indole centroid for simplicity.
RING_ATOMS = {
    "F": {"CG", "CD1", "CD2", "CE1", "CE2", "CZ"},
    "Y": {"CG", "CD1", "CD2", "CE1", "CE2", "CZ"},
    "W": {"CG", "CD1", "CD2", "NE1", "CE2", "CE3", "CZ2", "CZ3", "CH2"},
    "H": {"CG", "ND1", "CD2", "CE1", "NE2"},
}

# Atom sets used to define residue-level cation centers for cation-pi scoring.
# This is intentionally more specific than a generic side-chain centroid:
# Lys uses the terminal ammonium N, Arg uses the guanidinium group, and
# protonated/effectively cationic His uses the imidazole ring center.
CATION_CENTER_ATOMS = {
    "K": {"NZ"},
    "R": {"NE", "CZ", "NH1", "NH2"},
    "H": RING_ATOMS["H"],
}

# Pi-system centers for pi-pi scoring. In this heuristic, Arg contributes via
# its delocalized guanidinium group, His via its imidazole, and F/Y/W via
# aromatic ring centroids. A pi-pi pair must include at least one aromatic or
# imidazole partner so Arg-Arg like-charge proximity is not rewarded as pi-pi.
PI_SYSTEM_CENTER_ATOMS = {
    "F": RING_ATOMS["F"],
    "Y": RING_ATOMS["Y"],
    "W": RING_ATOMS["W"],
    "H": RING_ATOMS["H"],
    "R": {"NE", "CZ", "NH1", "NH2"},
}

ResidueKey = Tuple[str, int, str]
ResiduePair = Tuple[ResidueKey, ResidueKey]


@dataclass(frozen=True)
class Atom:
    record: str
    serial: int
    atom_name: str
    resname: str
    chain: str
    resseq: int
    icode: str
    element: str
    xyz: Tuple[float, float, float]

    @property
    def key(self) -> ResidueKey:
        return (self.chain, self.resseq, self.icode)


@dataclass
class Residue:
    key: ResidueKey
    chain: str
    resseq: int
    icode: str
    resname: str
    aa: str
    atoms: List[Atom]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Score/reweight IDR:folded-domain contacts in AFX multi-model PDB ensembles."
    )
    inp = p.add_mutually_exclusive_group(required=True)
    inp.add_argument("--pdb-dir", type=Path, help="Directory containing multi-model PDB files.")
    inp.add_argument("--pdb-file", type=Path, help="Single multi-model PDB file.")
    p.add_argument("--master-json", type=Path, required=True, help="Master JSON with IDR intervals keyed by UniProt ID.")
    p.add_argument("--outdir", type=Path, required=True, help="Output directory.")
    p.add_argument("--pattern", default="*.pdb", help="PDB glob pattern if --pdb-dir is used. Default: *.pdb")
    p.add_argument("--recursive", action="store_true", help="Recursively search --pdb-dir for PDB files.")
    p.add_argument("--chain", default=None, help="Optional chain ID to analyze. Default: all chains.")
    p.add_argument("--n-workers", type=int, default=1, help="Number of PDB files to process in parallel.")
    p.add_argument("--model-stride", type=int, default=1, help="Analyze every Nth model. Default: 1")
    p.add_argument("--max-models", type=int, default=None, help="Maximum number of models to analyze per PDB.")

    target = p.add_argument_group("IDR targeting")
    target.add_argument(
        "--target-terminal",
        choices=["all", "N", "C"],
        default="all",
        help="Which terminal IDR(s) to score. Use N for your current chimera panel. Default: all selected IDRs.",
    )
    target.add_argument(
        "--target-idrs",
        default=None,
        help="Comma-separated IDR labels or intervals to score, e.g. IDR1,IDR3 or 1-132. Overrides --target-terminal.",
    )
    target.add_argument(
        "--anchor-cutoff",
        type=int,
        default=10,
        help="Only score IDR:FD contacts made by IDR residues at least this many residues away from the selected IDR:FD junction. Use 0 to include anchor-adjacent residues. Default: 10",
    )

    cut = p.add_argument_group("contact cutoffs")
    cut.add_argument("--heavy-cutoff", type=float, default=4.5, help="Heavy-atom residue contact cutoff in Å. Default: 4.5")
    cut.add_argument("--charge-contact-cutoff", type=float, default=6.0, help="Charged residue contact cutoff in Å. Default: 6")
    cut.add_argument("--electro-cutoff", type=float, default=20.0, help="Screened electrostatic residue-center cutoff in Å. Default: 20")
    cut.add_argument("--hydrophobic-cutoff", type=float, default=4.5, help="Hydrophobic sidechain atom cutoff in Å. Default: 4.5")
    cut.add_argument("--cationpi-cutoff", type=float, default=6.0, help="Cation to aromatic-centroid cutoff in Å. Default: 6")
    cut.add_argument("--pipi-cutoff", type=float, default=6.0, help="Aromatic-centroid cutoff for pi-pi contacts in Å. Default: 6")
    cut.add_argument("--argarg-cutoff", type=float, default=6.0, help="Arg guanidinium-centroid cutoff for favorable Arg-Arg contacts in Å. Default: 6")
    cut.add_argument("--hbond-cutoff", type=float, default=3.5, help="Donor/acceptor heavy-atom cutoff for hydrogen-bond-like contacts in Å. Default: 3.5")
    cut.add_argument("--hbond-h-a-cutoff", type=float, default=2.5, help="Hydrogen-acceptor cutoff when explicit H atoms are present. Default: 2.5 Å")
    cut.add_argument("--hbond-angle-cutoff", type=float, default=120.0, help="Minimum D-H-A angle when explicit H atoms are present. Default: 120 degrees")
    cut.add_argument(
        "--hbond-geometry",
        choices=["heavy_only", "angle_if_hydrogens", "angle_strict"],
        default="angle_if_hydrogens",
        help="Hydrogen-bond geometry rule. heavy_only uses D/A heavy-atom distance only; angle_if_hydrogens uses H-A distance and D-H-A angle when H atoms are present and falls back to heavy-only otherwise; angle_strict requires explicit H atoms. Default: angle_if_hydrogens",
    )
    cut.add_argument(
        "--hbond-mode",
        choices=["all", "no_backbone_backbone", "sidechain_only"],
        default="no_backbone_backbone",
        help="Which donor/acceptor atom pairs to count as H-bond-like contacts. Default: no_backbone_backbone",
    )
    cut.add_argument("--clash-cutoff", type=float, default=2.2, help="Heavy-atom IDR:FD clash cutoff in Å. Default: 2.2")

    score = p.add_argument_group("contact score weights")
    score.add_argument("--histidine-charge", type=float, default=0.1, help="Effective His charge. Default: 0.1")
    score.add_argument("--debye-length", type=float, default=10.0, help="Screening length for charge term in Å. Default: 10")
    score.add_argument("--w-opposite-charge", type=float, default=1.0, help="Reward for each opposite-charge contact. Default: 1")
    score.add_argument("--w-like-charge", type=float, default=1.0, help="Penalty for each like-charge contact. Default: 1")
    score.add_argument("--w-screened-charge", type=float, default=1.0, help="Weight for screened charge contact score. Default: 1.0")
    score.add_argument("--w-hydrophobic", type=float, default=0.50, help="Reward for each hydrophobic contact. Default: 0.50")
    score.add_argument("--w-cationpi", type=float, default=0.75, help="Reward for each cation-pi contact. Default: 0.75")
    score.add_argument("--w-pipi", type=float, default=0.75, help="Reward for each pi-pi contact. Default: 0.75")
    score.add_argument("--w-argarg", type=float, default=0.50, help="Reward for each Arg-Arg guanidinium/π-stacking-like contact. Default: 0.50")
    score.add_argument("--w-hbond", type=float, default=0.25, help="Low reward for each hydrogen-bond-like residue pair. Default: 0.25")
    score.add_argument("--w-clash", type=float, default=0.0, help="Optional penalty for each IDR:FD heavy-atom clash. Default: 0, i.e. not included in contact score")

    reweight = p.add_argument_group("reweighting")
    reweight.add_argument("--beta", type=float, default=1.0, help="Weighting strength applied to the scaled contact score. Default: 1")
    reweight.add_argument(
        "--weight-scale",
        choices=["zscore", "raw", "minmax"],
        default="zscore",
        help="Scale contact score before converting to weights. Default: zscore",
    )

    out = p.add_argument_group("outputs")
    out.add_argument("--extract-top-n", type=int, default=0, help="Extract top N models per ensemble as clean PDBs. Default: 0")
    out.add_argument("--extract-bottom-n", type=int, default=0, help="Extract bottom N models per ensemble as clean PDBs. Default: 0")
    out.add_argument("--make-readable-summaries", action="store_true", help="Write per-ensemble markdown summaries.")
    out.add_argument("--summary-contact-pair-limit", type=int, default=30, help="Maximum residue pairs to list per contact type/model in readable summaries. Default: 30")
    out.add_argument("--make-plots", action="store_true", help="Write interpretable summary plots into outdir/plots.")
    out.add_argument("--make-contact-location-plots", action="store_true", help="Write diagnostic plots showing where IDR:FD contacts occur relative to the selected IDR:FD sequence boundary.")
    out.add_argument("--make-paper-plot", action="store_true", help="Write paper-ready 6-panel contact-score figures into outdir/paper_plots.")
    out.add_argument("--plot-dpi", type=int, default=300, help="DPI for output plots. Default: 300")
    return p.parse_args()


def load_json(path: Path) -> dict:
    with open(path, "r") as handle:
        return json.load(handle)


def find_pdbs(args: argparse.Namespace) -> List[Path]:
    if args.pdb_file:
        return [args.pdb_file]
    globber = args.pdb_dir.rglob if args.recursive else args.pdb_dir.glob
    pdbs = sorted([p for p in globber(args.pattern) if p.is_file()])
    if pdbs:
        return pdbs

    if not args.recursive:
        seen: Set[Path] = set()
        out: List[Path] = []
        for patt in (args.pattern, "*.pdb", "*.PDB"):
            for p in args.pdb_dir.rglob(patt):
                if p.is_file() and p not in seen:
                    out.append(p)
                    seen.add(p)
        return sorted(out)
    return []


def infer_protein_id(pdb_path: Path, master_ids: Sequence[str]) -> Optional[str]:
    stem = pdb_path.stem
    if stem in master_ids:
        return stem
    first = re.split(r"[_\-.]", stem)[0]
    if first in master_ids:
        return first
    hits = [mid for mid in master_ids if mid in stem]
    if hits:
        return sorted(hits, key=len, reverse=True)[0]
    return None


def infer_variant_name(pdb_path: Path, protein_id: Optional[str]) -> str:
    stem = pdb_path.stem
    # Remove common suffixes first.
    stem = re.sub(r"_idpcg_n\d+$", "", stem)
    stem = re.sub(r"_n\d+$", "", stem)
    if protein_id and stem.startswith(protein_id):
        rest = stem[len(protein_id):].strip("_-. ")
        return rest if rest else "ensemble"
    return stem


def clean_line(line: str) -> str:
    # FreeSASA/PDB-generating pipelines sometimes produce unicode-ish minus signs.
    return (
        line.rstrip("\n")
        .replace("¯", "-")
        .replace("−", "-")
        .replace("–", "-")
        .replace("—", "-")
    )


def parse_atom_line(line: str) -> Optional[Atom]:
    line = clean_line(line)
    if not (line.startswith("ATOM") or line.startswith("HETATM")):
        return None

    record = line[:6].strip() or "ATOM"
    # Fixed-width first.
    try:
        serial = int(line[6:11])
        atom_name = line[12:16].strip()
        resname = line[17:20].strip().upper()
        chain = line[21].strip() or "A"
        resseq = int(line[22:26])
        icode = line[26].strip()
        x = float(line[30:38])
        y = float(line[38:46])
        z = float(line[46:54])
        element = line[76:78].strip().upper() if len(line) >= 78 else ""
        if not element:
            element = re.sub(r"[^A-Za-z]", "", atom_name)[:1].upper()
        if resname in AA3_TO_1 and atom_name:
            return Atom(record, serial, atom_name, resname, chain, resseq, icode, element, (x, y, z))
    except Exception:
        pass

    # Whitespace fallback for malformed coordinate columns.
    toks = line.split()
    if len(toks) < 8:
        return None
    try:
        record = toks[0]
        serial = int(toks[1])
        atom_name = toks[2]
        resname = toks[3].upper()
        chain_token = toks[4]
        if len(toks) >= 9 and re.fullmatch(r"-?\d+[A-Za-z]?", toks[5]):
            chain = chain_token if chain_token else "A"
            m = re.match(r"(-?\d+)([A-Za-z]?)", toks[5])
            assert m is not None
            resseq = int(m.group(1))
            icode = m.group(2)
            coord_i = 6
        else:
            m = re.match(r"([A-Za-z]?)(-?\d+)([A-Za-z]?)", chain_token)
            if not m:
                return None
            chain = m.group(1) or "A"
            resseq = int(m.group(2))
            icode = m.group(3) or ""
            coord_i = 5
        x = float(toks[coord_i])
        y = float(toks[coord_i + 1])
        z = float(toks[coord_i + 2])
        element = toks[-1].upper() if toks[-1].isalpha() and len(toks[-1]) <= 2 else re.sub(r"[^A-Za-z]", "", atom_name)[:1].upper()
        if resname in AA3_TO_1 and atom_name:
            return Atom(record, serial, atom_name, resname, chain, resseq, icode, element, (x, y, z))
    except Exception:
        return None
    return None


def split_models(pdb_path: Path) -> List[List[str]]:
    models: List[List[str]] = []
    current: List[str] = []
    with open(pdb_path, "r", errors="replace") as fh:
        for line in fh:
            rec = line[:6].strip()
            if rec == "MODEL":
                if current:
                    models.append(current)
                    current = []
            elif rec in {"ATOM", "HETATM"}:
                current.append(line.rstrip("\n"))
            elif rec == "ENDMDL":
                if current:
                    models.append(current)
                    current = []
    if current:
        models.append(current)
    return models


def model_to_residues(lines: Sequence[str], chain_filter: Optional[str] = None) -> Dict[ResidueKey, Residue]:
    grouped: Dict[ResidueKey, List[Atom]] = defaultdict(list)
    for line in lines:
        atom = parse_atom_line(line)
        if atom is None:
            continue
        if chain_filter is not None and atom.chain != chain_filter:
            continue
        if atom.element.upper() == "H" or atom.atom_name.startswith("H"):
            continue
        grouped[atom.key].append(atom)

    residues: Dict[ResidueKey, Residue] = {}
    for key, atoms in grouped.items():
        if not atoms:
            continue
        resname = atoms[0].resname
        aa = AA3_TO_1.get(resname)
        if aa is None:
            continue
        chain, resseq, icode = key
        residues[key] = Residue(key, chain, resseq, icode, resname, aa, atoms)
    return residues


def normalize_idr_ranges(details: Sequence[Sequence[int]]) -> List[Tuple[int, int]]:
    return sorted([(int(s), int(e)) for s, e in details], key=lambda x: (x[0], x[1]))


def residue_in_ranges(resseq: int, ranges: Sequence[Tuple[int, int]]) -> bool:
    return any(start <= resseq <= end for start, end in ranges)


def select_target_ranges(
    all_ranges: Sequence[Tuple[int, int]],
    args: argparse.Namespace,
    max_resseq: int,
    ) -> List[Tuple[int, int]]:
        all_ranges = list(all_ranges)
        if args.target_idrs:
            selected: List[Tuple[int, int]] = []
            for token in [t.strip() for t in args.target_idrs.split(",") if t.strip()]:
                m = re.fullmatch(r"IDR(\d+)", token, flags=re.I)
                if m:
                    idx = int(m.group(1)) - 1
                    if idx < 0 or idx >= len(all_ranges):
                        raise ValueError(f"Requested {token}, but only {len(all_ranges)} IDR ranges are present: {all_ranges}")
                    selected.append(all_ranges[idx])
                    continue
                m = re.fullmatch(r"(-?\d+)\s*-\s*(-?\d+)", token)
                if m:
                    s, e = int(m.group(1)), int(m.group(2))
                    selected.append((min(s, e), max(s, e)))
                    continue
                raise ValueError(f"Could not parse --target-idrs token: {token}")
            return selected

        if args.target_terminal == "N":
            return [r for r in all_ranges if r[0] == 1]
        if args.target_terminal == "C":
            # Use PDB max residue as fallback for full-length C-terminal boundary.
            return [r for r in all_ranges if r[1] == max_resseq]
        return all_ranges


def residue_center(res: Residue, sidechain_preferred: bool = True) -> Optional[np.ndarray]:
    atoms = res.atoms
    if sidechain_preferred:
        sc = [a for a in atoms if a.atom_name.strip() not in BACKBONE_ATOMS]
        if sc:
            atoms = sc
    if not atoms:
        return None
    return np.array([a.xyz for a in atoms], dtype=float).mean(axis=0)


def residue_charge(res: Residue, histidine_charge: float) -> float:
    if res.aa in POSITIVE:
        return 1.0
    if res.aa in NEGATIVE:
        return -1.0
    if res.aa == "H":
        return float(histidine_charge)
    return 0.0


def atom_arrays(residues: Sequence[Residue], *, sidechain_only: bool = False, aa_filter: Optional[Set[str]] = None) -> Tuple[np.ndarray, List[ResidueKey]]:
    coords: List[Tuple[float, float, float]] = []
    keys: List[ResidueKey] = []
    for res in residues:
        if aa_filter is not None and res.aa not in aa_filter:
            continue
        for atom in res.atoms:
            if sidechain_only and atom.atom_name.strip() in BACKBONE_ATOMS:
                continue
            coords.append(atom.xyz)
            keys.append(res.key)
    if not coords:
        return np.zeros((0, 3), dtype=float), []
    return np.array(coords, dtype=float), keys


def contact_pairs_from_atoms(
    idr_residues: Sequence[Residue],
    fd_residues: Sequence[Residue],
    cutoff: float,
    *,
    sidechain_only: bool = False,
    aa_filter: Optional[Set[str]] = None,
    ) -> Tuple[Set[ResiduePair], int]:
        idr_xyz, idr_keys = atom_arrays(idr_residues, sidechain_only=sidechain_only, aa_filter=aa_filter)
        fd_xyz, fd_keys = atom_arrays(fd_residues, sidechain_only=sidechain_only, aa_filter=aa_filter)
        if len(idr_xyz) == 0 or len(fd_xyz) == 0:
            return set(), 0
        tree = cKDTree(fd_xyz)
        pair_set: Set[ResiduePair] = set()
        atom_pair_count = 0
        hits = tree.query_ball_point(idr_xyz, r=cutoff)
        for i, js in enumerate(hits):
            if not js:
                continue
            ikey = idr_keys[i]
            for j in js:
                pair_set.add((ikey, fd_keys[j]))
                atom_pair_count += 1
        return pair_set, atom_pair_count




def is_backbone_atom(atom: Atom) -> bool:
    return atom.atom_name.upper() in BACKBONE_ATOMS


def is_hydrogen_atom(atom: Atom) -> bool:
    name = atom.atom_name.upper().strip()
    elem = (atom.element or "").upper().strip()
    return elem == "H" or name.startswith("H")


def is_backbone_heavy_atom_name(name: str) -> bool:
    return name.upper().strip() in BACKBONE_ATOMS


def is_hbond_donor_atom(atom: Atom) -> bool:
    """Approximate heavy-atom H-bond donor classifier.

    Donors are N/O/S heavy atoms that can plausibly carry a proton. Proline
    backbone N is excluded. This donor list is intentionally permissive because
    PDB hydrogen naming/protonation can vary after model post-processing.
    """
    name = atom.atom_name.upper().strip()
    elem = (atom.element or "").upper().strip()
    if is_hydrogen_atom(atom):
        return False
    if atom.resname == "PRO" and name == "N":
        return False
    if elem in {"N", "O", "S"}:
        return True
    return name.startswith(("N", "O", "S"))


def is_hbond_acceptor_atom(atom: Atom) -> bool:
    """Approximate heavy-atom H-bond acceptor classifier.

    Backbone amide N is excluded as an acceptor. O and S atoms are acceptors.
    Some neutral side-chain nitrogens in His/Asn/Gln are included permissively.
    Lys/Arg cationic nitrogens are not treated as acceptors.
    """
    name = atom.atom_name.upper().strip()
    elem = (atom.element or "").upper().strip()
    if is_hydrogen_atom(atom):
        return False
    if name == "N":
        return False
    if elem in {"O", "S"}:
        return True
    if elem == "N" and atom.resname in {"HIS", "HID", "HIE", "ASN", "GLN"}:
        return True
    if not elem:
        if name.startswith(("O", "S")):
            return True
        if name.startswith("N") and atom.resname in {"HIS", "HID", "HIE", "ASN", "GLN"}:
            return True
    return False


def donor_hydrogens_for_atom(res: Residue, donor: Atom) -> List[Atom]:
    """Find explicit hydrogens likely attached to donor by intra-residue distance.

    This avoids relying on PDB hydrogen names/bond tables. N/O-H distances are
    usually ~1.0 Å; S-H is longer, so use a slightly larger fallback cutoff.
    """
    dxyz = np.asarray(donor.xyz, dtype=float)
    elem = (donor.element or "").upper().strip()
    cutoff = 1.45 if elem == "S" or donor.atom_name.upper().startswith("S") else 1.25
    hs = []
    for atom in res.atoms:
        if not is_hydrogen_atom(atom):
            continue
        dist = float(np.linalg.norm(np.asarray(atom.xyz, dtype=float) - dxyz))
        if dist <= cutoff:
            hs.append(atom)
    return hs


def hbond_atom_records(
    residues: Sequence[Residue],
    mode: str,
    ) -> Tuple[List[Tuple[ResidueKey, Atom, List[Atom], bool]], List[Tuple[ResidueKey, Atom, bool]]]:
        donors: List[Tuple[ResidueKey, Atom, List[Atom], bool]] = []
        acceptors: List[Tuple[ResidueKey, Atom, bool]] = []
        for res in residues:
            for atom in res.atoms:
                atom_is_bb = is_backbone_atom(atom)
                if mode == "sidechain_only" and atom_is_bb:
                    continue
                if is_hbond_donor_atom(atom):
                    donors.append((res.key, atom, donor_hydrogens_for_atom(res, atom), atom_is_bb))
                if is_hbond_acceptor_atom(atom):
                    acceptors.append((res.key, atom, atom_is_bb))
        return donors, acceptors


def dha_angle_degrees(donor_xyz: np.ndarray, hydrogen_xyz: np.ndarray, acceptor_xyz: np.ndarray) -> float:
    """Return D-H-A angle in degrees."""
    v1 = donor_xyz - hydrogen_xyz
    v2 = acceptor_xyz - hydrogen_xyz
    n1 = float(np.linalg.norm(v1))
    n2 = float(np.linalg.norm(v2))
    if n1 < 1e-8 or n2 < 1e-8:
        return 0.0
    cosang = float(np.dot(v1, v2) / (n1 * n2))
    cosang = max(-1.0, min(1.0, cosang))
    return float(np.degrees(np.arccos(cosang)))


def hbond_atom_pair_passes(
    donor: Atom,
    donor_hs: List[Atom],
    acceptor: Atom,
    *,
    da_cutoff: float,
    ha_cutoff: float,
    angle_cutoff: float,
    geometry: str,
    ) -> bool:
        d = np.asarray(donor.xyz, dtype=float)
        a = np.asarray(acceptor.xyz, dtype=float)
        da = float(np.linalg.norm(d - a))
        if da > da_cutoff:
            return False

        if geometry == "heavy_only":
            return True

        if donor_hs:
            for h_atom in donor_hs:
                h = np.asarray(h_atom.xyz, dtype=float)
                ha = float(np.linalg.norm(h - a))
                if ha > ha_cutoff:
                    continue
                angle = dha_angle_degrees(d, h, a)
                if angle >= angle_cutoff:
                    return True
            return False

        # Hydrogen-free PDB fallback. This keeps compatibility with ensembles that
        # lack explicit hydrogens but makes the behavior explicit in the output args.
        return geometry == "angle_if_hydrogens"


def hbond_like_pairs(
    idr_residues: Sequence[Residue],
    fd_residues: Sequence[Residue],
    cutoff: float,
    mode: str = "no_backbone_backbone",
    geometry: str = "angle_if_hydrogens",
    h_a_cutoff: float = 2.5,
    angle_cutoff: float = 120.0,
    ) -> Tuple[Set[ResiduePair], int]:
        """Count approximate hydrogen-bond residue pairs.

        A residue pair is counted once if any donor/acceptor atom pair between the
        two residues satisfies the requested H-bond rule. ``atom_pair_count`` reports
        the number of donor/acceptor atom pairs and can be larger than the residue
        pair count.
        """
        idr_donors, idr_acceptors = hbond_atom_records(idr_residues, mode)
        fd_donors, fd_acceptors = hbond_atom_records(fd_residues, mode)

        pair_set: Set[ResiduePair] = set()
        atom_pair_count = 0

        def add_direction(donors, acceptors, reverse: bool = False) -> None:
            nonlocal atom_pair_count
            for d_key, donor, donor_hs, donor_bb in donors:
                for a_key, acceptor, acceptor_bb in acceptors:
                    if mode == "no_backbone_backbone" and bool(donor_bb) and bool(acceptor_bb):
                        continue
                    if not hbond_atom_pair_passes(
                        donor,
                        donor_hs,
                        acceptor,
                        da_cutoff=cutoff,
                        ha_cutoff=h_a_cutoff,
                        angle_cutoff=angle_cutoff,
                        geometry=geometry,
                    ):
                        continue
                    atom_pair_count += 1
                    if reverse:
                        pair_set.add((a_key, d_key))  # acceptor is IDR, donor is FD
                    else:
                        pair_set.add((d_key, a_key))  # donor is IDR, acceptor is FD

        add_direction(idr_donors, fd_acceptors, reverse=False)
        add_direction(fd_donors, idr_acceptors, reverse=True)
        return pair_set, atom_pair_count


def center_dict(residues: Sequence[Residue]) -> Dict[ResidueKey, np.ndarray]:
    out: Dict[ResidueKey, np.ndarray] = {}
    for res in residues:
        c = residue_center(res, sidechain_preferred=True)
        if c is not None:
            out[res.key] = c
    return out


def pair_centers_by_cutoff(
    left: Sequence[Residue],
    right: Sequence[Residue],
    cutoff: float,
    *,
    left_filter: Optional[Set[str]] = None,
    right_filter: Optional[Set[str]] = None,
    ) -> List[Tuple[Residue, Residue, float]]:
        l_res = [r for r in left if left_filter is None or r.aa in left_filter]
        r_res = [r for r in right if right_filter is None or r.aa in right_filter]
        l_centers: List[np.ndarray] = []
        r_centers: List[np.ndarray] = []
        l_keep: List[Residue] = []
        r_keep: List[Residue] = []
        for r in l_res:
            c = residue_center(r, sidechain_preferred=True)
            if c is not None:
                l_keep.append(r)
                l_centers.append(c)
        for r in r_res:
            c = residue_center(r, sidechain_preferred=True)
            if c is not None:
                r_keep.append(r)
                r_centers.append(c)
        if not l_centers or not r_centers:
            return []
        l_xyz = np.vstack(l_centers)
        r_xyz = np.vstack(r_centers)
        tree = cKDTree(r_xyz)
        out = []
        hits = tree.query_ball_point(l_xyz, r=cutoff)
        for i, js in enumerate(hits):
            if not js:
                continue
            for j in js:
                d = float(np.linalg.norm(l_xyz[i] - r_xyz[j]))
                out.append((l_keep[i], r_keep[j], d))
        return out


def atom_name_centroid(res: Residue, atom_names: Set[str]) -> Optional[np.ndarray]:
    """Return the centroid of a named atom set, ignoring absent atoms."""
    wanted = {name.upper().strip() for name in atom_names}
    atoms = [a for a in res.atoms if a.atom_name.upper().strip() in wanted]
    if not atoms:
        return None
    return np.array([a.xyz for a in atoms], dtype=float).mean(axis=0)


def aromatic_centroid(res: Residue) -> Optional[np.ndarray]:
    names = RING_ATOMS.get(res.aa)
    if not names:
        return None
    c = atom_name_centroid(res, names)
    if c is not None:
        return c
    # Fallback for non-standard aromatic atom naming: use non-backbone side-chain centroid.
    atoms = [a for a in res.atoms if a.atom_name.upper().strip() not in BACKBONE_ATOMS]
    if not atoms:
        return None
    return np.array([a.xyz for a in atoms], dtype=float).mean(axis=0)


def cation_center(res: Residue, histidine_charge: float) -> Optional[np.ndarray]:
    """Return a chemically specific cation center for cation-pi scoring.

    Residues counted as cation-pi donors:
      - Lys: terminal ammonium NZ
      - Arg: guanidinium group centroid (NE/CZ/NH1/NH2)
      - His: imidazole centroid only when histidine_charge makes it cationic

    A residue can still be counted in additional contact classes independently;
    e.g. Arg can be charge-charge, cation-pi, pi-pi, and H-bond competent.
    """
    if res.aa == "K":
        center = atom_name_centroid(res, CATION_CENTER_ATOMS["K"])
        return center if center is not None else residue_center(res, sidechain_preferred=True)
    if res.aa == "R":
        center = atom_name_centroid(res, CATION_CENTER_ATOMS["R"])
        return center if center is not None else residue_center(res, sidechain_preferred=True)
    if res.aa == "H" and histidine_charge > 0:
        center = atom_name_centroid(res, CATION_CENTER_ATOMS["H"])
        return center if center is not None else residue_center(res, sidechain_preferred=True)
    return None


def pi_system_center(res: Residue) -> Optional[np.ndarray]:
    """Return a centroid for side-chain pi systems used in pi-pi scoring.

    This intentionally includes Arg guanidinium and His imidazole in addition to
    Phe/Tyr/Trp aromatic rings. It does not make contact classes mutually
    exclusive: the same residue pair may be counted as pi-pi and as cation-pi,
    charge-charge, hydrophobic, and/or H-bond-like when each rule is satisfied.
    """
    atom_names = PI_SYSTEM_CENTER_ATOMS.get(res.aa)
    if not atom_names:
        return None
    center = atom_name_centroid(res, atom_names)
    return center if center is not None else residue_center(res, sidechain_preferred=True)


def special_center_pairs(
    left: Sequence[Residue],
    right: Sequence[Residue],
    cutoff: float,
    *,
    left_kind: str,
    right_kind: str,
    histidine_charge: float,
    ) -> Set[ResiduePair]:
        def get_center(res: Residue, kind: str) -> Optional[np.ndarray]:
            if kind == "cation":
                if residue_charge(res, histidine_charge) <= 0:
                    return None
                return cation_center(res, histidine_charge)
            if kind == "aromatic":
                if res.aa not in AROMATIC:
                    return None
                return aromatic_centroid(res)
            if kind == "pi_system":
                if res.aa not in PI_SYSTEM:
                    return None
                return pi_system_center(res)
            raise ValueError(kind)

        l_centers: List[np.ndarray] = []
        r_centers: List[np.ndarray] = []
        l_res: List[Residue] = []
        r_res: List[Residue] = []
        for r in left:
            c = get_center(r, left_kind)
            if c is not None:
                l_res.append(r)
                l_centers.append(c)
        for r in right:
            c = get_center(r, right_kind)
            if c is not None:
                r_res.append(r)
                r_centers.append(c)
        if not l_centers or not r_centers:
            return set()
        l_xyz = np.vstack(l_centers)
        r_xyz = np.vstack(r_centers)
        tree = cKDTree(r_xyz)
        pairs: Set[ResiduePair] = set()
        hits = tree.query_ball_point(l_xyz, r=cutoff)
        for i, js in enumerate(hits):
            for j in js:
                pairs.add((l_res[i].key, r_res[j].key))
        return pairs


def filter_pipi_pairs_with_pi_anchor(
    pairs: Set[ResiduePair],
    residues_by_key: Dict[ResidueKey, Residue],
    ) -> Set[ResiduePair]:
        """Keep pi-pi pairs that include at least one aromatic/imidazole partner.

        This allows Arg guanidinium--aromatic/His and His--aromatic/His contacts,
        but avoids assigning a favorable pi-pi term to Arg--Arg contacts, which are
        better represented by the charge terms.
        """
        kept: Set[ResiduePair] = set()
        for ik, fk in pairs:
            iaa = residues_by_key.get(ik).aa if residues_by_key.get(ik) is not None else "X"
            faa = residues_by_key.get(fk).aa if residues_by_key.get(fk) is not None else "X"
            if iaa in PI_STACK_ANCHOR or faa in PI_STACK_ANCHOR:
                kept.add((ik, fk))
        return kept


def _contains_residue(resseq: int, ranges: Sequence[Tuple[int, int]]) -> Optional[Tuple[int, int]]:
    for start, end in ranges:
        if int(start) <= int(resseq) <= int(end):
            return int(start), int(end)
    return None


def idr_distance_from_selected_fd_boundary(
    resseq: int,
    target_ranges: Sequence[Tuple[int, int]],
    max_resseq: int,
    ) -> Optional[int]:
        """Distance, in sequence residues, from an IDR residue to its selected FD boundary.

        The boundary-adjacent IDR residue has distance 0. For terminal IDRs, only the
        boundary connected to the folded domain is used. For internal IDRs, the nearer
        of the two IDR:FD boundaries is used.
        """
        hit = _contains_residue(resseq, target_ranges)
        if hit is None:
            return None
        start, end = hit
        boundary_positions: List[int] = []
        if start > 1:
            boundary_positions.append(start)
        if end < max_resseq:
            boundary_positions.append(end)
        if not boundary_positions:
            boundary_positions = [start, end]
        return int(min(abs(int(resseq) - b) for b in boundary_positions))


def fd_distance_from_selected_idr_boundary(
    resseq: int,
    target_ranges: Sequence[Tuple[int, int]],
    ) -> Optional[int]:
        """Distance, in sequence residues, from an FD residue to the nearest selected IDR boundary.

        The FD residue immediately adjacent to a selected IDR has distance 0. This is
        a sequence-local anchor diagnostic, not a 3D distance.
        """
        distances: List[int] = []
        for start, end in target_ranges:
            start = int(start)
            end = int(end)
            if int(resseq) < start:
                distances.append(start - 1 - int(resseq))
            elif int(resseq) > end:
                distances.append(int(resseq) - (end + 1))
        if not distances:
            return None
        return int(min(max(0, d) for d in distances))


def boundary_distance_summary(prefix: str, pairs: Set[ResiduePair], target_ranges: Sequence[Tuple[int, int]], max_resseq: int) -> Dict[str, float]:
    """Return compact per-model contact-location diagnostics for one pair set."""
    idr_dists: List[int] = []
    fd_dists: List[int] = []
    pair_min_dists: List[int] = []
    for ik, fk in pairs:
        idr_d = idr_distance_from_selected_fd_boundary(ik[1], target_ranges, max_resseq)
        fd_d = fd_distance_from_selected_idr_boundary(fk[1], target_ranges)
        if idr_d is not None:
            idr_dists.append(idr_d)
        if fd_d is not None:
            fd_dists.append(fd_d)
        if idr_d is not None and fd_d is not None:
            pair_min_dists.append(min(idr_d, fd_d))
    def frac_gt(vals: List[int], threshold: int) -> float:
        return float(np.mean([v > threshold for v in vals])) if vals else float("nan")
    def mean(vals: List[int]) -> float:
        return float(np.mean(vals)) if vals else float("nan")
    def median(vals: List[int]) -> float:
        return float(np.median(vals)) if vals else float("nan")
    out: Dict[str, float] = {
        f"n_{prefix}_contact_pairs_for_boundary_diagnostic": int(len(pairs)),
        f"mean_{prefix}_idr_boundary_distance": mean(idr_dists),
        f"median_{prefix}_idr_boundary_distance": median(idr_dists),
        f"frac_{prefix}_idr_distance_gt5": frac_gt(idr_dists, 5),
        f"frac_{prefix}_idr_distance_gt10": frac_gt(idr_dists, 10),
        f"mean_{prefix}_fd_boundary_distance": mean(fd_dists),
        f"median_{prefix}_fd_boundary_distance": median(fd_dists),
        f"frac_{prefix}_fd_distance_gt5": frac_gt(fd_dists, 5),
        f"frac_{prefix}_fd_distance_gt10": frac_gt(fd_dists, 10),
        f"mean_{prefix}_pair_min_boundary_distance": mean(pair_min_dists),
        f"median_{prefix}_pair_min_boundary_distance": median(pair_min_dists),
        f"frac_{prefix}_pair_min_distance_gt5": frac_gt(pair_min_dists, 5),
        f"frac_{prefix}_pair_min_distance_gt10": frac_gt(pair_min_dists, 10),
    }
    return out


def contact_location_rows_for_model(
    *,
    pair_sets: Dict[str, Set[ResiduePair]],
    residues_by_key: Dict[ResidueKey, Residue],
    protein_id: str,
    ensemble_name: str,
    variant_name: str,
    model_index: int,
    target_ranges: Sequence[Tuple[int, int]],
    max_resseq: int,
    ) -> List[dict]:
        """Expand contact pair sets into a residue-level contact-localization table."""
        target_ranges_text = ";".join(f"{s}-{e}" for s, e in target_ranges)
        rows: List[dict] = []
        for contact_type, pairs in pair_sets.items():
            for ik, fk in sorted(pairs, key=lambda p: (p[0][0], p[0][1], p[1][0], p[1][1])):
                ires = residues_by_key.get(ik)
                fres = residues_by_key.get(fk)
                idr_d = idr_distance_from_selected_fd_boundary(ik[1], target_ranges, max_resseq)
                fd_d = fd_distance_from_selected_idr_boundary(fk[1], target_ranges)
                pair_min = min(idr_d, fd_d) if idr_d is not None and fd_d is not None else None
                rows.append({
                    "ensemble_name": ensemble_name,
                    "protein_id": protein_id,
                    "variant_name": variant_name,
                    "model_index": model_index,
                    "target_ranges": target_ranges_text,
                    "contact_type": contact_type,
                    "idr_chain": ik[0],
                    "idr_resseq": ik[1],
                    "idr_icode": ik[2],
                    "idr_aa": ires.aa if ires is not None else "X",
                    "fd_chain": fk[0],
                    "fd_resseq": fk[1],
                    "fd_icode": fk[2],
                    "fd_aa": fres.aa if fres is not None else "X",
                    "idr_boundary_distance": idr_d,
                    "fd_boundary_distance": fd_d,
                    "pair_min_boundary_distance": pair_min,
                    "idr_distance_gt5": int(idr_d is not None and idr_d > 5),
                    "idr_distance_gt10": int(idr_d is not None and idr_d > 10),
                    "fd_distance_gt5": int(fd_d is not None and fd_d > 5),
                    "fd_distance_gt10": int(fd_d is not None and fd_d > 10),
                    "pair_min_distance_gt5": int(pair_min is not None and pair_min > 5),
                    "pair_min_distance_gt10": int(pair_min is not None and pair_min > 10),
                })
        return rows

def score_model(
    model_lines: Sequence[str],
    *,
    model_index: int,
    protein_id: str,
    ensemble_name: str,
    variant_name: str,
    all_idr_ranges: Sequence[Tuple[int, int]],
    target_ranges: Sequence[Tuple[int, int]],
    args: argparse.Namespace,
    ) -> Tuple[Optional[dict], List[str], List[dict]]:
        warnings: List[str] = []
        residues_by_key = model_to_residues(model_lines, chain_filter=args.chain)
        if not residues_by_key:
            return None, ["no protein residues parsed"], []

        residues = sorted(residues_by_key.values(), key=lambda r: (r.chain, r.resseq, r.icode))
        max_resseq = max([r.resseq for r in residues], default=max(e for _, e in all_idr_ranges))
        target_idr_res_all = [r for r in residues if residue_in_ranges(r.resseq, target_ranges)]
        anchor_cutoff = max(0, int(getattr(args, "anchor_cutoff", 5)))
        target_idr_res = [
            r for r in target_idr_res_all
            if (idr_distance_from_selected_fd_boundary(r.resseq, target_ranges, max_resseq) is not None
                and idr_distance_from_selected_fd_boundary(r.resseq, target_ranges, max_resseq) >= anchor_cutoff)
        ]
        folded_res = [r for r in residues if not residue_in_ranges(r.resseq, all_idr_ranges)]
        other_idr_res = [r for r in residues if residue_in_ranges(r.resseq, all_idr_ranges) and not residue_in_ranges(r.resseq, target_ranges)]

        if not target_idr_res_all:
            return None, [f"no target IDR residues found for ranges={target_ranges}"], []
        if not target_idr_res:
            return None, [f"no target IDR residues remained after applying anchor_cutoff={anchor_cutoff}"], []
        if not folded_res:
            return None, ["no folded-domain residues found after excluding all IDR ranges"], []

        heavy_pairs, heavy_atom_contacts = contact_pairs_from_atoms(
            target_idr_res, folded_res, args.heavy_cutoff, sidechain_only=False, aa_filter=None
        )
        clash_pairs, clash_atom_contacts = contact_pairs_from_atoms(
            target_idr_res, folded_res, args.clash_cutoff, sidechain_only=False, aa_filter=None
        )
        hydro_pairs, hydro_atom_contacts = contact_pairs_from_atoms(
            target_idr_res, folded_res, args.hydrophobic_cutoff, sidechain_only=True, aa_filter=HYDROPHOBIC
        )

        # Charge contacts and screened electrostatic contact score.
        charged_pairs_contact: Set[ResiduePair] = set()
        opposite_pairs: Set[ResiduePair] = set()
        like_pairs: Set[ResiduePair] = set()
        screened_charge_score = 0.0
        screened_charge_favorable_abs = 0.0
        screened_charge_unfavorable = 0.0

        charged_idr = [r for r in target_idr_res if abs(residue_charge(r, args.histidine_charge)) > 1e-8]
        charged_fd = [r for r in folded_res if abs(residue_charge(r, args.histidine_charge)) > 1e-8]
        for ri, rj, dist in pair_centers_by_cutoff(charged_idr, charged_fd, args.electro_cutoff):
            qi = residue_charge(ri, args.histidine_charge)
            qj = residue_charge(rj, args.histidine_charge)
            prod = qi * qj
            if abs(prod) < 1e-8:
                continue
            contribution = prod * math.exp(-dist / max(args.debye_length, 1e-6)) / max(dist, 2.0)
            screened_charge_score += contribution
            if contribution < 0:
                screened_charge_favorable_abs += -contribution
            else:
                screened_charge_unfavorable += contribution
            if dist <= args.charge_contact_cutoff:
                pair = (ri.key, rj.key)
                charged_pairs_contact.add(pair)
                if prod < 0:
                    opposite_pairs.add(pair)
                else:
                    like_pairs.add(pair)

        # Cation-pi in both orientations: IDR cation to FD aromatic and FD cation to IDR aromatic.
        cationpi_pairs = set()
        cationpi_pairs |= special_center_pairs(
            target_idr_res, folded_res, args.cationpi_cutoff,
            left_kind="cation", right_kind="aromatic", histidine_charge=args.histidine_charge,
        )
        # Reverse orientation needs pair orientation as IDR,FD.
        reverse_cpi = special_center_pairs(
            folded_res, target_idr_res, args.cationpi_cutoff,
            left_kind="cation", right_kind="aromatic", histidine_charge=args.histidine_charge,
        )
        for fd_key, idr_key in reverse_cpi:
            cationpi_pairs.add((idr_key, fd_key))

        # Pi-pi / pi-system contacts. This includes Arg guanidinium and His imidazole
        # pi systems in addition to Phe/Tyr/Trp aromatic rings. At least one partner
        # must be aromatic/imidazole; Arg-Arg proximity is left to charge terms.
        pipi_raw_pairs = special_center_pairs(
            target_idr_res, folded_res, args.pipi_cutoff,
            left_kind="pi_system", right_kind="pi_system", histidine_charge=args.histidine_charge,
        )
        pipi_pairs = filter_pipi_pairs_with_pi_anchor(pipi_raw_pairs, residues_by_key)

        # Arg-Arg guanidinium/π-stacking-like contacts. These are kept separate
        # from the aromatic/imidazole pi-pi term above so Arg-Arg contacts remain
        # explicitly visible and tunable while still being allowed to overlap with
        # like-charge/screened-charge terms.
        argarg_pairs = special_center_pairs(
            [r for r in target_idr_res if r.aa == "R"],
            [r for r in folded_res if r.aa == "R"],
            args.argarg_cutoff,
            left_kind="pi_system", right_kind="pi_system", histidine_charge=args.histidine_charge,
        )

        # Hydrogen-bond-like contacts, counted as donor/acceptor heavy-atom pairs.
        hbond_pairs, hbond_atom_contacts = hbond_like_pairs(
            target_idr_res,
            folded_res,
            args.hbond_cutoff,
            mode=args.hbond_mode,
            geometry=args.hbond_geometry,
            h_a_cutoff=args.hbond_h_a_cutoff,
            angle_cutoff=args.hbond_angle_cutoff,
        )

        scored_any_pairs = set().union(
            opposite_pairs, like_pairs, hydro_pairs, cationpi_pairs, pipi_pairs, argarg_pairs, hbond_pairs
        )
        contact_location_pair_sets = {
            "scored_any": scored_any_pairs,
            "heavy": heavy_pairs,
            "opposite_charge": opposite_pairs,
            "like_charge": like_pairs,
            "hydrophobic": hydro_pairs,
            "cationpi": cationpi_pairs,
            "pipi": pipi_pairs,
            "argarg": argarg_pairs,
            "hbond": hbond_pairs,
            "clash": clash_pairs,
        }
        location_rows = contact_location_rows_for_model(
            pair_sets=contact_location_pair_sets,
            residues_by_key=residues_by_key,
            protein_id=protein_id,
            ensemble_name=ensemble_name,
            variant_name=variant_name,
            model_index=model_index,
            target_ranges=target_ranges,
            max_resseq=max_resseq,
        )

        n_opp = len(opposite_pairs)
        n_like = len(like_pairs)
        n_hydro = len(hydro_pairs)
        n_cationpi = len(cationpi_pairs)
        n_pipi = len(pipi_pairs)
        n_argarg = len(argarg_pairs)
        n_hbond = len(hbond_pairs)
        n_clash = len(clash_pairs)

        # Decomposed contact score. Higher is better/more favorable.
        # Positive terms reward favorable contacts; negative terms penalize like-charge,
        # unfavorable screened-charge proximity, and optional clashes. This is a
        # heuristic score, not a thermodynamic quantity.
        score_charge_contacts = args.w_opposite_charge * n_opp - args.w_like_charge * n_like
        score_screened_charge = args.w_screened_charge * (
            screened_charge_favorable_abs - screened_charge_unfavorable
        )
        score_hydrophobic = args.w_hydrophobic * n_hydro
        score_cationpi = args.w_cationpi * n_cationpi
        score_pipi = args.w_pipi * n_pipi
        score_argarg = args.w_argarg * n_argarg
        score_hbond = args.w_hbond * n_hbond
        score_clash_penalty = -args.w_clash * n_clash
        total_score_raw = (
            score_charge_contacts
            + score_screened_charge
            + score_hydrophobic
            + score_cationpi
            + score_pipi
            + score_argarg
            + score_hbond
            + score_clash_penalty
        )

        favorable_contact_score = (
            args.w_opposite_charge * n_opp
            + args.w_hydrophobic * n_hydro
            + args.w_cationpi * n_cationpi
            + args.w_pipi * n_pipi
            + args.w_argarg * n_argarg
            + args.w_hbond * n_hbond
            + args.w_screened_charge * screened_charge_favorable_abs
        )
        unfavorable_contact_score = (
            args.w_like_charge * n_like
            + args.w_screened_charge * screened_charge_unfavorable
            + args.w_clash * n_clash
        )

        equivalent_weight_contact_score = (
            n_opp
            - n_like
            - screened_charge_score
            + n_hydro
            + n_cationpi
            + n_pipi
            + n_argarg
            + n_hbond
            - n_clash if args.w_clash != 0 else
            n_opp - n_like - screened_charge_score + n_hydro + n_cationpi + n_pipi + n_argarg + n_hbond
        )

        target_idr_seq = "".join(r.aa for r in sorted(target_idr_res, key=lambda r: (r.chain, r.resseq, r.icode)))
        fd_seq_len = len(folded_res)

        row = {
            "ensemble_name": ensemble_name,
            "protein_id": protein_id,
            "variant_name": variant_name,
            "model_index": model_index,
            "target_ranges": ";".join(f"{s}-{e}" for s, e in target_ranges),
            "all_idr_ranges": ";".join(f"{s}-{e}" for s, e in all_idr_ranges),
            "n_target_idr_residues": len(target_idr_res),
            "n_target_idr_residues_total": len(target_idr_res_all),
            "n_target_idr_residues_scored_after_anchor_cutoff": len(target_idr_res),
            "anchor_cutoff_residues": anchor_cutoff,
            "n_folded_domain_residues": fd_seq_len,
            "n_other_idr_residues_excluded": len(other_idr_res),
            "target_idr_ncpr": sum(residue_charge(r, args.histidine_charge) for r in target_idr_res) / max(len(target_idr_res), 1),
            "target_idr_fcr": sum(1 for r in target_idr_res if abs(residue_charge(r, args.histidine_charge)) > 1e-8) / max(len(target_idr_res), 1),
            "target_idr_hydrophobic_frac": sum(1 for r in target_idr_res if r.aa in HYDROPHOBIC) / max(len(target_idr_res), 1),
            "target_idr_aromatic_frac": sum(1 for r in target_idr_res if r.aa in AROMATIC) / max(len(target_idr_res), 1),
            "n_heavy_residue_pairs": len(heavy_pairs),
            "n_heavy_atom_contacts": heavy_atom_contacts,
            "n_opposite_charge_pairs": n_opp,
            "n_like_charge_pairs": n_like,
            "n_charged_contact_pairs": len(charged_pairs_contact),
            "n_hydrophobic_pairs": n_hydro,
            "n_hydrophobic_atom_contacts": hydro_atom_contacts,
            "n_cationpi_pairs": n_cationpi,
            "n_pipi_pairs": n_pipi,
            "n_argarg_pairs": n_argarg,
            "n_hbond_pairs": n_hbond,
            "n_hbond_atom_contacts": hbond_atom_contacts,
            "n_clash_residue_pairs": n_clash,
            "n_clash_atom_contacts": clash_atom_contacts,
            "screened_charge_signed_score_raw": screened_charge_score,
            "screened_charge_favorable_abs_raw": screened_charge_favorable_abs,
            "screened_charge_unfavorable_raw": screened_charge_unfavorable,
            "score_charge_contacts": score_charge_contacts,
            "score_screened_charge": score_screened_charge,
            "score_hydrophobic": score_hydrophobic,
            "score_cationpi": score_cationpi,
            "score_pipi": score_pipi,
            "score_argarg": score_argarg,
            "score_hbond": score_hbond,
            "score_clash_penalty": score_clash_penalty,
            "favorable_contact_score": favorable_contact_score,
            "unfavorable_contact_score": unfavorable_contact_score,
            "total_score_raw": total_score_raw,
            "equivalent_weight_contact_score": equivalent_weight_contact_score,
            "sequence_preview": target_idr_seq[:30] + ("..." if len(target_idr_seq) > 30 else ""),
        }
        row.update(boundary_distance_summary("scored_any", scored_any_pairs, target_ranges, max_resseq))
        row.update(boundary_distance_summary("heavy", heavy_pairs, target_ranges, max_resseq))
        return row, warnings, location_rows


def clean_pdb_lines_from_model(lines: Sequence[str]) -> List[str]:
    out: List[str] = []
    serial_new = 1
    for line in lines:
        atom = parse_atom_line(line)
        if atom is None:
            continue
        x, y, z = atom.xyz
        # PDB atom-name alignment is approximate but readable/valid enough for extraction.
        name = atom.atom_name
        if len(name) < 4 and not name[0].isdigit():
            name_field = f" {name:<3s}"
        else:
            name_field = f"{name:<4s}"
        out.append(
            f"{atom.record:<6s}{serial_new:5d} {name_field}{atom.resname:>3s} {atom.chain:1s}"
            f"{atom.resseq:4d}{atom.icode:1s}   {x:8.3f}{y:8.3f}{z:8.3f}"
            f"  1.00  0.00          {atom.element:>2s}\n"
        )
        serial_new += 1
    return out


def process_one_pdb(payload: Tuple[str, dict, dict]) -> dict:
    pdb_path_str, master, opt = payload
    # Recreate a light args-like object from opt for multiprocessing portability.
    class Opt:
        pass
    args = Opt()
    for k, v in opt.items():
        setattr(args, k, v)

    pdb_path = Path(pdb_path_str)
    protein_id = infer_protein_id(pdb_path, list(master.keys()))
    if protein_id is None:
        return {"pdb": str(pdb_path), "protein_id": None, "rows": [], "location_rows": [], "warnings": ["could not infer protein id from filename"], "models": []}
    if protein_id not in master or "idrs" not in master[protein_id]:
        return {"pdb": str(pdb_path), "protein_id": protein_id, "rows": [], "location_rows": [], "warnings": ["protein id missing or has no idrs in master JSON"], "models": []}

    all_ranges = normalize_idr_ranges(master[protein_id]["idrs"])
    models = split_models(pdb_path)
    if not models:
        return {"pdb": str(pdb_path), "protein_id": protein_id, "rows": [], "location_rows": [], "warnings": ["no models/ATOM records found"], "models": []}

    stride = max(1, int(args.model_stride))
    selected_models = [(i + 1, m) for i, m in enumerate(models) if i % stride == 0]
    if args.max_models is not None:
        selected_models = selected_models[: int(args.max_models)]

    # Use the first parseable model to determine max residue for C-terminal range resolution.
    first_residues = model_to_residues(selected_models[0][1], chain_filter=args.chain)
    max_resseq = max([r.resseq for r in first_residues.values()], default=max(e for _, e in all_ranges))
    try:
        target_ranges = select_target_ranges(all_ranges, args, max_resseq)
    except Exception as exc:
        return {"pdb": str(pdb_path), "protein_id": protein_id, "rows": [], "location_rows": [], "warnings": [str(exc)], "models": []}
    if not target_ranges:
        return {"pdb": str(pdb_path), "protein_id": protein_id, "rows": [], "location_rows": [], "warnings": [f"no target IDR ranges selected from {all_ranges}"], "models": []}

    ensemble_name = pdb_path.stem
    variant_name = infer_variant_name(pdb_path, protein_id)
    rows: List[dict] = []
    location_rows: List[dict] = []
    warnings: List[str] = []
    kept_models_for_extract: Dict[int, List[str]] = {}
    for model_index, model_lines in selected_models:
        row, ws, loc_rows = score_model(
            model_lines,
            model_index=model_index,
            protein_id=protein_id,
            ensemble_name=ensemble_name,
            variant_name=variant_name,
            all_idr_ranges=all_ranges,
            target_ranges=target_ranges,
            args=args,
        )
        warnings.extend([f"model {model_index}: {w}" for w in ws])
        for lr in loc_rows:
            lr["pdb_file"] = str(pdb_path)
        location_rows.extend(loc_rows)
        if row is not None:
            row["pdb_file"] = str(pdb_path)
            rows.append(row)
            kept_models_for_extract[model_index] = list(model_lines)

    return {"pdb": str(pdb_path), "protein_id": protein_id, "rows": rows, "location_rows": location_rows, "warnings": warnings, "models": kept_models_for_extract}


def make_total_score_positive(df: pd.DataFrame, eps: float = 1e-6) -> pd.DataFrame:
    """Add a positive total_score column while preserving signed raw scores.

    total_score_raw is the direct heuristic sum (favorable terms minus
    penalties). total_score is shifted by one run-wide constant only when needed
    so every reported score is positive and rank order is unchanged.
    """
    if df.empty:
        return df
    out = df.copy()
    raw = out["total_score_raw"].astype(float)
    min_raw = float(raw.min())
    offset = (-min_raw + eps) if min_raw <= 0 else 0.0
    out["total_score_shift_offset"] = offset
    out["total_score"] = raw + offset
    return out


def add_weights(df: pd.DataFrame, beta: float, scale: str) -> pd.DataFrame:
    if df.empty:
        return df
    out_parts = []
    for ensemble_name, group in df.groupby("ensemble_name", sort=False):
        g = group.copy()
        score = g["total_score"].astype(float).to_numpy()
        if scale == "zscore":
            mu = float(np.mean(score))
            sd = float(np.std(score, ddof=0))
            if sd < 1e-12:
                score_scaled = np.zeros_like(score)
            else:
                score_scaled = (score - mu) / sd
        elif scale == "minmax":
            smin = float(np.min(score))
            smax = float(np.max(score))
            if abs(smax - smin) < 1e-12:
                score_scaled = np.zeros_like(score)
            else:
                score_scaled = (score - smin) / (smax - smin)
        else:
            score_scaled = score
        # Higher score is better. Shift for numerical stability.
        x = beta * score_scaled
        x = x - np.max(x)
        factors = np.exp(x)
        weights = factors / np.sum(factors) if np.sum(factors) > 0 else np.ones_like(factors) / len(factors)
        g["score_scaled_for_weighting"] = score_scaled
        g["relative_weight_factor"] = factors / np.max(factors) if np.max(factors) > 0 else factors
        g["normalized_weight"] = weights
        g["model_rank_by_score"] = g["total_score"].rank(method="first", ascending=False).astype(int)
        g = g.sort_values("model_rank_by_score")
        g["cumulative_weight_ranked"] = g["normalized_weight"].cumsum()
        out_parts.append(g)
    return pd.concat(out_parts, ignore_index=True)

def make_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if df.empty:
        return pd.DataFrame()
    for ensemble_name, g in df.groupby("ensemble_name", sort=False):
        g_rank = g.sort_values("model_rank_by_score")
        w = g["normalized_weight"].to_numpy(dtype=float)
        ess = 1.0 / np.sum(w ** 2) if len(w) and np.sum(w ** 2) > 0 else np.nan
        best = g_rank.iloc[0]
        top10_n = max(1, int(math.ceil(0.10 * len(g_rank))))
        top10 = g_rank.head(top10_n)
        rows.append({
            "ensemble_name": ensemble_name,
            "protein_id": best["protein_id"],
            "variant_name": best["variant_name"],
            "n_models_scored": len(g),
            "effective_sample_size": ess,
            "effective_sample_size_frac": ess / len(g) if len(g) else np.nan,
            "best_model_index": int(best["model_index"]),
            "best_total_score": float(best["total_score"]),
            "mean_total_score": float(g["total_score"].mean()),
            "std_total_score": float(g["total_score"].std(ddof=0)),
            "top10pct_mean_total_score": float(top10["total_score"].mean()),
            "lowest10pct_mean_total_score": float(g_rank.tail(top10_n)["total_score"].mean()),
            "mean_total_score_raw": float(g["total_score_raw"].mean()),
            "std_total_score_raw": float(g["total_score_raw"].std(ddof=0)),
            "mean_equivalent_weight_contact_score": float(g["equivalent_weight_contact_score"].mean()),
            "std_equivalent_weight_contact_score": float(g["equivalent_weight_contact_score"].std(ddof=0)),
            "mean_normalized_weight": float(g["normalized_weight"].mean()),
            "max_normalized_weight": float(g["normalized_weight"].max()),
            "mean_n_heavy_residue_pairs": float(g["n_heavy_residue_pairs"].mean()),
            "mean_n_opposite_charge_pairs": float(g["n_opposite_charge_pairs"].mean()),
            "mean_n_like_charge_pairs": float(g["n_like_charge_pairs"].mean()),
            "mean_n_hydrophobic_pairs": float(g["n_hydrophobic_pairs"].mean()),
            "mean_n_cationpi_pairs": float(g["n_cationpi_pairs"].mean()),
            "mean_n_pipi_pairs": float(g["n_pipi_pairs"].mean()),
            "mean_n_argarg_pairs": float(g["n_argarg_pairs"].mean()),
            "mean_n_hbond_pairs": float(g["n_hbond_pairs"].mean()),
            "mean_n_clash_residue_pairs": float(g["n_clash_residue_pairs"].mean()),
            "best_favorable_contact_score": float(best["favorable_contact_score"]),
            "best_unfavorable_contact_score": float(best["unfavorable_contact_score"]),
        })
    return pd.DataFrame(rows).sort_values(["protein_id", "variant_name", "ensemble_name"])


def write_model_pdb(outpath: Path, model_lines: Sequence[str], title: str) -> None:
    outpath.parent.mkdir(parents=True, exist_ok=True)
    clean_lines = clean_pdb_lines_from_model(model_lines)
    with open(outpath, "w") as handle:
        handle.write(f"REMARK {title}\n")
        handle.write("MODEL        1\n")
        handle.writelines(clean_lines)
        handle.write("ENDMDL\nEND\n")


def extract_ranked_models(
    df: pd.DataFrame,
    result_by_pdb: Dict[str, dict],
    outdir: Path,
    top_n: int,
    bottom_n: int,
    ) -> pd.DataFrame:
        rows = []
        if df.empty or (top_n <= 0 and bottom_n <= 0):
            return pd.DataFrame()
        extract_dir = outdir / "extracted_models"
        for ensemble_name, g in df.groupby("ensemble_name", sort=False):
            g_rank = g.sort_values("model_rank_by_score")
            selections = []
            if top_n > 0:
                selections.extend([("top", r) for _, r in g_rank.head(top_n).iterrows()])
            if bottom_n > 0:
                selections.extend([("bottom", r) for _, r in g_rank.tail(bottom_n).sort_values("model_rank_by_score", ascending=False).iterrows()])
            for kind, row in selections:
                pdb_file = str(row["pdb_file"])
                model_index = int(row["model_index"])
                res = result_by_pdb.get(pdb_file)
                if not res:
                    continue
                model_lines = res.get("models", {}).get(model_index)
                if model_lines is None:
                    continue
                rank = int(row["model_rank_by_score"])
                fname = f"{ensemble_name}_{kind}_rank{rank:03d}_model{model_index:03d}.pdb"
                outpath = extract_dir / ensemble_name / fname
                title = (
                    f"{ensemble_name} {kind} rank={rank} model={model_index} "
                    f"total_score={float(row['total_score']):.3f} weight={float(row['normalized_weight']):.6f}"
                )
                write_model_pdb(outpath, model_lines, title)
                rows.append({
                    "ensemble_name": ensemble_name,
                    "protein_id": row["protein_id"],
                    "variant_name": row["variant_name"],
                    "selection": kind,
                    "model_rank_by_score": rank,
                    "model_index": model_index,
                    "total_score": row["total_score"],
                    "normalized_weight": row["normalized_weight"],
                    "extracted_pdb": str(outpath),
                })
        return pd.DataFrame(rows)


READABLE_CONTACT_TYPES = [
    ("heavy", "Heavy residue pairs"),
    ("opposite_charge", "Opposite-charge pairs"),
    ("like_charge", "Like-charge pairs"),
    ("hydrophobic", "Hydrophobic pairs"),
    ("cationpi", "Cation-pi pairs"),
    ("pipi", "Pi-pi pairs"),
    ("argarg", "Arg-Arg pairs"),
    ("hbond", "H-bond-like pairs"),
    ("clash", "Clash residue pairs"),
]


def _safe_int(value) -> int:
    try:
        return int(value)
    except Exception:
        return int(float(value))


def _residue_label(chain, aa, resseq, icode) -> str:
    chain = str(chain) if pd.notna(chain) else ""
    aa = str(aa) if pd.notna(aa) else "X"
    icode = "" if pd.isna(icode) else str(icode)
    return f"{chain}:{aa}{_safe_int(resseq)}{icode}"


def _format_contact_pair(row: pd.Series) -> str:
    idr = _residue_label(row.get("idr_chain", ""), row.get("idr_aa", "X"), row.get("idr_resseq", 0), row.get("idr_icode", ""))
    fd = _residue_label(row.get("fd_chain", ""), row.get("fd_aa", "X"), row.get("fd_resseq", 0), row.get("fd_icode", ""))
    return f"{idr}–{fd}"


def _append_model_score_table(lines: List[str], title: str, rows: pd.DataFrame) -> None:
    lines.append(title)
    lines.append("| rank | model | total_score | raw_score | weight | fav_score | unfav_score | opp_charge | like_charge | hydrophobic | cation_pi | pi_pi | arg_arg | hbond | clashes |")
    lines.append("|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for _, r in rows.iterrows():
        lines.append(
            f"| {int(r['model_rank_by_score'])} | {int(r['model_index'])} | {r['total_score']:.3f} | "
            f"{r['total_score_raw']:.3f} | {r['normalized_weight']:.5f} | {r['favorable_contact_score']:.3f} | "
            f"{r['unfavorable_contact_score']:.3f} | {int(r['n_opposite_charge_pairs'])} | "
            f"{int(r['n_like_charge_pairs'])} | {int(r['n_hydrophobic_pairs'])} | "
            f"{int(r['n_cationpi_pairs'])} | {int(r['n_pipi_pairs'])} | {int(r['n_argarg_pairs'])} | "
            f"{int(r['n_hbond_pairs'])} | {int(r['n_clash_residue_pairs'])} |"
        )
    lines.append("")


def _append_contact_pair_details(
    lines: List[str],
    contact_location_df: Optional[pd.DataFrame],
    ensemble_name: str,
    highlighted_rows: pd.DataFrame,
    *,
    title: str,
    pair_limit: int,
    ) -> None:
        lines.append(title)
        if contact_location_df is None or contact_location_df.empty:
            lines.append("No contact-pair table was available for this run.\n")
            return
        work = contact_location_df[contact_location_df["ensemble_name"].astype(str) == str(ensemble_name)].copy()
        if work.empty:
            lines.append("No residue-pair contact rows were recorded for this ensemble.\n")
            return
        pair_limit = max(1, int(pair_limit))
        for _, model_row in highlighted_rows.iterrows():
            model_index = int(model_row["model_index"])
            rank = int(model_row["model_rank_by_score"])
            m = work[pd.to_numeric(work["model_index"], errors="coerce") == model_index].copy()
            lines.append(f"### Rank {rank}, model {model_index} — total_score {model_row['total_score']:.3f}")
            if m.empty:
                lines.append("No residue-pair contact rows were recorded for this model.\n")
                continue
            any_written = False
            for contact_type, label in READABLE_CONTACT_TYPES:
                c = m[m["contact_type"] == contact_type].copy()
                if c.empty:
                    continue
                # De-duplicate by residue pair within this contact type/model.
                c = c.drop_duplicates(subset=["idr_chain", "idr_resseq", "idr_icode", "fd_chain", "fd_resseq", "fd_icode"])
                c = c.sort_values(["idr_chain", "idr_resseq", "fd_chain", "fd_resseq"], kind="mergesort")
                pairs = [_format_contact_pair(row) for _, row in c.head(pair_limit).iterrows()]
                more = f"; +{len(c) - pair_limit} more" if len(c) > pair_limit else ""
                lines.append(f"- **{label} ({len(c)})**: " + "; ".join(pairs) + more)
                any_written = True
            if not any_written:
                lines.append("No scored residue-pair contacts for this model.")
            lines.append("")


def write_readable_summaries(
    df: pd.DataFrame,
    summary_df: pd.DataFrame,
    outdir: Path,
    contact_location_df: Optional[pd.DataFrame] = None,
    pair_limit: int = 30,
    ) -> None:
        if df.empty:
            return
        sdir = outdir / "readable_summaries"
        sdir.mkdir(parents=True, exist_ok=True)
        for ensemble_name, g in df.groupby("ensemble_name", sort=False):
            g_rank = g.sort_values("model_rank_by_score")
            best = g_rank.iloc[0]
            lowest10 = g_rank.tail(10).sort_values("total_score", ascending=True)
            highest10 = g_rank.head(10)
            highlighted_for_pairs = pd.concat([highest10, lowest10], ignore_index=True).drop_duplicates(
                subset=["ensemble_name", "model_index"], keep="first"
            )
            summ = summary_df[summary_df["ensemble_name"] == ensemble_name].iloc[0]
            lines: List[str] = []
            lines.append(f"# {ensemble_name}\n")
            lines.append(f"Protein: **{best['protein_id']}**  ")
            lines.append(f"Variant: **{best['variant_name']}**  ")
            lines.append(f"Target IDR range(s): **{best['target_ranges']}**  ")
            lines.append(f"Models scored: **{int(summ['n_models_scored'])}**  ")
            lines.append(f"Effective sample size: **{summ['effective_sample_size']:.2f}** ({summ['effective_sample_size_frac']:.3f} of models)  ")
            lines.append(f"Score offset applied to keep total_score positive: **{best['total_score_shift_offset']:.6g}**\n")
            lines.append("## Best model\n")
            lines.append(f"- Model index: **{int(best['model_index'])}**")
            lines.append(f"- Total score: **{best['total_score']:.3f}**")
            lines.append(f"- Raw total score before positive shift: **{best['total_score_raw']:.3f}**")
            lines.append(f"- Normalized weight: **{best['normalized_weight']:.5f}**")
            lines.append(f"- Favorable contact score: **{best['favorable_contact_score']:.3f}**")
            lines.append(f"- Unfavorable contact score: **{best['unfavorable_contact_score']:.3f}**")
            lines.append(f"- Heavy residue pairs: **{int(best['n_heavy_residue_pairs'])}**")
            lines.append(f"- Opposite-charge pairs: **{int(best['n_opposite_charge_pairs'])}**")
            lines.append(f"- Like-charge pairs: **{int(best['n_like_charge_pairs'])}**")
            lines.append(f"- Hydrophobic pairs: **{int(best['n_hydrophobic_pairs'])}**")
            lines.append(f"- Cation-pi pairs: **{int(best['n_cationpi_pairs'])}**")
            lines.append(f"- Pi-pi pairs: **{int(best['n_pipi_pairs'])}**")
            lines.append(f"- Arg-Arg pairs: **{int(best['n_argarg_pairs'])}**")
            lines.append(f"- H-bond-like pairs: **{int(best['n_hbond_pairs'])}**")
            lines.append(f"- Clash residue pairs: **{int(best['n_clash_residue_pairs'])}**\n")
            _append_model_score_table(lines, "## Highest 10 models by total_score\n", highest10)
            _append_model_score_table(lines, "## Lowest 10 models by total_score\n", lowest10)
            _append_contact_pair_details(
                lines,
                contact_location_df,
                ensemble_name,
                highlighted_for_pairs,
                title="## Residue-pair contacts for highest/lowest scoring models\n",
                pair_limit=pair_limit,
            )
            (sdir / f"{ensemble_name}_summary.md").write_text("\n".join(lines) + "\n")


def variant_sort_key(name: str) -> tuple:
    order = {"wt": 0, "wildtype": 0, "positive": 1, "negative": 2, "hydrophobic": 3, "polar_neutral": 4, "polar-neutral": 4, "neutral": 4}
    key = str(name).strip().lower()
    return (order.get(key, 99), key)


def aggregate_variant_plot_data(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    work = df.copy()
    work["total_score_no_clash"] = work["total_score"] - work["score_clash_penalty"]
    for col in [
        "n_heavy_residue_pairs", "n_opposite_charge_pairs", "n_like_charge_pairs",
        "n_hydrophobic_pairs", "n_cationpi_pairs", "n_pipi_pairs", "n_argarg_pairs", "n_hbond_pairs", "n_clash_residue_pairs",
    ]:
        work[f"frac_any_{col}"] = (work[col].astype(float) > 0).astype(float)

    rows = []
    group_cols = ["protein_id", "variant_name"]
    for (protein_id, variant_name), g in work.groupby(group_cols, sort=False):
        def mean_sem(series_name: str) -> tuple[float, float]:
            vals = g[series_name].astype(float).to_numpy()
            mean = float(np.mean(vals)) if len(vals) else np.nan
            sem = float(np.std(vals, ddof=0) / math.sqrt(len(vals))) if len(vals) else np.nan
            return mean, sem

        row = {"protein_id": protein_id, "variant_name": variant_name, "n_models": len(g)}
        metrics = [
            "total_score", "total_score_raw", "total_score_no_clash", "normalized_weight",
            "equivalent_weight_contact_score",
            "favorable_contact_score", "unfavorable_contact_score",
            "n_heavy_residue_pairs", "n_opposite_charge_pairs", "n_like_charge_pairs",
            "n_hydrophobic_pairs", "n_cationpi_pairs", "n_pipi_pairs", "n_argarg_pairs", "n_hbond_pairs", "n_clash_residue_pairs",
            "score_charge_contacts", "score_screened_charge", "score_hydrophobic", "score_cationpi", "score_pipi", "score_argarg", "score_hbond", "score_clash_penalty",
        ]
        for m in metrics:
            mu, se = mean_sem(m)
            row[f"mean_{m}"] = mu
            row[f"sem_{m}"] = se

        frac_metrics = [
            "n_heavy_residue_pairs", "n_opposite_charge_pairs", "n_like_charge_pairs",
            "n_hydrophobic_pairs", "n_cationpi_pairs", "n_pipi_pairs", "n_argarg_pairs", "n_hbond_pairs", "n_clash_residue_pairs",
        ]
        for m in frac_metrics:
            mu, se = mean_sem(f"frac_any_{m}")
            short = m.replace("n_", "").replace("_pairs", "")
            row[f"frac_models_any_{short}"] = mu
            row[f"sem_frac_models_any_{short}"] = se

        row["best_model_total_score"] = float(g["total_score"].max())
        row["best_model_total_score_no_clash"] = float((g["total_score"] - g["score_clash_penalty"]).max())
        rows.append(row)
    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.sort_values(["protein_id", "variant_name"], key=lambda s: s.map(lambda x: variant_sort_key(x) if s.name=="variant_name" else x))
    return out


def make_interpretable_plots(df: pd.DataFrame, summary_df: pd.DataFrame, outdir: Path, dpi: int = 300) -> None:
    if df.empty:
        return
    plot_dir = outdir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)

    plot_df = aggregate_variant_plot_data(df)
    plot_df.to_csv(plot_dir / "plot_summary_by_variant.csv", index=False)

    for protein_id, g in plot_df.groupby("protein_id", sort=False):
        g = g.copy()
        g["_sort"] = g["variant_name"].map(variant_sort_key)
        g = g.sort_values("_sort").reset_index(drop=True)
        variants = g["variant_name"].tolist()
        x = np.arange(len(variants))

        fig, axes = plt.subplots(3, 2, figsize=(16, 14), constrained_layout=True)
        fig.suptitle(f"{protein_id} chimera ensemble summary", fontsize=16)

        # 1. Mean contact score with and without clash
        ax = axes[0, 0]
        width = 0.35
        ax.bar(x - width/2, g["mean_total_score"], width=width, yerr=g["sem_total_score"], capsize=3, label="Contact score")
        ax.bar(x + width/2, g["mean_total_score_no_clash"], width=width, yerr=g["sem_total_score_no_clash"], capsize=3, label="Contact score (no clash)")
        ax.set_title("Mean model contact score")
        ax.set_ylabel("Score (higher = more favorable)")
        ax.set_xticks(x, variants, rotation=30, ha="right")
        ax.legend(frameon=False, fontsize=8)

        # 2. Mean contact counts by type
        ax = axes[0, 1]
        contact_cols = [
            ("mean_n_opposite_charge_pairs", "Opp charge"),
            ("mean_n_like_charge_pairs", "Like charge"),
            ("mean_n_hydrophobic_pairs", "Hydrophobic"),
            ("mean_n_cationpi_pairs", "Cation-pi"),
            ("mean_n_pipi_pairs", "Pi-pi"),
            ("mean_n_argarg_pairs", "Arg-Arg"),
            ("mean_n_hbond_pairs", "H-bond"),
        ]
        width = 0.12
        offsets = np.linspace(-2, 2, len(contact_cols)) * width
        for off, (col, label) in zip(offsets, contact_cols):
            ax.bar(x + off, g[col], width=width, label=label)
        ax.set_title("Mean favorable/unfavorable contact counts")
        ax.set_ylabel("Mean residue-pair count per model")
        ax.set_xticks(x, variants, rotation=30, ha="right")
        ax.legend(frameon=False, fontsize=8, ncols=2)

        # 3. Fraction of models with each contact type
        ax = axes[1, 0]
        frac_cols = [
            ("frac_models_any_opposite_charge", "Opp charge"),
            ("frac_models_any_like_charge", "Like charge"),
            ("frac_models_any_hydrophobic", "Hydrophobic"),
            ("frac_models_any_cationpi", "Cation-pi"),
            ("frac_models_any_pipi", "Pi-pi"),
            ("frac_models_any_argarg", "Arg-Arg"),
            ("frac_models_any_hbond", "H-bond"),
        ]
        width = 0.12
        offsets = np.linspace(-2, 2, len(frac_cols)) * width
        for off, (col, label) in zip(offsets, frac_cols):
            ax.bar(x + off, g[col], width=width, label=label)
        ax.set_title("Fraction of models showing each contact type")
        ax.set_ylabel("Fraction of models")
        ax.set_ylim(0, 1.05)
        ax.set_xticks(x, variants, rotation=30, ha="right")
        ax.legend(frameon=False, fontsize=8, ncols=2)

        # 4. Mean score components
        ax = axes[1, 1]
        comp_cols = [
            ("mean_score_charge_contacts", "Charge contacts"),
            ("mean_score_screened_charge", "Screened charge"),
            ("mean_score_hydrophobic", "Hydrophobic"),
            ("mean_score_cationpi", "Cation-pi"),
            ("mean_score_pipi", "Pi-pi"),
            ("mean_score_argarg", "Arg-Arg"),
            ("mean_score_hbond", "H-bond"),
            ("mean_score_clash_penalty", "Clash penalty"),
        ]
        width = 0.10
        offsets = np.linspace(-2.5, 2.5, len(comp_cols)) * width
        for off, (col, label) in zip(offsets, comp_cols):
            vals = g[col] if col in g.columns else np.zeros(len(g), dtype=float)
            ax.bar(x + off, vals, width=width, label=label)
        ax.axhline(0.0, linewidth=0.8)
        ax.set_title("Mean contact score components")
        ax.set_ylabel("Mean component contribution")
        ax.set_xticks(x, variants, rotation=30, ha="right")
        ax.legend(frameon=False, fontsize=7, ncols=2)

        # 5. Distribution of per-model contact score
        ax = axes[2, 0]
        data = [df[(df["protein_id"] == protein_id) & (df["variant_name"] == v)]["total_score"].astype(float).to_numpy() for v in variants]
        bp = ax.boxplot(data, patch_artist=True, labels=variants, showfliers=False)
        ax.set_title("Per-model contact score distribution")
        ax.set_ylabel("Contact score")
        ax.tick_params(axis='x', rotation=30)

        # 6. Favorable vs unfavorable contact score
        ax = axes[2, 1]
        width = 0.35
        ax.bar(x - width/2, g["mean_favorable_contact_score"], width=width, yerr=g["sem_favorable_contact_score"], capsize=3, label="Favorable")
        ax.bar(x + width/2, g["mean_unfavorable_contact_score"], width=width, yerr=g["sem_unfavorable_contact_score"], capsize=3, label="Unfavorable")
        ax.set_title("Interpretable score balance")
        ax.set_ylabel("Score contribution")
        ax.set_xticks(x, variants, rotation=30, ha="right")
        ax.legend(frameon=False, fontsize=8)

        fig.savefig(plot_dir / f"{protein_id}_chimera_summary.png", dpi=dpi, bbox_inches="tight")
        plt.close(fig)

    # Optional global comparison plot across all ensembles
    global_fig, global_ax = plt.subplots(figsize=(12, 6), constrained_layout=True)
    plot_df2 = plot_df.copy()
    plot_df2["label"] = plot_df2["protein_id"].astype(str) + "\n" + plot_df2["variant_name"].astype(str)
    plot_df2 = plot_df2.sort_values(["protein_id", "variant_name"], key=lambda s: s.map(lambda x: variant_sort_key(x) if s.name=="variant_name" else x))
    xg = np.arange(len(plot_df2))
    global_ax.bar(xg - 0.2, plot_df2["mean_total_score_no_clash"], width=0.4, label="Contact score (no clash)")
    global_ax.bar(xg + 0.2, plot_df2["mean_n_hydrophobic_pairs"], width=0.4, label="Mean hydrophobic pairs")
    global_ax.set_title("Across-ensemble quick comparison")
    global_ax.set_xticks(xg, plot_df2["label"].tolist(), rotation=45, ha="right")
    global_ax.legend(frameon=False, fontsize=8)
    global_fig.savefig(plot_dir / "all_ensembles_quick_comparison.png", dpi=dpi, bbox_inches="tight")
    plt.close(global_fig)



def pretty_variant_label(name: str) -> str:
    s = str(name)
    s = re.sub(r"^(N|C)[_\-.]+", "", s, flags=re.IGNORECASE)
    s = re.sub(r"^IDR\d+[_\-.]+", "", s, flags=re.IGNORECASE)
    s = s.replace("-", "_").replace(".", "_")
    parts = [p for p in s.split("_") if p]
    if not parts:
        return str(name)
    label = " ".join(parts).title()
    label = label.replace("Wt", "WT")
    return label


def mean_sem(vals: Sequence[float]) -> Tuple[float, float]:
    arr = np.asarray(vals, dtype=float)
    if len(arr) == 0:
        return np.nan, np.nan
    return float(np.mean(arr)), float(np.std(arr, ddof=0) / math.sqrt(len(arr)))


def make_paper_ready_contact_plots(df: pd.DataFrame, outdir: Path, dpi: int = 300) -> None:
    """Write one 6-panel, paper-ready contact-score figure per protein.

    The figure deliberately excludes clash terms and reports contact scores, not
    physical thermodynamic quantities. Higher contact-score values are more favorable.
    """
    if df.empty:
        return
    paper_dir = outdir / "paper_plots"
    paper_dir.mkdir(parents=True, exist_ok=True)

    contact_types = [
        ("n_opposite_charge_pairs", "Opposite Charge"),
        ("n_like_charge_pairs", "Like Charge"),
        ("n_hydrophobic_pairs", "Hydrophobic"),
        ("n_cationpi_pairs", "Cation-π"),
        ("n_pipi_pairs", "π–π"),
        ("n_argarg_pairs", "Arg–Arg"),
        ("n_hbond_pairs", "H-bond"),
    ]
    favorable_types = [
        ("n_opposite_charge_pairs", "Opposite Charge"),
        ("n_hydrophobic_pairs", "Hydrophobic"),
        ("n_cationpi_pairs", "Cation-π"),
        ("n_pipi_pairs", "π–π"),
        ("n_argarg_pairs", "Arg–Arg"),
        ("n_hbond_pairs", "H-bond"),
    ]

    # Explicitly ensure scores exist even if plotting a minimally edited legacy CSV.
    work = df.copy()
    if "total_score" not in work.columns and "total_score_raw" in work.columns:
        work = make_total_score_positive(work)
    if "equivalent_weight_contact_score" not in work.columns:
        signed_screened = work.get("screened_charge_signed_score_raw", 0.0)
        work["equivalent_weight_contact_score"] = (
            work["n_opposite_charge_pairs"].astype(float)
            - work["n_like_charge_pairs"].astype(float)
            - pd.Series(signed_screened, index=work.index).astype(float)
            + work["n_hydrophobic_pairs"].astype(float)
            + work["n_cationpi_pairs"].astype(float)
            + work["n_pipi_pairs"].astype(float)
            + work.get("n_argarg_pairs", 0).astype(float)
            + work.get("n_hbond_pairs", 0).astype(float)
        )

    # Save plot-ready summary table.
    summary_rows = []
    for (protein_id, variant), g in work.groupby(["protein_id", "variant_name"], sort=False):
        row = {"protein_id": protein_id, "variant_name": variant, "variant_label": pretty_variant_label(variant), "n_models": len(g)}
        for col, _lab in contact_types:
            row[f"frac_models_any_{col}"] = float((g[col].astype(float) > 0).mean())
            mu, se = mean_sem(g[col].astype(float))
            row[f"mean_{col}"] = mu
            row[f"sem_{col}"] = se
        for score_col in ["total_score", "equivalent_weight_contact_score"]:
            mu, se = mean_sem(g[score_col].astype(float))
            row[f"mean_{score_col}"] = mu
            row[f"sem_{score_col}"] = se
        summary_rows.append(row)
    pd.DataFrame(summary_rows).to_csv(paper_dir / "paper_plot_summary_by_variant.csv", index=False)

    for protein_id, gprot in work.groupby("protein_id", sort=False):
        variants = sorted(gprot["variant_name"].unique(), key=variant_sort_key)
        labels = [pretty_variant_label(v) for v in variants]
        x = np.arange(len(variants))

        # Precompute variant-level arrays.
        frac_any = {lab: [] for _col, lab in contact_types}
        mean_fav = {lab: [] for _col, lab in favorable_types}
        sem_fav = {lab: [] for _col, lab in favorable_types}
        mean_score_total = []
        sem_score_total = []
        mean_score_eq = []
        sem_score_eq = []
        dist_total = []
        dist_eq = []

        for v in variants:
            gv = gprot[gprot["variant_name"] == v]
            for col, lab in contact_types:
                frac_any[lab].append(float((gv[col].astype(float) > 0).mean()))
            for col, lab in favorable_types:
                mu, se = mean_sem(gv[col].astype(float))
                mean_fav[lab].append(mu)
                sem_fav[lab].append(se)
            mu, se = mean_sem(gv["total_score"].astype(float))
            mean_score_total.append(mu); sem_score_total.append(se)
            mu, se = mean_sem(gv["equivalent_weight_contact_score"].astype(float))
            mean_score_eq.append(mu); sem_score_eq.append(se)
            dist_total.append(gv["total_score"].astype(float).to_numpy())
            dist_eq.append(gv["equivalent_weight_contact_score"].astype(float).to_numpy())

        plt.rcParams.update({
            "font.size": 15,
            "axes.titlesize": 18,
            "axes.labelsize": 16,
            "xtick.labelsize": 14,
            "ytick.labelsize": 14,
            "legend.fontsize": 12,
        })
        fig, axes = plt.subplots(3, 2, figsize=(17, 18), constrained_layout=True)
        fig.set_constrained_layout_pads(w_pad=0.12, h_pad=0.14, wspace=0.22, hspace=0.24)
        fig.suptitle(f"{protein_id}: IDR–folded-domain contact signatures", fontsize=21)

        def set_xticks(ax):
            ax.set_xticks(x)
            ax.set_xticklabels(labels, rotation=30, ha="right")

        # A. Fraction of models showing each contact type
        ax = axes[0, 0]
        width = 0.12
        offsets = np.linspace(-2.5, 2.5, len(contact_types)) * width
        for off, (_col, lab) in zip(offsets, contact_types):
            ax.bar(x + off, frac_any[lab], width=width, label=lab)
        ax.set_title("Fraction of models showing each contact type")
        ax.set_ylabel("Fraction of models")
        ax.set_ylim(0, 1.05)
        set_xticks(ax)
        ax.legend(frameon=True, ncols=2)

        # B. Mean favorable contact counts
        ax = axes[0, 1]
        width = 0.14
        offsets = np.linspace(-2, 2, len(favorable_types)) * width
        for off, (_col, lab) in zip(offsets, favorable_types):
            ax.bar(x + off, mean_fav[lab], width=width, yerr=sem_fav[lab], capsize=3, label=lab)
        ax.set_title("Mean favorable contact counts")
        ax.set_ylabel("Residue-pair contacts per model")
        set_xticks(ax)
        ax.legend(frameon=True, ncols=2)

        # C. Mean total contact scores
        ax = axes[1, 0]
        ax.bar(x, mean_score_total, yerr=sem_score_total, capsize=4)
        ax.axhline(0, linewidth=0.9)
        ax.set_title("Mean ensemble total scores: heuristic weights")
        ax.set_ylabel("Contact score")
        set_xticks(ax)

        # D. Distribution heuristic
        ax = axes[1, 1]
        ax.boxplot(dist_total, labels=labels, showfliers=False)
        ax.axhline(0, linewidth=0.9)
        ax.set_title("Per-model total score distribution: heuristic weights")
        ax.set_ylabel("Contact score")
        ax.tick_params(axis="x", rotation=30)

        # E. Mean equivalent scores
        ax = axes[2, 0]
        ax.bar(x, mean_score_eq, yerr=sem_score_eq, capsize=4)
        ax.axhline(0, linewidth=0.9)
        ax.set_title("Mean ensemble contact scores: equivalent weights")
        ax.set_ylabel("Contact score")
        set_xticks(ax)

        # F. Distribution equivalent
        ax = axes[2, 1]
        ax.boxplot(dist_eq, labels=labels, showfliers=False)
        ax.axhline(0, linewidth=0.9)
        ax.set_title("Per-model contact score distribution: equivalent weights")
        ax.set_ylabel("Contact score")
        ax.tick_params(axis="x", rotation=30)

        for ax in axes.ravel():
            ax.tick_params(axis="both", labelsize=14)
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)

        png = paper_dir / f"{protein_id}_paper_ready_contact_score_6panel.png"
        pdf = paper_dir / f"{protein_id}_paper_ready_contact_score_6panel.pdf"
        fig.savefig(png, dpi=dpi, bbox_inches="tight")
        fig.savefig(pdf, bbox_inches="tight")
        plt.close(fig)


def summarize_contact_pairs_by_model(contact_df: pd.DataFrame, pair_limit: int = 200) -> pd.DataFrame:
    """Write compact residue-pair lists by ensemble/model/contact type."""
    if contact_df.empty:
        return pd.DataFrame()
    rows = []
    group_cols = ["protein_id", "variant_name", "ensemble_name", "model_index", "contact_type"]
    pair_limit = max(1, int(pair_limit))
    for keys, g in contact_df.groupby(group_cols, sort=False):
        protein_id, variant_name, ensemble_name, model_index, contact_type = keys
        g = g.drop_duplicates(subset=["idr_chain", "idr_resseq", "idr_icode", "fd_chain", "fd_resseq", "fd_icode"])
        g = g.sort_values(["idr_chain", "idr_resseq", "fd_chain", "fd_resseq"], kind="mergesort")
        pairs = [_format_contact_pair(row) for _, row in g.head(pair_limit).iterrows()]
        rows.append({
            "protein_id": protein_id,
            "variant_name": variant_name,
            "ensemble_name": ensemble_name,
            "model_index": int(model_index),
            "contact_type": contact_type,
            "n_residue_pairs": int(len(g)),
            "pair_list_truncated": int(len(g) > pair_limit),
            "pair_list_limit": pair_limit,
            "residue_pairs": "; ".join(pairs),
        })
    return pd.DataFrame(rows).sort_values(group_cols)


def summarize_contact_location_rows(contact_df: pd.DataFrame) -> pd.DataFrame:
    """Summarize contact-localization rows by ensemble, variant, and contact type."""
    if contact_df.empty:
        return pd.DataFrame()
    rows = []
    group_cols = ["protein_id", "variant_name", "ensemble_name", "contact_type"]
    for keys, g in contact_df.groupby(group_cols, sort=False):
        protein_id, variant_name, ensemble_name, contact_type = keys
        row = {
            "protein_id": protein_id,
            "variant_name": variant_name,
            "ensemble_name": ensemble_name,
            "contact_type": contact_type,
            "n_contact_rows": int(len(g)),
            "n_models_with_contact_type": int(g["model_index"].nunique()),
        }
        for col in ["idr_boundary_distance", "fd_boundary_distance", "pair_min_boundary_distance"]:
            vals = pd.to_numeric(g[col], errors="coerce").dropna()
            row[f"mean_{col}"] = float(vals.mean()) if len(vals) else np.nan
            row[f"median_{col}"] = float(vals.median()) if len(vals) else np.nan
            row[f"frac_{col}_gt5"] = float((vals > 5).mean()) if len(vals) else np.nan
            row[f"frac_{col}_gt10"] = float((vals > 10).mean()) if len(vals) else np.nan
        rows.append(row)
    return pd.DataFrame(rows).sort_values(group_cols)


def make_contact_location_plots(contact_df: pd.DataFrame, outdir: Path, dpi: int = 300) -> None:
    """Write sanity-check plots for contact distances from selected IDR:FD boundaries."""
    if contact_df.empty:
        return
    plot_dir = outdir / "contact_location_plots"
    plot_dir.mkdir(parents=True, exist_ok=True)

    # Use scored_any for the main sanity check, because it collapses all scored
    # contact classes into unique IDR:FD residue pairs per model. Fall back to
    # heavy contacts if no scored contacts exist.
    work = contact_df.copy()
    primary_type = "scored_any" if (work["contact_type"] == "scored_any").any() else "heavy"
    primary = work[work["contact_type"] == primary_type].copy()
    if primary.empty:
        return

    for protein_id, gprot in primary.groupby("protein_id", sort=False):
        gprot = gprot.copy()
        variants = sorted(gprot["variant_name"].dropna().unique(), key=variant_sort_key)
        if not variants:
            continue

        # 1. Distribution of IDR-side boundary distances by variant.
        data = [pd.to_numeric(gprot[gprot["variant_name"] == v]["idr_boundary_distance"], errors="coerce").dropna().to_numpy() for v in variants]
        labels = [pretty_variant_label(v) for v in variants]
        if any(len(d) for d in data):
            fig, ax = plt.subplots(figsize=(max(7, 1.7 * len(variants)), 5.5), constrained_layout=True)
            ax.boxplot(data, labels=labels, showfliers=False)
            ax.axhline(5, linestyle="--", linewidth=0.9)
            ax.axhline(10, linestyle="--", linewidth=0.9)
            ax.set_title(f"{protein_id}: IDR-side contact distance from selected IDR:FD boundary")
            ax.set_ylabel("Residues from selected IDR:FD boundary")
            ax.tick_params(axis="x", rotation=30)
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
            fig.savefig(plot_dir / f"{protein_id}_idr_boundary_distance_boxplot.png", dpi=dpi, bbox_inches="tight")
            plt.close(fig)

        # 2. Fraction of contacts more than 5 or 10 IDR residues from the boundary.
        frac_rows = []
        for v in variants:
            gv = gprot[gprot["variant_name"] == v]
            vals = pd.to_numeric(gv["idr_boundary_distance"], errors="coerce").dropna()
            frac_rows.append({
                "variant": pretty_variant_label(v),
                "frac_gt5": float((vals > 5).mean()) if len(vals) else np.nan,
                "frac_gt10": float((vals > 10).mean()) if len(vals) else np.nan,
            })
        frac_df = pd.DataFrame(frac_rows)
        if not frac_df.empty:
            x = np.arange(len(frac_df))
            width = 0.35
            fig, ax = plt.subplots(figsize=(max(7, 1.7 * len(frac_df)), 5.5), constrained_layout=True)
            ax.bar(x - width/2, frac_df["frac_gt5"], width=width, label=">5 residues")
            ax.bar(x + width/2, frac_df["frac_gt10"], width=width, label=">10 residues")
            ax.set_ylim(0, 1.05)
            ax.set_title(f"{protein_id}: fraction of {primary_type} contacts away from anchor")
            ax.set_ylabel("Fraction of contacts")
            ax.set_xticks(x)
            ax.set_xticklabels(frac_df["variant"].tolist(), rotation=30, ha="right")
            ax.legend(frameon=False)
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
            fig.savefig(plot_dir / f"{protein_id}_fraction_contacts_gt5_gt10_from_boundary.png", dpi=dpi, bbox_inches="tight")
            plt.close(fig)

        # 3. Contact-type-specific IDR boundary-distance histogram for the protein.
        gtyped = work[(work["protein_id"] == protein_id) & (work["contact_type"].isin([
            "opposite_charge", "like_charge", "hydrophobic", "cationpi", "pipi", "argarg", "hbond"
        ]))].copy()
        if not gtyped.empty:
            fig, ax = plt.subplots(figsize=(8.5, 5.5), constrained_layout=True)
            max_dist = pd.to_numeric(gtyped["idr_boundary_distance"], errors="coerce").max()
            if pd.isna(max_dist):
                plt.close(fig)
            else:
                bins = np.arange(0, int(max_dist) + 3) - 0.5
                for ctype, gt in gtyped.groupby("contact_type", sort=False):
                    vals = pd.to_numeric(gt["idr_boundary_distance"], errors="coerce").dropna().to_numpy()
                    if len(vals):
                        ax.hist(vals, bins=bins, histtype="step", linewidth=1.6, density=True, label=ctype)
                ax.axvline(5, linestyle="--", linewidth=0.9)
                ax.axvline(10, linestyle="--", linewidth=0.9)
                ax.set_title(f"{protein_id}: contact-class positions along selected IDR")
                ax.set_xlabel("IDR residues from selected IDR:FD boundary")
                ax.set_ylabel("Density")
                ax.legend(frameon=False, fontsize=8)
                ax.spines["top"].set_visible(False)
                ax.spines["right"].set_visible(False)
                fig.savefig(plot_dir / f"{protein_id}_contact_type_idr_distance_histogram.png", dpi=dpi, bbox_inches="tight")
                plt.close(fig)


def main() -> None:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    master = load_json(args.master_json)
    pdbs = find_pdbs(args)
    if not pdbs:
        sys.exit("ERROR: no PDB files found.")

    opt = {
        "chain": args.chain,
        "model_stride": max(1, args.model_stride),
        "max_models": args.max_models,
        "target_terminal": args.target_terminal,
        "target_idrs": args.target_idrs,
        "anchor_cutoff": args.anchor_cutoff,
        "heavy_cutoff": args.heavy_cutoff,
        "charge_contact_cutoff": args.charge_contact_cutoff,
        "electro_cutoff": args.electro_cutoff,
        "hydrophobic_cutoff": args.hydrophobic_cutoff,
        "cationpi_cutoff": args.cationpi_cutoff,
        "pipi_cutoff": args.pipi_cutoff,
        "argarg_cutoff": args.argarg_cutoff,
        "hbond_cutoff": args.hbond_cutoff,
        "hbond_h_a_cutoff": args.hbond_h_a_cutoff,
        "hbond_angle_cutoff": args.hbond_angle_cutoff,
        "hbond_geometry": args.hbond_geometry,
        "hbond_mode": args.hbond_mode,
        "clash_cutoff": args.clash_cutoff,
        "histidine_charge": args.histidine_charge,
        "debye_length": args.debye_length,
        "w_opposite_charge": args.w_opposite_charge,
        "w_like_charge": args.w_like_charge,
        "w_screened_charge": args.w_screened_charge,
        "w_hydrophobic": args.w_hydrophobic,
        "w_cationpi": args.w_cationpi,
        "w_pipi": args.w_pipi,
        "w_argarg": args.w_argarg,
        "w_hbond": args.w_hbond,
        "w_clash": args.w_clash,
    }

    payloads = [(str(p), master, opt) for p in pdbs]
    results: List[dict] = []
    workers = max(1, args.n_workers)
    if workers == 1:
        for payload in tqdm(payloads, desc="Scoring ensembles"):
            try:
                results.append(process_one_pdb(payload))
            except Exception as exc:
                results.append({"pdb": payload[0], "protein_id": None, "rows": [], "location_rows": [], "warnings": [f"worker-level failure: {type(exc).__name__}: {exc}"], "models": {}})
    else:
        with cf.ProcessPoolExecutor(max_workers=workers) as ex:
            fut_to_payload = {ex.submit(process_one_pdb, payload): payload for payload in payloads}
            for fut in tqdm(cf.as_completed(fut_to_payload), total=len(fut_to_payload), desc="Scoring ensembles"):
                payload = fut_to_payload[fut]
                try:
                    results.append(fut.result())
                except Exception as exc:
                    results.append({"pdb": payload[0], "protein_id": None, "rows": [], "location_rows": [], "warnings": [f"worker-level failure: {type(exc).__name__}: {exc}"], "models": {}})

    all_rows: List[dict] = []
    all_location_rows: List[dict] = []
    warnings: List[dict] = []
    result_by_pdb: Dict[str, dict] = {}
    for res in results:
        result_by_pdb[str(res.get("pdb"))] = res
        all_rows.extend(res.get("rows", []))
        all_location_rows.extend(res.get("location_rows", []))
        for w in res.get("warnings", []):
            warnings.append({"protein_id": res.get("protein_id"), "pdb_file": res.get("pdb"), "warning": w})

    df = pd.DataFrame(all_rows)
    contact_location_df = pd.DataFrame(all_location_rows)
    if df.empty:
        pd.DataFrame(warnings).to_csv(args.outdir / "warnings.csv", index=False)
        sys.exit("ERROR: no models were scored. Check warnings.csv.")

    df = make_total_score_positive(df)
    df = add_weights(df, beta=args.beta, scale=args.weight_scale)
    # Present naturally by ensemble/rank.
    df = df.sort_values(["protein_id", "variant_name", "ensemble_name", "model_rank_by_score"]).reset_index(drop=True)
    summary_df = make_summary(df)
    warn_df = pd.DataFrame(warnings)

    df.to_csv(args.outdir / "per_model_contact_scores.csv", index=False)
    summary_df.to_csv(args.outdir / "summary_by_ensemble.csv", index=False)
    warn_df.to_csv(args.outdir / "warnings.csv", index=False)
    if not contact_location_df.empty:
        contact_location_df.to_csv(args.outdir / "contact_location_by_pair.csv", index=False)
        summarize_contact_location_rows(contact_location_df).to_csv(args.outdir / "contact_location_summary_by_ensemble.csv", index=False)
        summarize_contact_pairs_by_model(
            contact_location_df,
            pair_limit=max(200, int(args.summary_contact_pair_limit)),
        ).to_csv(args.outdir / "contact_pairs_by_model_summary.csv", index=False)

    top_manifest = df.sort_values(["ensemble_name", "model_rank_by_score"]).groupby("ensemble_name", sort=False).head(10)
    top_manifest.to_csv(args.outdir / "top10_models_by_total_score.csv", index=False)
    lowest_manifest = (
        df.sort_values(["ensemble_name", "total_score"], ascending=[True, True])
        .groupby("ensemble_name", sort=False)
        .head(10)
    )
    lowest_manifest.to_csv(args.outdir / "lowest10_models_by_total_score.csv", index=False)

    extract_df = extract_ranked_models(df, result_by_pdb, args.outdir, args.extract_top_n, args.extract_bottom_n)
    if not extract_df.empty:
        extract_df.to_csv(args.outdir / "extracted_models_manifest.csv", index=False)

    params = vars(args).copy()
    params["pdb_file"] = str(params["pdb_file"]) if params.get("pdb_file") else None
    params["pdb_dir"] = str(params["pdb_dir"]) if params.get("pdb_dir") else None
    params["master_json"] = str(params["master_json"])
    params["outdir"] = str(params["outdir"])
    (args.outdir / "scoring_parameters.json").write_text(json.dumps(params, indent=2, sort_keys=True) + "\n")

    if args.make_readable_summaries:
        write_readable_summaries(
            df,
            summary_df,
            args.outdir,
            contact_location_df=contact_location_df,
            pair_limit=args.summary_contact_pair_limit,
        )
    if args.make_plots:
        make_interpretable_plots(df, summary_df, args.outdir, dpi=args.plot_dpi)
    if args.make_contact_location_plots or args.make_plots:
        make_contact_location_plots(contact_location_df, args.outdir, dpi=args.plot_dpi)
    if args.make_paper_plot:
        make_paper_ready_contact_plots(df, args.outdir, dpi=args.plot_dpi)

    print(f"Done. Wrote outputs to: {args.outdir}")
    print(f"Scored ensembles: {df['ensemble_name'].nunique()} | model rows: {len(df)} | contact-location rows: {len(contact_location_df)} | warnings: {len(warn_df)}")
    print("Main output: per_model_contact_scores.csv")
    print("Summary: summary_by_ensemble.csv")


if __name__ == "__main__":
    main()
