"""
Step 1 for an AlphaFlex TM-IDR workflow.

Given a text file of UniProt accessions, fetch UniProtKB JSON records and keep only
proteins that are annotated by UniProt as known transmembrane proteins. By default,
"known TM" means at least one UniProt feature of type "Transmembrane".

Outputs:
  1) JSON checkpoint with UniProt sequence, TM/SIGNAL/TOPO_DOM features, and status.
  2) FASTA file containing only the known-TM subset.
  3) Text file of known-TM UniProt IDs.
  4) Text file of non-TM / failed IDs.
  5) (Optional) PDF of TM label statistics plots.

Feature coordinates are 1-based inclusive residue indices.

Example (plain ID list):
  python tm01_uniprot_known_tm.py \
    --ids uniprot_ids.txt \
    --out-json step1_uniprot_known_tm.json \
    --out-fasta step1_known_tm.fasta \
    --out-ids step1_known_tm_ids.txt \
    --out-non-tm-ids step1_non_tm_ids.txt \
    --cache-dir uniprot_cache

Example (AF2 sequences JSON — {accession: sequence} dict):
  python tm01_uniprot_known_tm.py \
    --af2-json AF2_9606_HUMAN_v4_sequences.json \
    --out-json step1_uniprot_known_tm.json \
    --out-fasta step1_known_tm.fasta \
    --out-ids step1_known_tm_ids.txt \
    --out-non-tm-ids step1_non_tm_ids.txt \
    --cache-dir uniprot_cache
"""
import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from tqdm import tqdm

import requests

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    _HAS_MPL = True
except ImportError:
    _HAS_MPL = False

UNIPROT_URL = "https://rest.uniprot.org/uniprotkb/{accession}.json"


@dataclass
class Interval:
    start: int
    end: int
    label: str
    source: str = "UniProt"
    note: str = ""
    evidence: str = ""

    def as_dict(self) -> dict:
        return asdict(self)


def read_ids(path: str) -> List[str]:
    ids: List[str] = []
    with open(path) as handle:
        for line in handle:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            ids.append(s.split()[0])
    # preserve order, remove exact duplicates
    seen = set()
    out = []
    for x in ids:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out


def read_af2_json(path: str) -> Tuple[List[str], Dict[str, str]]:
    """Read an AF2 sequences JSON ({accession: sequence}) and return
    (ordered list of accessions, accession->sequence mapping)."""
    with open(path) as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError(f"--af2-json expects a JSON object mapping accession->sequence, got {type(data).__name__}")
    seen: set = set()
    ordered: List[str] = []
    seqs: Dict[str, str] = {}
    for acc, seq in data.items():
        if acc not in seen:
            ordered.append(acc)
            seen.add(acc)
        seqs[acc] = str(seq).replace("\n", "").replace(" ", "").upper()
    return ordered, seqs


def write_fasta(seqs: Dict[str, str], path: str) -> None:
    with open(path, "w") as out:
        for acc, seq in seqs.items():
            out.write(f">{acc}\n")
            for i in range(0, len(seq), 80):
                out.write(seq[i : i + 80] + "\n")


def write_ids(ids: Iterable[str], path: str) -> None:
    with open(path, "w") as out:
        for acc in ids:
            out.write(str(acc) + "\n")


def cache_path(cache_dir: Optional[str], accession: str) -> Optional[Path]:
    if not cache_dir:
        return None
    return Path(cache_dir) / f"{accession}.json"


def fetch_uniprot(accession: str, cache_dir: Optional[str] = None, timeout: int = 30, retries: int = 3, sleep: float = 0.2) -> Optional[dict]:
    cpath = cache_path(cache_dir, accession)
    if cpath and cpath.exists():
        try:
            return json.loads(cpath.read_text())
        except Exception as exc:
            print(f"[WARN] Could not read cache for {accession}: {exc}", file=sys.stderr)

    url = UNIPROT_URL.format(accession=accession)
    last_error = None
    for attempt in range(1, retries + 1):
        try:
            r = requests.get(url, timeout=timeout, headers={"Accept": "application/json"})
            if r.status_code == 200:
                data = r.json()
                if cpath:
                    cpath.parent.mkdir(parents=True, exist_ok=True)
                    cpath.write_text(json.dumps(data, indent=2))
                if sleep:
                    time.sleep(sleep)
                return data
            last_error = f"HTTP {r.status_code}: {r.text[:250]}"
        except Exception as exc:
            last_error = str(exc)
        time.sleep(1.0 + attempt)
    print(f"[WARN] UniProt fetch failed for {accession}: {last_error}", file=sys.stderr)
    return None


def evidence_summary(feature: dict) -> str:
    evs = feature.get("evidences") or []
    bits = []
    for ev in evs[:5]:
        code = ev.get("evidenceCode") or ev.get("code") or ""
        src = ev.get("source") or ""
        if isinstance(src, dict):
            src = src.get("name") or src.get("id") or ""
        bits.append(":".join([x for x in [code, str(src)] if x]))
    return ";".join(bits)


def location_to_interval(location: dict) -> Optional[Tuple[int, int]]:
    try:
        start = int(location.get("start", {}).get("value"))
        end = int(location.get("end", {}).get("value"))
        if start > end:
            start, end = end, start
        return start, end
    except Exception:
        return None


def parse_features(record: dict) -> List[Interval]:
    label_map = {
        "Transmembrane": "TRANSMEM",
        "Intramembrane": "INTRAMEM",
        "Topological domain": "TOPO_DOM",
        "Signal": "SIGNAL",
        "Signal peptide": "SIGNAL",
        "Lipidation": "LIPID",
        "Chain": "CHAIN",
        "Region": "REGION",
        "Domain": "DOMAIN",
    }
    keep_types = set(label_map)
    out: List[Interval] = []
    for f in record.get("features", []) or []:
        ftype = f.get("type", "")
        if ftype not in keep_types:
            continue
        loc = location_to_interval(f.get("location", {}))
        if loc is None:
            continue
        note = f.get("description") or ""
        out.append(Interval(start=loc[0], end=loc[1], label=label_map.get(ftype, ftype.upper()), note=note, evidence=evidence_summary(f)))
    return out


def get_entry_name(record: dict) -> str:
    return record.get("uniProtkbId") or record.get("primaryAccession") or ""


def get_protein_name(record: dict) -> str:
    desc = record.get("proteinDescription") or {}
    rec = desc.get("recommendedName") or {}
    full = rec.get("fullName") or {}
    if isinstance(full, dict):
        return full.get("value", "")
    return ""


def plot_statistics(proteins: Dict[str, dict], out_pdf: str) -> None:
    """Write a multi-panel PDF of TM label statistics for the processed proteins."""
    if not _HAS_MPL:
        print("[WARN] matplotlib not available; skipping plots.", file=sys.stderr)
        return

    tm_proteins = [v for v in proteins.values() if v.get("known_tm_uniprot")]

    # ── data collection ────────────────────────────────────────────────────────
    n_input = len(proteins)
    n_tm = len(tm_proteins)
    n_non_tm = n_input - n_tm

    tm_counts = [len(v.get("uniprot_tm_segments") or []) for v in tm_proteins]
    tm_lengths = [
        seg["end"] - seg["start"] + 1
        for v in tm_proteins
        for seg in (v.get("uniprot_tm_segments") or [])
    ]
    prot_lengths = [v["length"] for v in tm_proteins if v.get("length")]

    topo_notes: List[str] = []
    for v in tm_proteins:
        for td in v.get("uniprot_topology_domains") or []:
            note = (td.get("note") or "").strip()
            if note:
                topo_notes.append(note)

    signal_count = sum(1 for v in tm_proteins if v.get("uniprot_signal_segments"))
    intramem_count = sum(1 for v in tm_proteins if v.get("uniprot_intramem_segments"))

    # ── plotting ───────────────────────────────────────────────────────────────
    Path(out_pdf).parent.mkdir(parents=True, exist_ok=True) if Path(out_pdf).parent != Path(".") else None

    with PdfPages(out_pdf) as pdf:
        fig, axes = plt.subplots(2, 3, figsize=(15, 9))
        fig.suptitle("UniProt TM Label Statistics", fontsize=14, fontweight="bold")

        # 1) TM vs non-TM count
        ax = axes[0, 0]
        bars = ax.bar(["Known TM", "Non-TM / failed"], [n_tm, n_non_tm], color=["steelblue", "salmon"], edgecolor="white")
        for bar, val in zip(bars, [n_tm, n_non_tm]):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5, str(val), ha="center", va="bottom", fontsize=10)
        ax.set_title("Input proteins")
        ax.set_ylabel("Count")
        ax.set_ylim(0, max(n_tm, n_non_tm) * 1.15)

        # 2) # TM segments per protein
        ax = axes[0, 1]
        if tm_counts:
            max_tm = max(tm_counts)
            bins = range(1, max_tm + 2)
            ax.hist(tm_counts, bins=bins, align="left", color="steelblue", edgecolor="white", rwidth=0.8)
        ax.set_title("TM segments per protein")
        ax.set_xlabel("# TM segments")
        ax.set_ylabel("# proteins")

        # 3) TM segment lengths
        ax = axes[0, 2]
        if tm_lengths:
            ax.hist(tm_lengths, bins=20, color="mediumseagreen", edgecolor="white")
            ax.axvline(sum(tm_lengths) / len(tm_lengths), color="darkgreen", linestyle="--", linewidth=1.2, label=f"mean={sum(tm_lengths)/len(tm_lengths):.1f}")
            ax.legend(fontsize=8)
        ax.set_title("TM segment lengths")
        ax.set_xlabel("Residues")
        ax.set_ylabel("Count")

        # 4) Protein sequence lengths (TM subset)
        ax = axes[1, 0]
        if prot_lengths:
            ax.hist(prot_lengths, bins=30, color="cornflowerblue", edgecolor="white")
            ax.axvline(sum(prot_lengths) / len(prot_lengths), color="navy", linestyle="--", linewidth=1.2, label=f"mean={sum(prot_lengths)/len(prot_lengths):.0f}")
            ax.legend(fontsize=8)
        ax.set_title("Protein lengths (TM subset)")
        ax.set_xlabel("Residues")
        ax.set_ylabel("# proteins")

        # 5) Topological domain note breakdown
        ax = axes[1, 1]
        if topo_notes:
            from collections import Counter
            counts = Counter(topo_notes).most_common(10)
            labels, vals = zip(*counts)
            y_pos = range(len(labels))
            ax.barh(list(y_pos), list(vals), color="mediumpurple", edgecolor="white")
            ax.set_yticks(list(y_pos))
            ax.set_yticklabels([l[:30] for l in labels], fontsize=7)
            ax.invert_yaxis()
            ax.set_xlabel("Count")
        ax.set_title("Topological domain types (top 10)")

        # 6) Signal peptide & intramem presence
        ax = axes[1, 2]
        bars = ax.bar(
            ["Signal peptide", "Intramembrane"],
            [signal_count, intramem_count],
            color=["darkorange", "tomato"],
            edgecolor="white",
        )
        for bar, val in zip(bars, [signal_count, intramem_count]):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.2, str(val), ha="center", va="bottom", fontsize=10)
        ax.set_title("Co-occurring features (TM subset)")
        ax.set_ylabel("# proteins")
        ax.set_ylim(0, max(signal_count, intramem_count, 1) * 1.2)

        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)

    print(f"[OK] wrote {out_pdf}")


def get_gene_names(record: dict) -> List[str]:
    genes = []
    for g in record.get("genes", []) or []:
        name = g.get("geneName", {}).get("value")
        if name:
            genes.append(name)
    return genes


def _process_one(
    acc: str,
    cache_dir: Optional[str],
    timeout: int,
    retries: int,
    sleep: float,
    af2_seq: Optional[str],
    include_intramem: bool,
    ) -> Tuple[str, dict, bool, Optional[str]]:
        """Fetch and process one accession. Returns (acc, entry_dict, is_tm, fasta_seq)."""
        record = fetch_uniprot(acc, cache_dir, timeout, retries, sleep)
        if record is None:
            return acc, {"status": "fetch_failed", "known_tm_uniprot": False}, False, None
    
        seq = af2_seq or (record.get("sequence") or {}).get("value")
        features = parse_features(record)
        transmem = [x for x in features if x.label == "TRANSMEM"]
        intramem = [x for x in features if x.label == "INTRAMEM"]
        signals  = [x for x in features if x.label == "SIGNAL"]
        topo     = [x for x in features if x.label == "TOPO_DOM"]
    
        known = bool(transmem) or (include_intramem and bool(intramem))
        fasta_seq = seq.upper() if (known and seq) else None
    
        entry = {
            "status": "ok",
            "primary_accession": record.get("primaryAccession", acc),
            "entry_name": get_entry_name(record),
            "protein_name": get_protein_name(record),
            "gene_names": get_gene_names(record),
            "organism": ((record.get("organism") or {}).get("scientificName")),
            "sequence": seq.upper() if seq else None,
            "length": len(seq) if seq else None,
            "known_tm_uniprot": known,
            "known_tm_rule": "TRANSMEM present" if transmem else ("INTRAMEM present" if known else "no UniProt TRANSMEM"),
            "uniprot_features": [x.as_dict() for x in features],
            "uniprot_tm_segments": [x.as_dict() for x in transmem],
            "uniprot_intramem_segments": [x.as_dict() for x in intramem],
            "uniprot_signal_segments": [x.as_dict() for x in signals],
            "uniprot_topology_domains": [x.as_dict() for x in topo],
        }
        return acc, entry, known, fasta_seq


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    id_src = ap.add_mutually_exclusive_group(required=True)
    id_src.add_argument("--ids", help="Text file with UniProt accessions, one per line")
    id_src.add_argument("--af2-json", dest="af2_json", help="AF2 sequences JSON file ({accession: sequence}); accessions and sequences are read from this file")
    ap.add_argument("--out-json", required=True, help="Step-1 JSON checkpoint")
    ap.add_argument("--out-fasta", required=True, help="FASTA of UniProt-known TM subset")
    ap.add_argument("--out-ids", required=True, help="Text file of UniProt-known TM IDs")
    ap.add_argument("--out-non-tm-ids", required=True, help="Text file of non-TM or failed IDs")
    ap.add_argument("--cache-dir", default="uniprot_cache", help="Cache UniProt JSON records here")
    ap.add_argument("--include-intramem", action="store_true", help="Also keep UniProt INTRAMEM-only proteins. Default keeps only TRANSMEM-crossing proteins.")
    ap.add_argument("--timeout", type=int, default=30)
    ap.add_argument("--retries", type=int, default=3)
    ap.add_argument("--sleep", type=float, default=0.2, help="Polite delay after successful UniProt requests (per worker thread)")
    ap.add_argument("--workers", type=int, default=16, help="Number of parallel HTTP worker threads for UniProt fetching")
    ap.add_argument("--out-plots", default=None, help="Optional path for output PDF of TM statistics plots (e.g. step1_stats.pdf)")
    args = ap.parse_args()

    af2_seqs: Dict[str, str] = {}
    if args.af2_json:
        ids, af2_seqs = read_af2_json(args.af2_json)
        input_source = args.af2_json
    else:
        ids = read_ids(args.ids)
        input_source = args.ids

    proteins: Dict[str, dict] = {}
    known_tm_ids: List[str] = []
    non_tm_ids: List[str] = []
    fasta_seqs: Dict[str, str] = {}

    total = len(ids)
    results: Dict[str, Tuple[dict, bool, Optional[str]]] = {}

    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        future_to_acc = {
            executor.submit(
                _process_one,
                acc,
                args.cache_dir,
                args.timeout,
                args.retries,
                args.sleep,
                af2_seqs.get(acc),
                args.include_intramem,
            ): acc
            for acc in ids
        }
        with tqdm(total=total, desc="Fetching UniProt", unit="acc", file=sys.stderr) as pbar:
            for future in as_completed(future_to_acc):
                acc_done, entry, is_tm, fasta_seq = future.result()
                results[acc_done] = (entry, is_tm, fasta_seq)
                pbar.update(1)

    # Reassemble in original input order
    for acc in ids:
        entry, is_tm, fasta_seq = results[acc]
        proteins[acc] = entry
        if is_tm:
            known_tm_ids.append(acc)
            if fasta_seq:
                fasta_seqs[acc] = fasta_seq
        else:
            non_tm_ids.append(acc)

    result = {
        "schema": "alphaflex_tm_step1_uniprot_known_tm_v1",
        "created_by": "tm01_uniprot_known_tm.py",
        "known_tm_definition": "UniProt TRANSMEM feature present" + ("; INTRAMEM-only also included" if args.include_intramem else ""),
        "inputs": {"source": input_source, "af2_json": args.af2_json, "ids": args.ids, "include_intramem": args.include_intramem},
        "counts": {"input_ids": len(ids), "known_tm": len(known_tm_ids), "non_tm_or_failed": len(non_tm_ids)},
        "known_tm_ids": known_tm_ids,
        "non_tm_or_failed_ids": non_tm_ids,
        "proteins": proteins,
    }

    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True) if Path(args.out_json).parent != Path(".") else None
    with open(args.out_json, "w") as out:
        json.dump(result, out, indent=2)
    write_fasta(fasta_seqs, args.out_fasta)
    write_ids(known_tm_ids, args.out_ids)
    write_ids(non_tm_ids, args.out_non_tm_ids)

    print(f"[OK] wrote {args.out_json}")
    print(f"[OK] wrote {args.out_fasta} with {len(fasta_seqs)} sequences")

    if args.out_plots:
        plot_statistics(proteins, args.out_plots)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
