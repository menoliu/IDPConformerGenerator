"""
Step 3 for an AlphaFlex TM-IDR workflow.

Input:
  * Step-2 JSON from tm02_tmbed_boundaries.py, using TMbed topology first and UniProt only as fallback.
  * Known-IDR JSON: {"P08913": [[1, 40], [150, 170]]} or dicts with start/end/label.
  * PDB templates, ideally AlphaFold DB PDBs whose residue numbers match UniProt coordinates.

Action:
    * Delineate each IDR as N-terminal, C-terminal, linker, or N+C edge case.
  * Remove known IDR coordinates from the template.
  * Infer a membrane frame automatically from predicted TM segment C-alpha coordinates.
  * Generate candidate IDR fragments with IDPConformerGenerator `build`.
  * If strict filtering leaves fewer accepted single-terminal conformers than requested,
    launch additional fragment batches and keep sampling until --n-conformers is reached
    or explicit safety limits are hit.
  * Terminal/LINKER IDRs use Kabsch-aligned flank fragments.
  * LOOP-IDRs use hard-flex-style two-anchor closure: lower/upper anchor alignment plus `next_seeker`.
  * Filter IDR-placement clashes only: IDR-vs-fixed-template and IDR-vs-IDR-region clashes.
    Normal covalent contacts inside the fixed template and inside each generated IDR fragment are not counted as clashes.
    * For linker IDRs, apply stricter membrane-core avoidance so linker chains stay
        attached to the TM scaffold but swing outward from the bilayer.
  * Filter IDR/bilayer conflicts using a probabilistic POPC slab only.
    No explicit lipid atoms are generated or required.
    * Postprocess accepted conformers in-script (default):
            - PDBFixer protonation
            - restrained OpenMM minimization
            - folded/TM-region alignment across conformers
            - single multi-model ensemble PDB output

Important assumptions:
  * PDB template residue numbering matches the full-length UniProt sequence.
  * This script currently parses PDB, not mmCIF.
  * IDR ranges are 1-based inclusive and should not include true TM helix residues.
  * The automatic membrane orientation is approximate; it is meant for high-throughput filtering.

Examples:
    # build the easy non-conflict TM-IDR list from tm02_3
    python tm03_build_tm_idr_probabilistic_slab.py \
        --tm-json ../databases/transmembrane/step2_tmbed_uniprot_full_boundaries.json \
        --master-db-json ../databases/min15_updated_PAE_master_db_fixed.json \
        --idr-json ../databases/min15_updated_PAE_master_db_fixed.json \
        --ids-file ../databases/bilayer_classification/non_conflict_easy_ids.txt \
        --template-dir ../databases/AF2_9606_PAE_PDB \
        --outdir ../AF_tm_ensembles/tmidr_popc_slab_easy \
        --workdir ../AF_tm_ensembles/work_popc_slab_easy \
        --idpcg-db ../databases/idpconfgen_database_2024.json \
        --n-conformers 100 \
        --only-tm

    # same run but keep raw accepted conformers only
    python tm03_build_tm_idr_probabilistic_slab.py \
        --tm-json ../databases/transmembrane/step2_tmbed_uniprot_full_boundaries.json \
        --master-db-json ../databases/min15_updated_PAE_master_db_fixed.json \
        --idr-json ../databases/min15_updated_PAE_master_db_fixed.json \
        --ids-file ../databases/bilayer_classification/non_conflict_difficult_ids.txt \
        --template-dir ../databases/AF2_9606_PAE_PDB \
        --outdir ../AF_tm_ensembles/tmidr_popc_slab_difficult \
        --workdir ../AF_tm_ensembles/work_popc_slab_difficult \
        --idpcg-db ../databases/idpconfgen_database_2024.json \
        --skip-postprocess \
        --only-tm
"""
import argparse
import csv
import glob
import importlib
import json
import os
import random
import shlex
import shutil
import subprocess
import sys
from dataclasses import dataclass, replace
from functools import partial
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
from scipy.spatial import cKDTree

PDBFixer = None
CustomExternalForce = None
LangevinIntegrator = None
ForceField = None
HBonds = None
NoCutoff = None
PDBFile = None
Simulation = None
angstrom = None
kelvin = None
kilocalories_per_mole = None
picosecond = None
picoseconds = None

AA3_TO_1 = {
    "ALA":"A", "ARG":"R", "ASN":"N", "ASP":"D", "CYS":"C", "GLN":"Q", "GLU":"E", "GLY":"G", "HIS":"H", "ILE":"I",
    "LEU":"L", "LYS":"K", "MET":"M", "PHE":"F", "PRO":"P", "SER":"S", "THR":"T", "TRP":"W", "TYR":"Y", "VAL":"V",
    "MSE":"M", "SEC":"U", "PYL":"O",
}
AA1_TO_3 = {v:k for k, v in AA3_TO_1.items() if len(v) == 1}
AA1_TO_3.update({"A":"ALA","R":"ARG","N":"ASN","D":"ASP","C":"CYS","Q":"GLN","E":"GLU","G":"GLY","H":"HIS","I":"ILE","L":"LEU","K":"LYS","M":"MET","F":"PHE","P":"PRO","S":"SER","T":"THR","W":"TRP","Y":"TYR","V":"VAL"})

VDW = {
    "H": 1.10, "C": 1.70, "N": 1.55, "O": 1.52, "S": 1.80, "P": 1.80,
    "F": 1.47, "CL": 1.75, "BR": 1.85, "I": 1.98,
}
BACKBONE = {"N", "CA", "C", "O", "OXT"}
ALIGN_ATOMS = {"N", "CA", "C"}


@dataclass
class Atom:
    record: str
    serial: int
    name: str
    altloc: str
    resname: str
    chain: str
    resseq: int
    icode: str
    x: float
    y: float
    z: float
    occ: float
    b: float
    element: str
    source: str = "template"  # template, idr, lipid

    @property
    def xyz(self) -> np.ndarray:
        return np.array([self.x, self.y, self.z], dtype=float)

    def with_xyz(self, xyz: Sequence[float]) -> "Atom":
        return replace(self, x=float(xyz[0]), y=float(xyz[1]), z=float(xyz[2]))


def element_from_name(name: str) -> str:
    s = "".join([c for c in name.strip() if c.isalpha()]).upper()
    if not s:
        return "C"
    if len(s) >= 2 and s[:2] in {"CL", "BR"}:
        return s[:2]
    return s[0]


def parse_pdb(path: str, chain: Optional[str] = None, include_hetatm: bool = False) -> List[Atom]:
    atoms: List[Atom] = []
    with open(path, errors="ignore") as handle:
        for line in handle:
            if not (line.startswith("ATOM") or (include_hetatm and line.startswith("HETATM"))):
                continue
            ch = line[21].strip() or "A"
            if chain and ch != chain:
                continue
            alt = line[16].strip()
            if alt not in {"", "A", "1"}:
                continue
            try:
                elem = line[76:78].strip().upper() or element_from_name(line[12:16])
                atoms.append(Atom(
                    record=line[:6].strip(),
                    serial=int(line[6:11]),
                    name=line[12:16].strip(),
                    altloc=alt,
                    resname=line[17:20].strip(),
                    chain=ch,
                    resseq=int(line[22:26]),
                    icode=line[26].strip(),
                    x=float(line[30:38]),
                    y=float(line[38:46]),
                    z=float(line[46:54]),
                    occ=float(line[54:60] or 1.0),
                    b=float(line[60:66] or 0.0),
                    element=elem,
                ))
            except Exception:
                continue
    return atoms


def write_pdb(atoms: List[Atom], path: str, remarks: Optional[List[str]] = None) -> None:
    with open(path, "w") as out:
        if remarks:
            for r in remarks:
                out.write(f"REMARK {r[:72]}\n")
        serial = 1
        for a in atoms:
            record = "HETATM" if a.source == "lipid" or a.record == "HETATM" else "ATOM"
            name = a.name
            if len(name) < 4 and not name[0].isdigit():
                name_fmt = f" {name:<3s}"
            else:
                name_fmt = f"{name:>4s}"
            out.write(
                f"{record:<6s}{serial:5d} {name_fmt}{a.altloc or ' ':1s}"
                f"{a.resname:>3s} {a.chain[:1] or 'A':1s}"
                f"{a.resseq:4d}{a.icode or ' ':1s}   "
                f"{a.x:8.3f}{a.y:8.3f}{a.z:8.3f}"
                f"{a.occ:6.2f}{a.b:6.2f}          {a.element:>2s}\n"
            )
            serial += 1
        out.write("END\n")


def atom_xyz(atoms: List[Atom]) -> np.ndarray:
    if not atoms:
        return np.zeros((0, 3), dtype=float)
    return np.array([[a.x, a.y, a.z] for a in atoms], dtype=float)


def rotate_atoms(atoms: List[Atom], R: np.ndarray, t: np.ndarray) -> List[Atom]:
    return [a.with_xyz(R @ a.xyz + t) for a in atoms]


def kabsch(moving: np.ndarray, target: np.ndarray) -> Tuple[np.ndarray, np.ndarray, float]:
    """Return R,t,rmsd so R @ moving + t ~= target."""
    if moving.shape != target.shape or moving.shape[0] < 3:
        raise ValueError("Need >=3 paired points for Kabsch alignment")
    cm = moving.mean(axis=0)
    ct = target.mean(axis=0)
    X = moving - cm
    Y = target - ct
    H = X.T @ Y
    U, S, Vt = np.linalg.svd(H)
    R = Vt.T @ U.T
    if np.linalg.det(R) < 0:
        Vt[-1, :] *= -1
        R = Vt.T @ U.T
    t = ct - R @ cm
    diff = (moving @ R.T + t) - target  # equivalent if row vectors; for rmsd only
    rmsd = float(np.sqrt((diff * diff).sum() / moving.shape[0]))
    return R, t, rmsd


def rotation_matrix_from_vectors(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Rotate vector a to vector b."""
    a = a / (np.linalg.norm(a) + 1e-12)
    b = b / (np.linalg.norm(b) + 1e-12)
    v = np.cross(a, b)
    c = float(np.dot(a, b))
    if c > 0.999999:
        return np.eye(3)
    if c < -0.999999:
        # 180-degree rotation around any perpendicular axis.
        axis = np.array([1.0, 0.0, 0.0])
        if abs(a[0]) > 0.9:
            axis = np.array([0.0, 1.0, 0.0])
        v = np.cross(a, axis)
        v /= np.linalg.norm(v)
        K = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
        return np.eye(3) + 2 * (K @ K)
    s = np.linalg.norm(v)
    K = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + K + K @ K * ((1 - c) / (s * s + 1e-12))


def load_json(path: str) -> dict:
    with open(path) as handle:
        return json.load(handle)


def get_protein_map(db_obj: dict) -> Dict[str, dict]:
    if isinstance(db_obj, dict) and isinstance(db_obj.get("proteins"), dict):
        return db_obj["proteins"]
    if isinstance(db_obj, dict):
        return db_obj
    return {}


def load_ids_file(path: str) -> List[str]:
    ids = []
    with open(path) as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            ids.append(line)
    return ids


def is_tm_like(tm_class: str) -> bool:
    cls = (tm_class or "UNKNOWN").upper()
    return "TM" in cls and not cls.startswith("NON")


def first_non_empty(record: dict, keys: Sequence[str], default=None):
    for k in keys:
        v = record.get(k)
        if v not in (None, "", [], {}):
            return v
    return default


TM_LABELS = set("HhBbMmTt")
INSIDE_LABELS = set("Ii")
OUTSIDE_LABELS = set("Oo")
SIGNAL_LABELS = set("Ss")


def clean_topology_string(value: Any) -> Optional[str]:
    """Return a compact residue-label string if value looks like TMbed topology."""
    if not isinstance(value, str):
        return None
    lines = [ln.strip() for ln in value.splitlines() if ln.strip() and not ln.startswith(">")]
    s = "".join(lines).strip()
    if not s:
        return None
    allowed = TM_LABELS | INSIDE_LABELS | OUTSIDE_LABELS | SIGNAL_LABELS | {".", "-"}
    label_chars = [c for c in s if c in allowed]
    if len(label_chars) < max(5, 0.75 * len(s.replace(" ", ""))):
        return None
    return "".join(label_chars)


def intervals_from_label_string(labels: str, tm_chars: Iterable[str] = TM_LABELS) -> List[Tuple[int, int]]:
    intervals: List[Tuple[int, int]] = []
    tm_chars = set(tm_chars)
    start: Optional[int] = None
    for idx, ch in enumerate(labels, start=1):
        if ch in tm_chars:
            if start is None:
                start = idx
        else:
            if start is not None:
                intervals.append((start, idx - 1))
                start = None
    if start is not None:
        intervals.append((start, len(labels)))
    return intervals


def normalize_interval_list(items: Any) -> List[Tuple[int, int]]:
    out: List[Tuple[int, int]] = []
    if not isinstance(items, list):
        return out
    for item in items:
        try:
            if isinstance(item, dict):
                start = int(first_non_empty(item, ["start", "begin", "from", "first", "s"], None))
                end = int(first_non_empty(item, ["end", "stop", "to", "last", "e"], None))
            else:
                start, end = int(item[0]), int(item[1])
        except Exception:
            continue
        if start > end:
            start, end = end, start
        out.append((start, end))
    return sorted(set(out))


def tmbed_container(record: dict) -> dict:
    if isinstance(record.get("tmbed"), dict):
        return record["tmbed"]
    return {}


def extract_tmbed_topology(record: dict) -> Optional[str]:
    nested = tmbed_container(record)
    for source in (nested, record):
        topo = first_non_empty(
            source,
            [
                "topology_labels", "tmbed_topology", "topology", "topology_string", "labels",
                "prediction", "per_residue_labels", "description", "topology_description",
            ],
            None,
        )
        topo_clean = clean_topology_string(topo)
        if topo_clean:
            return topo_clean
    return None


def extract_tmbed_intervals(record: dict) -> List[Tuple[int, int]]:
    nested = tmbed_container(record)
    for key in ("tm_intervals", "tm_segments", "segments", "predicted_tm_segments"):
        intervals = normalize_interval_list(nested.get(key))
        if intervals:
            return intervals
    topo = extract_tmbed_topology(record)
    if topo:
        intervals = intervals_from_label_string(topo)
        if intervals:
            return intervals
    src_text = " ".join(str(record.get(k, "")) for k in ("tm_classification", "tm_class", "classification", "source", "boundary_source"))
    if "TMBED" in src_text.upper():
        for key in ("tmbed_tm_segments", "predicted_tm_segments", "tm_segments"):
            intervals = normalize_interval_list(record.get(key))
            if intervals:
                return intervals
    return []


def extract_uniprot_intervals(record: dict) -> List[Tuple[int, int]]:
    for key in (
        "uniprot_tm_segments", "uniprot_transmembrane_segments", "uniprot_transmembrane",
        "uniprot_tm_intervals", "transmembrane", "transmembrane_regions", "tm_features",
    ):
        intervals = normalize_interval_list(record.get(key))
        if intervals:
            return intervals
    # Last-resort fallback only when TMbed prediction is absent.
    intervals = normalize_interval_list(record.get("consensus_tm_segments"))
    if intervals:
        return intervals
    return []


def preferred_tm_annotation(record: dict) -> dict:
    """Return TM intervals/topology with TMbed priority and UniProt fallback only if TMbed is absent."""
    topo = extract_tmbed_topology(record)
    tmbed_intervals = extract_tmbed_intervals(record)
    if topo or tmbed_intervals:
        return {
            "source": "TMBED_TOPOLOGY" if topo else "TMBED_INTERVALS",
            "topology_labels": topo,
            "tm_segments": tmbed_intervals,
            "tm_classification": "TMBED_TM" if tmbed_intervals else "NON_TM_TMBED_TOPOLOGY",
            "used_uniprot_fallback": False,
        }
    uni_intervals = extract_uniprot_intervals(record)
    return {
        "source": "UNIPROT_FALLBACK" if uni_intervals else "NO_TM_ANNOTATION",
        "topology_labels": None,
        "tm_segments": uni_intervals,
        "tm_classification": "UNIPROT_FALLBACK_TM" if uni_intervals else "NON_TM_OR_UNKNOWN",
        "used_uniprot_fallback": bool(uni_intervals),
    }


def merge_protein_record(acc: str, tm_record: Optional[dict], master_record: Optional[dict]) -> dict:
    out = {}
    if isinstance(master_record, dict):
        out.update(master_record)
    if isinstance(tm_record, dict):
        out.update(tm_record)

    out["accession"] = acc
    out.setdefault("primaryAccession", acc)

    if "sequence" not in out:
        out["sequence"] = first_non_empty(
            out,
            ["sequence", "full_sequence", "uniprot_sequence", "protein_sequence", "seq"],
            default=None,
        )

    # Re-resolve membrane annotations after merging. TMbed is authoritative;
    # UniProt/consensus intervals are used only if no TMbed topology/intervals exist.
    anno = preferred_tm_annotation(out)
    out["consensus_tm_segments"] = [
        {"start": int(start), "end": int(end), "source": anno["source"]}
        for start, end in anno["tm_segments"]
    ]
    out["topology_labels"] = anno["topology_labels"]
    out["tm_annotation_source"] = anno["source"]
    out["used_uniprot_fallback"] = bool(anno["used_uniprot_fallback"])
    out["tm_classification"] = anno["tm_classification"]
    return out


def normalize_idr_json(obj: dict) -> Dict[str, List[dict]]:
    out: Dict[str, List[dict]] = {}
    for acc, value in obj.items():
        if isinstance(value, dict):
            ranges = value.get("idrs", [])
        else:
            ranges = value

        if not isinstance(ranges, list):
            ranges = []

        out[acc] = []
        for i, r in enumerate(ranges):
            if isinstance(r, dict):
                start, end = int(r["start"]), int(r["end"])
                label = r.get("label", f"IDR{i+1}")
            else:
                start, end = int(r[0]), int(r[1])
                label = f"IDR{i+1}"
            if start > end:
                start, end = end, start
            out[acc].append({"start": start, "end": end, "label": label})
    return out


def normalize_interactions(value) -> List[List[str]]:
    """Normalize master-DB folded-domain interactions like [["F1", "F2"], ...]."""
    if isinstance(value, dict):
        value = value.get("interactions", [])
    if not isinstance(value, list):
        return []
    out: List[List[str]] = []
    for pair in value:
        if isinstance(pair, (list, tuple)) and len(pair) == 2:
            out.append([str(pair[0]), str(pair[1])])
    return out


def folded_domains_from_idrs(idrs: List[dict], seq_len: int) -> List[Tuple[int, int]]:
    """Return folded/domain intervals between known IDRs using UniProt numbering."""
    ranges = sorted((int(r["start"]), int(r["end"])) for r in idrs)
    domains: List[Tuple[int, int]] = []
    if not ranges:
        return [(1, seq_len)]
    if ranges[0][0] > 1:
        domains.append((1, ranges[0][0] - 1))
    for (_, prev_end), (next_start, _) in zip(ranges, ranges[1:]):
        start = prev_end + 1
        end = next_start - 1
        if start <= end:
            domains.append((start, end))
    if ranges[-1][1] < seq_len:
        domains.append((ranges[-1][1] + 1, seq_len))
    return domains


def interaction_pair_set(interactions: Sequence[Sequence[str]]) -> set:
    pairs = set()
    for pair in normalize_interactions(list(interactions)):
        a, b = pair
        pairs.add(tuple(sorted((str(a), str(b)))))
    return pairs


def find_flanking_domain_indices_for_idr(idr_start: int, idr_end: int, domains: List[Tuple[int, int]]) -> Tuple[Optional[int], Optional[int]]:
    left = None
    right = None
    for idx, (dstart, dend) in enumerate(domains):
        if dend == idr_start - 1:
            left = idx
        if dstart == idr_end + 1:
            right = idx
    return left, right


def adjacent_pair_is_loop_tm(
    left_idx: int,
    right_idx: int,
    interactions: set,
    mean_pae: Optional[dict] = None,
    use_pae_fallback: bool = False,
    pae_cutoff: float = 8.0,
    ) -> bool:
        """Classify an internal IDR as LOOP if adjacent folded domains interact."""
        left_label = f"F{left_idx + 1}"
        right_label = f"F{right_idx + 1}"
        if tuple(sorted((left_label, right_label))) in interactions:
            return True
        if use_pae_fallback and isinstance(mean_pae, dict):
            for key in (f"{left_label}-{right_label}", f"{right_label}-{left_label}"):
                if key in mean_pae:
                    try:
                        return float(mean_pae[key]) <= float(pae_cutoff)
                    except Exception:
                        return False
        return False


def classify_idr_segments(
    idrs: List[dict],
    seq_len: int,
    interactions: Optional[Sequence[Sequence[str]]] = None,
    mean_pae: Optional[dict] = None,
    use_pae_fallback: bool = False,
    pae_cutoff: float = 8.0,
    ) -> List[dict]:
        """Classify IDRs as N/C/LINKER/LOOP.

        This mirrors the important part of build_hard_flex.py: an internal IDR is
        a LOOP only when its immediately flanking folded domains are an adjacent
        interacting F_i/F_{i+1} pair. Otherwise it remains a flexible LINKER.
        """
        typed = []
        domains = folded_domains_from_idrs(idrs, seq_len)
        interactions_set = interaction_pair_set(interactions or [])

        for r in sorted(idrs, key=lambda x: (int(x["start"]), int(x["end"]))):
            start, end = int(r["start"]), int(r["end"])
            kind = "LINKER"
            left_idx = None
            right_idx = None
            if start <= 1 and end >= seq_len:
                kind = "N+C"
            elif start <= 1:
                kind = "N"
            elif end >= seq_len:
                kind = "C"
            else:
                left_idx, right_idx = find_flanking_domain_indices_for_idr(start, end, domains)
                if left_idx is not None and right_idx is not None and right_idx == left_idx + 1:
                    if adjacent_pair_is_loop_tm(
                        left_idx,
                        right_idx,
                        interactions_set,
                        mean_pae=mean_pae,
                        use_pae_fallback=use_pae_fallback,
                        pae_cutoff=pae_cutoff,
                    ):
                        kind = "LOOP"
                    else:
                        kind = "LINKER"
                else:
                    kind = "LINKER"

            rr = dict(r)
            rr["kind"] = kind
            rr["label"] = rr.get("label", f"{kind}_{start}_{end}")
            if left_idx is not None:
                rr["left_domain"] = f"F{left_idx + 1}"
            if right_idx is not None:
                rr["right_domain"] = f"F{right_idx + 1}"
            typed.append(rr)
        return typed


def ensure_postprocess_dependencies() -> None:
    global PDBFixer
    global CustomExternalForce, LangevinIntegrator
    global ForceField, HBonds, NoCutoff, PDBFile, Simulation
    global angstrom, kelvin, kilocalories_per_mole, picosecond, picoseconds

    if PDBFixer is None:
        try:
            PDBFixer = importlib.import_module("pdbfixer").PDBFixer
        except Exception:
            PDBFixer = None

    if PDBFile is None:
        try:
            openmm_mod = importlib.import_module("openmm")
            openmm_app = importlib.import_module("openmm.app")
            openmm_unit = importlib.import_module("openmm.unit")
            CustomExternalForce = openmm_mod.CustomExternalForce
            LangevinIntegrator = openmm_mod.LangevinIntegrator
            ForceField = openmm_app.ForceField
            HBonds = openmm_app.HBonds
            NoCutoff = openmm_app.NoCutoff
            PDBFile = openmm_app.PDBFile
            Simulation = openmm_app.Simulation
            angstrom = openmm_unit.angstrom
            kelvin = openmm_unit.kelvin
            kilocalories_per_mole = openmm_unit.kilocalories_per_mole
            picosecond = openmm_unit.picosecond
            picoseconds = openmm_unit.picoseconds
        except Exception:
            PDBFile = None

    missing = []
    if PDBFixer is None:
        missing.append("pdbfixer")
    if PDBFile is None or ForceField is None or Simulation is None:
        missing.append("openmm")
    if missing:
        raise RuntimeError(
            "Post-processing requested, but required packages are unavailable: "
            + ", ".join(sorted(set(missing)))
        )


def add_hydrogens_pdbfixer(pdb_file: str, pH: float = 7.4) -> str:
    ensure_postprocess_dependencies()
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    out = os.path.join(folder, f"{name}_pro.pdb")

    fixer = PDBFixer(filename=pdb_file)
    fixer.findMissingResidues()
    fixer.findMissingAtoms()
    fixer.addMissingHydrogens(pH=pH)
    with open(out, "w") as handle:
        PDBFile.writeFile(fixer.topology, fixer.positions, handle)
    return out


def resolve_clash_openmm(pdb_file: str, max_iterations: int = 1000) -> str:
    ensure_postprocess_dependencies()
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    out = os.path.join(folder, f"{name}_cr.pdb")

    pdb = PDBFile(pdb_file)
    forcefield = ForceField("amber99sb.xml")
    system = forcefield.createSystem(pdb.topology, constraints=HBonds, nonbondedMethod=NoCutoff)

    sidechain_atoms = {atom.index for atom in pdb.topology.atoms() if atom.name not in ALIGN_ATOMS and atom.name not in {"O"}}
    k = 10.0 * kilocalories_per_mole / angstrom**2
    restraint = CustomExternalForce("0.5 * k * ((x - x0)^2 + (y - y0)^2 + (z - z0)^2)")
    restraint.addPerParticleParameter("x0")
    restraint.addPerParticleParameter("y0")
    restraint.addPerParticleParameter("z0")
    restraint.addGlobalParameter("k", k)

    for atom in pdb.topology.atoms():
        if atom.index not in sidechain_atoms:
            pos = pdb.positions[atom.index]
            restraint.addParticle(atom.index, [pos.x, pos.y, pos.z])
    system.addForce(restraint)

    integrator = LangevinIntegrator(300 * kelvin, 1 / picosecond, 0.002 * picoseconds)  # type: ignore
    sim = Simulation(pdb.topology, system, integrator)
    sim.context.setPositions(pdb.positions)
    sim.minimizeEnergy(maxIterations=max_iterations)

    positions = sim.context.getState(getPositions=True).getPositions()
    with open(out, "w") as handle:
        PDBFile.writeFile(sim.topology, positions, handle)
    return out


def alignment_pairs(ref_atoms: List[Atom], mov_atoms: List[Atom], idr_ranges: List[Tuple[int, int]], chain: str) -> Tuple[np.ndarray, np.ndarray, int]:
    ref = {
        (a.chain, a.resseq, a.name): a
        for a in ref_atoms
        if a.chain == chain and a.name in ALIGN_ATOMS and not in_any_idr(a.resseq, idr_ranges)
    }
    mov = {
        (a.chain, a.resseq, a.name): a
        for a in mov_atoms
        if a.chain == chain and a.name in ALIGN_ATOMS and not in_any_idr(a.resseq, idr_ranges)
    }
    keys = sorted(set(ref.keys()).intersection(mov.keys()))
    if len(keys) < 3:
        return np.zeros((0, 3)), np.zeros((0, 3)), 0
    mov_xyz = np.array([mov[k].xyz for k in keys], dtype=float)
    ref_xyz = np.array([ref[k].xyz for k in keys], dtype=float)
    return mov_xyz, ref_xyz, len(keys)


def in_any_idr(pos: int, ranges: List[Tuple[int, int]]) -> bool:
    return any(s <= pos <= e for s, e in ranges)


def align_folded_conformers(pdb_files: List[str], idrs: List[dict], chain: str = "A", min_common_atoms: int = 20) -> List[str]:
    if not pdb_files:
        return []
    idr_ranges = [(int(r["start"]), int(r["end"])) for r in idrs]
    ref_file = pdb_files[0]
    ref_atoms = parse_pdb(ref_file, chain=None, include_hetatm=False)
    aligned = []

    for pdb in pdb_files:
        mov_atoms_chain = parse_pdb(pdb, chain=None, include_hetatm=False)
        mov_xyz, ref_xyz, ncommon = alignment_pairs(ref_atoms, mov_atoms_chain, idr_ranges, chain)
        if ncommon < min_common_atoms:
            print(f"[WARN] {os.path.basename(pdb)} has only {ncommon} common folded atoms; skipping alignment", file=sys.stderr)
            aligned.append(pdb)
            continue
        try:
            R, t, _ = kabsch(mov_xyz, ref_xyz)
            transformed = rotate_atoms(mov_atoms_chain, R, t)
            out = os.path.splitext(pdb)[0] + "_ali.pdb"
            write_pdb(transformed, out, remarks=["Folded-region aligned conformer"]) 
            aligned.append(out)
        except Exception as exc:
            print(f"[WARN] Failed folded alignment for {pdb}: {exc}", file=sys.stderr)
            aligned.append(pdb)
    return aligned


def write_multimodel_pdb(model_files: List[str], out_path: str) -> None:
    with open(out_path, "w") as out:
        for idx, pdb in enumerate(model_files, start=1):
            out.write(f"MODEL     {idx:4d}\n")
            with open(pdb, errors="ignore") as handle:
                for line in handle:
                    if line.startswith("ATOM") or line.startswith("HETATM"):
                        out.write(line)
            out.write("ENDMDL\n")
        out.write("END\n")


def postprocess_and_ensemble(acc: str, out_prot: str, idrs: List[dict], args) -> Optional[str]:
    raw = sorted(glob.glob(os.path.join(out_prot, f"{acc}_tmidr_*.pdb")))
    if not raw:
        return None
    if not args.run_postprocess:
        return None

    ensure_postprocess_dependencies()
    print(f"[INFO] Post-processing {acc}: protonation + minimization + alignment + ensemble", file=sys.stderr)

    pro_files = []
    for pdb in raw:
        pro = add_hydrogens_pdbfixer(pdb, pH=args.postprocess_ph)
        pro_files.append(pro)
        if not args.keep_postprocess_intermediates and os.path.exists(pdb):
            os.remove(pdb)

    min_files = []
    for pdb in pro_files:
        cr = resolve_clash_openmm(pdb, max_iterations=args.openmm_max_iterations)
        min_files.append(cr)
        if not args.keep_postprocess_intermediates and os.path.exists(pdb):
            os.remove(pdb)

    aligned = align_folded_conformers(min_files, idrs, chain=args.align_chain, min_common_atoms=args.align_min_common_atoms)
    if not args.keep_postprocess_intermediates:
        for p in min_files:
            if p not in aligned and os.path.exists(p):
                os.remove(p)

    ensemble_path = os.path.join(out_prot, f"{acc}_tmidr_n{len(aligned)}_aligned_ensemble.pdb")
    write_multimodel_pdb(aligned, ensemble_path)
    return ensemble_path


def cleanup_protein_output(out_prot: str, acc: str, ensemble_path: Optional[str], args) -> None:
    """Keep only the final ensemble PDB and membrane-frame JSON in a successful protein folder.

    Failure folders are left untouched so build_summary.csv and intermediate files remain
    available for debugging.  This cleanup intentionally runs only after a final
    ensemble PDB exists and --clean-final-output is enabled.
    """
    if not getattr(args, "clean_final_output", True):
        return
    if not ensemble_path or not os.path.isfile(ensemble_path):
        return

    keep = {
        os.path.abspath(ensemble_path),
        os.path.abspath(os.path.join(out_prot, f"{acc}_membrane_frame.json")),
    }
    for entry in os.listdir(out_prot):
        path = os.path.join(out_prot, entry)
        abspath = os.path.abspath(path)
        if abspath in keep:
            continue
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        else:
            try:
                os.remove(path)
            except FileNotFoundError:
                pass


def residue_sequence_from_template(atoms: List[Atom]) -> Dict[int, str]:
    seq = {}
    for a in atoms:
        if a.resname in AA3_TO_1:
            seq[a.resseq] = AA3_TO_1[a.resname]
    return seq


def find_template_path(template_dir: str, acc: str) -> Optional[str]:
    pats = [
        f"{acc}.pdb", f"{acc}.cif", f"{acc}.mmcif",
        f"AF-{acc}-F1-model_v4.pdb", f"AF-{acc}-F1-model_v3.pdb",
        f"*{acc}*.pdb",
    ]
    for pat in pats:
        hits = sorted(glob.glob(os.path.join(template_dir, pat)))
        if hits:
            if hits[0].endswith(('.cif', '.mmcif')):
                print(f"[WARN] mmCIF found for {acc} but this script parses PDB only: {hits[0]}", file=sys.stderr)
                continue
            return hits[0]
    return None


def interval_contains(ranges: List[dict], pos: int) -> bool:
    return any(r["start"] <= pos <= r["end"] for r in ranges)


def overlap_any(start: int, end: int, ranges: List[Tuple[int, int]]) -> bool:
    return any(max(start, a) <= min(end, b) for a, b in ranges)


def overlap_interval(a: Tuple[int, int], b: Tuple[int, int]) -> Optional[Tuple[int, int]]:
    start = max(a[0], b[0])
    end = min(a[1], b[1])
    if start <= end:
        return (start, end)
    return None


def is_small_tm_edge_overlap(overlap: Tuple[int, int], tm: Tuple[int, int], edge_tolerance: int) -> bool:
    if edge_tolerance <= 0:
        return False
    overlap_len = overlap[1] - overlap[0] + 1
    if overlap_len > edge_tolerance:
        return False
    left_edge_limit = tm[0] + edge_tolerance - 1
    right_edge_limit = tm[1] - edge_tolerance + 1
    return overlap[1] <= left_edge_limit or overlap[0] >= right_edge_limit


def idr_tm_conflicts(start: int, end: int, tm_segments: List[Tuple[int, int]], edge_tolerance: int) -> List[dict]:
    """Return IDR/TM overlaps that are not tolerated small TM-edge overlaps."""
    bad = []
    idr = (int(start), int(end))
    for tm_idx, tm in enumerate(tm_segments, start=1):
        ov = overlap_interval(idr, tm)
        if ov is None:
            continue
        if is_small_tm_edge_overlap(ov, tm, edge_tolerance):
            continue
        bad.append({
            "tm_index": tm_idx,
            "tm_start": int(tm[0]),
            "tm_end": int(tm[1]),
            "overlap_start": int(ov[0]),
            "overlap_end": int(ov[1]),
            "overlap_length": int(ov[1] - ov[0] + 1),
        })
    return bad


def parse_intervals(items: List[dict]) -> List[Tuple[int, int]]:
    out = []
    for x in items or []:
        try:
            out.append((int(x["start"]), int(x["end"])))
        except Exception:
            pass
    return out


def infer_membrane_frame(atoms: List[Atom], tm_segments: List[Tuple[int, int]], topology_labels: Optional[str] = None,
                         core_half_default: float = 15.0, head_half_default: float = 22.0) -> Tuple[List[Atom], dict]:
    """Orient predicted TM helix axes along z and center the membrane at z=0."""
    ca_by_res = {a.resseq: a.xyz for a in atoms if a.name == "CA"}
    vectors = []
    tm_cas = []
    for start, end in tm_segments:
        pts = [(res, ca_by_res[res]) for res in range(start, end + 1) if res in ca_by_res]
        if len(pts) < 4:
            continue
        coords = np.array([p[1] for p in pts])
        tm_cas.extend(list(coords))
        # PCA axis for helix/strand segment.
        X = coords - coords.mean(axis=0)
        _, _, vt = np.linalg.svd(X, full_matrices=False)
        v = vt[0]
        # Orient roughly from N to C so multiple helices do not cancel.
        nc = coords[-1] - coords[0]
        if np.dot(v, nc) < 0:
            v = -v
        vectors.append(v)
    if not vectors:
        print("[WARN] Could not infer TM orientation from template; leaving coordinates as-is and using z=0 membrane.", file=sys.stderr)
        frame = {
            "auto_oriented": False,
            "normal": [0.0, 0.0, 1.0], "midplane_z": 0.0,
            "core_half_thickness": core_half_default, "head_half_thickness": head_half_default, "slab_model": "POPC_PROBABILISTIC", "popc_reference": "DB~39.1A and 2DC~28.8A at 30C",
            "inside_sign": None, "outside_sign": None,
        }
        return atoms, frame
    normal = np.mean(np.array(vectors), axis=0)
    normal = normal / (np.linalg.norm(normal) + 1e-12)
    R = rotation_matrix_from_vectors(normal, np.array([0.0, 0.0, 1.0]))
    rotated = rotate_atoms(atoms, R, np.zeros(3))
    tm_z = []
    for a in rotated:
        if a.name == "CA" and any(s <= a.resseq <= e for s, e in tm_segments):
            tm_z.append(a.z)
    mid = float(np.median(tm_z)) if tm_z else 0.0
    centered = [a.with_xyz([a.x, a.y, a.z - mid]) for a in rotated]

    inside_sign = None
    outside_sign = None
    if topology_labels:
        inside_z, outside_z = [], []
        for a in centered:
            if a.name != "CA":
                continue
            idx = a.resseq - 1
            if 0 <= idx < len(topology_labels):
                lab = topology_labels[idx].upper()
                if lab == "I":
                    inside_z.append(a.z)
                elif lab == "O":
                    outside_z.append(a.z)
        if len(inside_z) >= 3 and len(outside_z) >= 3:
            mi, mo = float(np.mean(inside_z)), float(np.mean(outside_z))
            if abs(mi - mo) > 3.0:
                inside_sign = 1 if mi > mo else -1
                outside_sign = -inside_sign

    frame = {
        "auto_oriented": True,
        "normal_pre_rotation": normal.tolist(),
        "normal": [0.0, 0.0, 1.0],
        "midplane_z": 0.0,
        "core_half_thickness": core_half_default,
        "head_half_thickness": head_half_default,
        "inside_sign": inside_sign,
        "outside_sign": outside_sign,
    }
    return centered, frame


def write_seq_fasta(seq: str, path: str, name: str = "fragment") -> None:
    with open(path, "w") as out:
        out.write(f">{name}\n")
        for i in range(0, len(seq), 80):
            out.write(seq[i:i+80] + "\n")


def run_idpcg_build(seq: str, n: int, outdir: str, db: str, cmd: str, workers: int, extra: str = "") -> None:
    Path(outdir).mkdir(parents=True, exist_ok=True)
    fasta = os.path.join(outdir, "fragment.fasta")
    write_seq_fasta(seq, fasta)
    parts = shlex.split(cmd)
    full = parts + ["build", "-db", db, "-seq", fasta, "-nc", str(n), "-of", outdir]
    extra_tokens = shlex.split(extra) if extra else []
    if extra:
        full += extra_tokens
    else:
        full += ["--dloop-off", "--dany"]

    # Use IDPConfGen internal multiprocessing only; outer protein loop remains serial.
    if "-n" not in extra_tokens and "--n" not in extra_tokens:
        full += ["-n", str(max(1, int(workers)))]

    print("[INFO] Running IDPConfGen:", " ".join(shlex.quote(x) for x in full), file=sys.stderr)
    subprocess.run(full, check=True)


_IDPCG_PY: Optional[dict] = None


def get_idpcg_python_helpers() -> dict:
    """Import IDPConformerGenerator Python helpers lazily.

    Terminal/linker cases only need the IDPConfGen CLI. LOOP closure needs the
    same helper machinery as build_hard_flex.py: Structure arrays, align_coords,
    count_clashes, next_seeker, and pool_function.
    """
    global _IDPCG_PY
    if _IDPCG_PY is None:
        try:
            from idpconfgen import Path as IDPPath  # type: ignore
            from idpconfgen.libs.libmulticore import pool_function  # type: ignore
            from idpconfgen.libs.libstructure import (  # type: ignore
                Structure,
                col_chainID,
                col_name,
                col_resSeq,
                col_serial,
                col_segid,
                cols_coords,
                parse_pdb_to_array,
                structure_to_pdb,
                write_PDB,
            )
            from idpconfgen.ldrs_helper import align_coords, count_clashes, next_seeker  # type: ignore
        except Exception as exc:
            raise RuntimeError(
                "Hard LOOP closure requires IDPConformerGenerator Python modules "
                "(idpconfgen.ldrs_helper.align_coords/count_clashes/next_seeker). "
                f"Import failed: {exc}"
            ) from exc
        _IDPCG_PY = {
            "IDPPath": IDPPath,
            "Structure": Structure,
            "pool_function": pool_function,
            "col_chainID": col_chainID,
            "col_name": col_name,
            "col_resSeq": col_resSeq,
            "col_serial": col_serial,
            "col_segid": col_segid,
            "cols_coords": cols_coords,
            "parse_pdb_to_array": parse_pdb_to_array,
            "structure_to_pdb": structure_to_pdb,
            "write_PDB": write_PDB,
            "align_coords": align_coords,
            "count_clashes": count_clashes,
            "next_seeker": next_seeker,
        }
    return _IDPCG_PY


def idpcg_load_structure(pdb_path: str) -> Tuple[Any, np.ndarray]:
    h = get_idpcg_python_helpers()
    struc = h["Structure"](h["IDPPath"](pdb_path))
    struc.build()
    return struc, np.array(struc.data_array, copy=True)


def idpcg_parse_candidate_array(candidate_pdb: str) -> Optional[np.ndarray]:
    h = get_idpcg_python_helpers()
    with open(candidate_pdb) as handle:
        pdb_data = handle.read()
    try:
        return np.array(h["parse_pdb_to_array"](pdb_data), copy=True)
    except AssertionError:
        return None


def idpcg_save_array(arr: np.ndarray, outpath: str) -> None:
    h = get_idpcg_python_helpers()
    arr = np.array(arr, copy=True)
    if len(arr):
        arr[:, h["col_serial"]] = [str(i) for i in range(1, len(arr) + 1)]
        arr[:, h["col_segid"]] = ""
    h["write_PDB"](h["structure_to_pdb"](arr), outpath)


def idpcg_get_atom_index(arr: np.ndarray, resseq: int, atom_name: str) -> int:
    h = get_idpcg_python_helpers()
    resnums = arr[:, h["col_resSeq"]].astype(int)
    names = arr[:, h["col_name"]]
    hits = np.where((resnums == int(resseq)) & (names == atom_name))[0]
    if len(hits) == 0:
        raise ValueError(f"Could not find atom {atom_name} in residue {resseq} for LOOP anchor.")
    return int(hits[0])


def idpcg_get_loop_anchor_coords(scaffold_arr: np.ndarray, start: int, end: int) -> Tuple[np.ndarray, np.ndarray]:
    """Return hard-flex-style lower/upper 3-atom anchors for LOOP start..end."""
    h = get_idpcg_python_helpers()
    lower = int(start) - 1
    upper = int(end) + 1
    lower_coords = np.array(
        [
            scaffold_arr[idpcg_get_atom_index(scaffold_arr, lower - 1, "C")][h["cols_coords"]].astype(float),
            scaffold_arr[idpcg_get_atom_index(scaffold_arr, lower, "N")][h["cols_coords"]].astype(float),
            scaffold_arr[idpcg_get_atom_index(scaffold_arr, lower, "CA")][h["cols_coords"]].astype(float),
        ]
    )
    upper_coords = np.array(
        [
            scaffold_arr[idpcg_get_atom_index(scaffold_arr, upper, "C")][h["cols_coords"]].astype(float),
            scaffold_arr[idpcg_get_atom_index(scaffold_arr, upper + 1, "N")][h["cols_coords"]].astype(float),
            scaffold_arr[idpcg_get_atom_index(scaffold_arr, upper + 1, "CA")][h["cols_coords"]].astype(float),
        ]
    )
    return lower_coords, upper_coords


def idpcg_atom_clash_count(
    arr_a: np.ndarray,
    arr_b: np.ndarray,
    *,
    cutoff: float = 1.35,
    max_count: int = 20,
    ignore_adjacent_residues: bool = True,
    chunk_size: int = 256,
) -> int:
    """Small hard-flex-style array close-contact counter for loop inserts."""
    h = get_idpcg_python_helpers()
    if len(arr_a) == 0 or len(arr_b) == 0:
        return 0
    coords_a = arr_a[:, h["cols_coords"]].astype(float)
    coords_b = arr_b[:, h["cols_coords"]].astype(float)
    res_a = arr_a[:, h["col_resSeq"]].astype(int)
    res_b = arr_b[:, h["col_resSeq"]].astype(int)
    cutoff2 = float(cutoff) * float(cutoff)
    count = 0
    for start in range(0, len(coords_a), chunk_size):
        end = min(start + chunk_size, len(coords_a))
        diff = coords_a[start:end, None, :] - coords_b[None, :, :]
        d2 = np.sum(diff * diff, axis=2)
        mask = d2 < cutoff2
        if ignore_adjacent_residues:
            sep = np.abs(res_a[start:end, None] - res_b[None, :])
            mask &= sep > 1
        count += int(np.count_nonzero(mask))
        if count > max_count:
            return count
    return count


def idpcg_loop_break_attach(
    candidate_pdb: str,
    *,
    scaffold_pdb: str,
    start: int,
    end: int,
    run_tag: str,
    output_lower: Optional[str],
    output_upper: Optional[str],
    loop_anchor_max_clash: int,
    loop_anchor_tolerance: float,
    ) -> None:
        """Align one raw loop candidate to lower and/or upper anchors, as in build_hard_flex.py."""
        if output_lower is None and output_upper is None:
            return
        h = get_idpcg_python_helpers()
        scaffold_struc, scaffold_arr = idpcg_load_structure(scaffold_pdb)
        lower_coords, upper_coords = idpcg_get_loop_anchor_coords(scaffold_arr, start, end)
        candidate_arr = idpcg_parse_candidate_array(candidate_pdb)
        if candidate_arr is None:
            return
        stem = Path(candidate_pdb).stem
        if output_lower is not None:
            aligned_lower = h["align_coords"](candidate_arr, lower_coords, "C-IDR")
            clashes_lower, fragment_lower = h["count_clashes"](
                aligned_lower,
                scaffold_struc,
                "C-IDR",
                max_clash=int(loop_anchor_max_clash),
                tolerance=float(loop_anchor_tolerance),
            )
            if type(clashes_lower) is int:
                idpcg_save_array(fragment_lower, os.path.join(output_lower, f"{run_tag}_L_{stem}.pdb"))
        if output_upper is not None:
            aligned_upper = h["align_coords"](candidate_arr, upper_coords, "N-IDR")
            clashes_upper, fragment_upper = h["count_clashes"](
                aligned_upper,
                scaffold_struc,
                "N-IDR",
                max_clash=int(loop_anchor_max_clash),
                tolerance=float(loop_anchor_tolerance),
            )
            if type(clashes_upper) is int:
                idpcg_save_array(fragment_upper, os.path.join(output_upper, f"{run_tag}_U_{stem}.pdb"))


def idpcg_extract_loop_insert_arr(
    loop_candidate_pdb: str,
    *,
    start: int,
    end: int,
    local_offset: int,
    chain_id: str,
    ) -> Optional[np.ndarray]:
        """Extract only original residues start..end from a joined LOOP bridge."""
        h = get_idpcg_python_helpers()
        arr = idpcg_parse_candidate_array(loop_candidate_pdb)
        if arr is None or len(arr) == 0:
            return None
        local_res = arr[:, h["col_resSeq"]].astype(int)
        orig_res = local_res + int(local_offset)
        mask = (orig_res >= int(start)) & (orig_res <= int(end))
        if not np.any(mask):
            orig_res = local_res
            mask = (orig_res >= int(start)) & (orig_res <= int(end))
        if not np.any(mask):
            return None
        insert = np.array(arr[mask], copy=True)
        insert[:, h["col_resSeq"]] = orig_res[mask].astype(str)
        insert[:, h["col_chainID"]] = chain_id
        if len(insert):
            insert[:, h["col_serial"]] = [str(i) for i in range(1, len(insert) + 1)]
            insert[:, h["col_segid"]] = ""
        return insert


def idpcg_evaluate_joined_loop_candidate(
    joined_pdb: str,
    *,
    start: int,
    end: int,
    local_offset: int,
    chain_id: str,
    scaffold_arr: np.ndarray,
    loop_atom_clash_cutoff: float,
    loop_max_atom_clashes: int,
    ) -> Optional[np.ndarray]:
        insert_arr = idpcg_extract_loop_insert_arr(
            joined_pdb,
            start=start,
            end=end,
            local_offset=local_offset,
            chain_id=chain_id,
        )
        if insert_arr is None:
            return None
        nbad = idpcg_atom_clash_count(
            insert_arr,
            scaffold_arr,
            cutoff=float(loop_atom_clash_cutoff),
            max_count=int(loop_max_atom_clashes),
        )
        if nbad > int(loop_max_atom_clashes):
            return None
        return insert_arr


def hard_loop_sequence_with_offset(full_sequence: str, start: int, end: int) -> Tuple[str, int]:
    """Return sequence start-2..end+2 and local->UniProt residue offset."""
    seq_start = int(start) - 2
    seq_end = int(end) + 2
    if seq_start < 1 or seq_end > len(full_sequence):
        raise ValueError(
            f"LOOP {start}-{end} cannot use required 2-residue overhangs "
            f"for sequence length {len(full_sequence)}."
        )
    return full_sequence[seq_start - 1:seq_end], seq_start - 1


def prepare_hard_loop_closures_for_idr(
    acc: str,
    idr: dict,
    full_sequence: str,
    fixed_pdb: str,
    args,
    ) -> List[List[Atom]]:
        """Build closed LOOP-IDR inserts using the build_hard_flex.py next_seeker strategy."""
        h = get_idpcg_python_helpers()
        start, end = int(idr["start"]), int(idr["end"])
        loop_seq, local_offset = hard_loop_sequence_with_offset(full_sequence, start, end)
        root = os.path.join(args.workdir, "hard_loop_fragments", acc, f"loop_{start}_{end}")
        raw_dir = os.path.join(root, "raw")
        lower_dir = os.path.join(root, "lower")
        upper_dir = os.path.join(root, "upper")
        joined_dir = os.path.join(root, "joined")
        library_dir = os.path.join(root, "library")
        archive_lower_dir = os.path.join(root, "lower_archive")
        archive_upper_dir = os.path.join(root, "upper_archive")
        for folder in (raw_dir, lower_dir, upper_dir, joined_dir, library_dir, archive_lower_dir, archive_upper_dir):
            Path(folder).mkdir(parents=True, exist_ok=True)
        if not args.reuse_loop_libraries:
            for folder in (raw_dir, lower_dir, upper_dir, joined_dir, library_dir, archive_lower_dir, archive_upper_dir):
                for p in Path(folder).glob("*.pdb"):
                    p.unlink()

        existing = sorted(glob.glob(os.path.join(library_dir, "*.pdb")))
        target_n = max(1, int(args.hard_loop_unique_target))
        if len(existing) >= target_n:
            print(f"[INFO] {acc} LOOP {start}-{end}: reusing {len(existing[:target_n])} closed loop insert(s)", file=sys.stderr)
            return [mark_atoms_source(parse_pdb(p, chain=None, include_hetatm=False), source="idr", chain=args.chain) for p in existing[:target_n]]

        _, scaffold_arr = idpcg_load_structure(fixed_pdb)
        if len(scaffold_arr) == 0:
            return []
        chain_id = str(scaffold_arr[0, h["col_chainID"]]) or args.chain or "A"

        library_paths: List[str] = list(existing)
        lower_archive: List[str] = sorted(glob.glob(os.path.join(archive_lower_dir, "*.pdb")))
        upper_archive: List[str] = sorted(glob.glob(os.path.join(archive_upper_dir, "*.pdb")))
        rng = random.Random(args.seed + start * 1009 + end)

        print(
            f"[INFO] {acc} LOOP {start}-{end}: hard-flex closure target={target_n}, "
            f"batch_nc={args.hard_loop_batch_size}",
            file=sys.stderr,
        )

        for batch_idx in range(int(args.hard_loop_max_batches)):
            # Clear transient dirs only.
            for folder in (raw_dir, lower_dir, upper_dir, joined_dir):
                for p in Path(folder).glob("*.pdb"):
                    p.unlink()
            run_idpcg_build(
                loop_seq,
                int(args.hard_loop_batch_size),
                raw_dir,
                args.idpcg_db,
                args.idpcg_cmd,
                args.n_workers,
                args.idpcg_extra,
            )
            raw_candidates = sorted(glob.glob(os.path.join(raw_dir, "*.pdb")))
            if not raw_candidates:
                continue
            run_tag = f"b{batch_idx:03d}"
            lower_exec = partial(
                idpcg_loop_break_attach,
                scaffold_pdb=fixed_pdb,
                start=start,
                end=end,
                run_tag=run_tag,
                output_lower=lower_dir,
                output_upper=None,
                loop_anchor_max_clash=args.loop_anchor_max_clash,
                loop_anchor_tolerance=args.loop_anchor_tolerance,
            )
            for _ in h["pool_function"](lower_exec, raw_candidates, ncores=max(1, int(args.n_workers))):
                pass
            upper_exec = partial(
                idpcg_loop_break_attach,
                scaffold_pdb=fixed_pdb,
                start=start,
                end=end,
                run_tag=run_tag,
                output_lower=None,
                output_upper=upper_dir,
                loop_anchor_max_clash=args.loop_anchor_max_clash,
                loop_anchor_tolerance=args.loop_anchor_tolerance,
            )
            for _ in h["pool_function"](upper_exec, raw_candidates, ncores=max(1, int(args.n_workers))):
                pass

            lower_candidates = sorted(glob.glob(os.path.join(lower_dir, "*.pdb")))
            upper_candidates = sorted(glob.glob(os.path.join(upper_dir, "*.pdb")))
            for src in lower_candidates:
                dst = os.path.join(archive_lower_dir, os.path.basename(src))
                if not os.path.exists(dst):
                    Path(dst).write_bytes(Path(src).read_bytes())
            for src in upper_candidates:
                dst = os.path.join(archive_upper_dir, os.path.basename(src))
                if not os.path.exists(dst):
                    Path(dst).write_bytes(Path(src).read_bytes())
            lower_archive = sorted(glob.glob(os.path.join(archive_lower_dir, "*.pdb")))
            upper_archive = sorted(glob.glob(os.path.join(archive_upper_dir, "*.pdb")))
            # Bound the archive so very long runs do not explode disk usage.
            cap = max(int(args.loop_join_archive_min), int(args.loop_join_cap_min), target_n * 20)
            for archive in (lower_archive, upper_archive):
                if len(archive) > cap:
                    keep = set(rng.sample(archive, cap))
                    for p in archive:
                        if p not in keep and os.path.exists(p):
                            os.remove(p)
            lower_archive = sorted(glob.glob(os.path.join(archive_lower_dir, "*.pdb")))
            upper_archive = sorted(glob.glob(os.path.join(archive_upper_dir, "*.pdb")))

            join_cap = min(max(int(args.loop_join_cap_min), target_n * int(args.loop_join_search_factor)), len(lower_archive), len(upper_archive))
            lower_for_join = rng.sample(lower_archive, join_cap) if join_cap and len(lower_archive) > join_cap else lower_archive
            upper_for_join = rng.sample(upper_archive, join_cap) if join_cap and len(upper_archive) > join_cap else upper_archive
            if lower_for_join and upper_for_join:
                join_exec = partial(
                    h["next_seeker"],
                    nterm_idr_lib=upper_for_join,
                    max_clash=int(args.loop_join_max_clash),
                    tolerance=float(args.loop_join_tolerance),
                    output_folder=joined_dir,
                )
                for _ in h["pool_function"](join_exec, lower_for_join, ncores=max(1, int(args.n_workers))):
                    pass

            joined = sorted(glob.glob(os.path.join(joined_dir, "*.pdb")))
            rng.shuffle(joined)
            eval_exec = partial(
                idpcg_evaluate_joined_loop_candidate,
                start=start,
                end=end,
                local_offset=local_offset,
                chain_id=chain_id,
                scaffold_arr=scaffold_arr,
                loop_atom_clash_cutoff=args.loop_atom_clash_cutoff,
                loop_max_atom_clashes=args.loop_max_atom_clashes,
            )
            accepted = [arr for arr in h["pool_function"](eval_exec, joined, ncores=max(1, int(args.n_workers))) if arr is not None]
            before = len(library_paths)
            for insert_arr in accepted:
                if len(library_paths) >= target_n:
                    break
                lib_path = os.path.join(library_dir, f"loop_{start}_{end}_candidate_{len(library_paths) + 1:05d}.pdb")
                idpcg_save_array(insert_arr, lib_path)
                library_paths.append(lib_path)
            print(
                f"[INFO] {acc} LOOP {start}-{end}: batch={batch_idx + 1}, raw={len(raw_candidates)}, "
                f"lower={len(lower_candidates)}, upper={len(upper_candidates)}, joined={len(joined)}, "
                f"library={len(library_paths)}/{target_n}, archive=({len(lower_archive)},{len(upper_archive)})",
                file=sys.stderr,
            )
            if len(library_paths) >= target_n:
                break
            if len(library_paths) > before and len(library_paths) >= int(args.min_hard_loop_unique_required):
                # Finish-if-doable: a tiny true closed-loop library can be reused.
                break

        if len(library_paths) < int(args.min_hard_loop_unique_required):
            if args.loop_closure_fallback_to_kabsch:
                print(
                    f"[WARN] {acc} LOOP {start}-{end}: hard LOOP closure produced {len(library_paths)} inserts; "
                    "falling back to Kabsch flank-fragment mode.",
                    file=sys.stderr,
                )
                return prepare_fragments_for_idr(acc, idr, full_sequence, parse_pdb(fixed_pdb, chain=None), args)
            return []

        if len(library_paths) < target_n:
            print(
                f"[WARN] {acc} LOOP {start}-{end}: only {len(library_paths)}/{target_n} unique closed LOOP insert(s); "
                "they will be reused across output conformers.",
                file=sys.stderr,
            )
        return [mark_atoms_source(parse_pdb(p, chain=None, include_hetatm=False), source="idr", chain=args.chain) for p in library_paths]


def mark_atoms_source(atoms: List[Atom], source: str = "idr", chain: Optional[str] = None) -> List[Atom]:
    """Return atoms marked as inserted IDR atoms, optionally forcing chain ID."""
    out: List[Atom] = []
    for a in atoms:
        out.append(replace(a, source=source, chain=(chain or a.chain or "A")))
    return out


def collect_pdbs(path: str) -> List[str]:
    return sorted(glob.glob(os.path.join(path, "*.pdb"))) + sorted(glob.glob(os.path.join(path, "*", "*.pdb")))


def get_atom_map(atoms: List[Atom]) -> Dict[Tuple[int, str], Atom]:
    return {(a.resseq, a.name): a for a in atoms if a.record == "ATOM" or a.source in {"template", "idr"}}


def residue_atoms(atoms: List[Atom], resseq: int) -> List[Atom]:
    return [a for a in atoms if a.resseq == resseq]


def fragment_window_for_idr(acc: str, idr: dict, full_sequence: str, args) -> Optional[Tuple[int, int, int, int, str]]:
    """Return IDR/window coordinates and the flanked fragment sequence."""
    start, end = int(idr["start"]), int(idr["end"])
    flank = int(args.anchor_flank)
    win_start = max(1, start - flank)
    win_end = min(len(full_sequence), end + flank)
    window_seq = full_sequence[win_start - 1:win_end]
    if not window_seq or not all(c.isalpha() for c in window_seq):
        print(f"[WARN] Bad window sequence for {acc} {start}-{end}", file=sys.stderr)
        return None
    return start, end, win_start, win_end, window_seq


def align_fragment_pdbs_for_idr(
    acc: str,
    idr: dict,
    full_sequence: str,
    template_atoms: List[Atom],
    args,
    pdbs: List[str],
    *,
    log_prefix: str = "",
    ) -> List[List[Atom]]:
        """Align raw IDPConfGen fragment PDBs onto the template flanks and extract the IDR atoms."""
        ctx = fragment_window_for_idr(acc, idr, full_sequence, args)
        if ctx is None:
            return []
        start, end, win_start, win_end, _window_seq = ctx
        if not pdbs:
            return []

        template_map = get_atom_map(template_atoms)
        aligned_idr_atoms: List[List[Atom]] = []
        anchor_full_positions = list(range(win_start, start)) + list(range(end + 1, win_end + 1))
        anchor_names = ["N", "CA", "C"]

        for pdb in pdbs:
            frag_atoms = parse_pdb(pdb, chain=None, include_hetatm=False)
            if not frag_atoms:
                continue
            # IDPConfGen fragments usually start at residue 1. Map frag residue i to full position win_start+i-1.
            frag_pairs = []
            templ_pairs = []
            for full_pos in anchor_full_positions:
                frag_pos = full_pos - win_start + 1
                for aname in anchor_names:
                    fa = next((a for a in frag_atoms if a.resseq == frag_pos and a.name == aname), None)
                    ta = template_map.get((full_pos, aname))
                    if fa is not None and ta is not None:
                        frag_pairs.append(fa.xyz)
                        templ_pairs.append(ta.xyz)
            if len(frag_pairs) < 3:
                continue
            try:
                R, t, rmsd = kabsch(np.array(frag_pairs), np.array(templ_pairs))
            except Exception:
                continue
            if rmsd > args.anchor_rmsd_max:
                continue
            transformed = rotate_atoms(frag_atoms, R, t)
            idr_atoms = []
            for a in transformed:
                full_pos = win_start + a.resseq - 1
                if start <= full_pos <= end:
                    aa = full_sequence[full_pos - 1]
                    idr_atoms.append(replace(a, resseq=full_pos, resname=AA1_TO_3.get(aa, a.resname), chain=args.chain or a.chain or "A", source="idr"))
            if not idr_atoms:
                continue
            if not junctions_ok(template_atoms, idr_atoms, start, end, args.junction_min, args.junction_max):
                continue
            aligned_idr_atoms.append(idr_atoms)

        prefix = f" {log_prefix}" if log_prefix else ""
        print(
            f"[INFO] {acc} IDR {start}-{end}{prefix}: "
            f"{len(aligned_idr_atoms)}/{len(pdbs)} fragments passed anchor/junction checks",
            file=sys.stderr,
        )
        return aligned_idr_atoms


def prepare_fragments_for_idr(acc: str, idr: dict, full_sequence: str, template_atoms: List[Atom], args) -> List[List[Atom]]:
    ctx = fragment_window_for_idr(acc, idr, full_sequence, args)
    if ctx is None:
        return []
    start, end, _win_start, _win_end, window_seq = ctx

    frag_dir = os.path.join(args.workdir, "fragments", acc, f"idr_{start}_{end}")
    pdbs = collect_pdbs(frag_dir)
    if len(pdbs) < args.fragment_pool_size:
        run_idpcg_build(
            window_seq,
            args.fragment_pool_size,
            frag_dir,
            args.idpcg_db,
            args.idpcg_cmd,
            args.n_workers,
            args.idpcg_extra,
        )
        pdbs = collect_pdbs(frag_dir)
    if not pdbs:
        print(f"[WARN] No fragment PDBs generated for {acc} IDR {start}-{end}", file=sys.stderr)
        return []

    return align_fragment_pdbs_for_idr(
        acc,
        idr,
        full_sequence,
        template_atoms,
        args,
        pdbs,
        log_prefix="initial pool",
    )


def _next_fragment_resample_dir(frag_dir: str) -> str:
    """Return a new one-level batch folder so collect_pdbs(frag_dir) can reuse it on later runs."""
    Path(frag_dir).mkdir(parents=True, exist_ok=True)
    batch_idx = 1
    while True:
        out = os.path.join(frag_dir, f"resample_{batch_idx:04d}")
        if not os.path.exists(out):
            return out
        batch_idx += 1


def sample_additional_fragments_for_idr(
    acc: str,
    idr: dict,
    full_sequence: str,
    template_atoms: List[Atom],
    args,
    *,
    batch_size: Optional[int] = None,
    ) -> List[List[Atom]]:
        """Launch one extra IDPConfGen batch and return newly aligned fragments."""
        ctx = fragment_window_for_idr(acc, idr, full_sequence, args)
        if ctx is None:
            return []
        start, end, _win_start, _win_end, window_seq = ctx
        frag_dir = os.path.join(args.workdir, "fragments", acc, f"idr_{start}_{end}")
        outdir = _next_fragment_resample_dir(frag_dir)
        nraw = max(1, int(batch_size if batch_size is not None else args.fragment_resample_batch_size))
        print(
            f"[INFO] {acc} IDR {start}-{end}: sampling additional fragment batch "
            f"n={nraw} into {outdir}",
            file=sys.stderr,
        )
        run_idpcg_build(
            window_seq,
            nraw,
            outdir,
            args.idpcg_db,
            args.idpcg_cmd,
            args.n_workers,
            args.idpcg_extra,
        )
        pdbs = collect_pdbs(outdir)
        if not pdbs:
            print(f"[WARN] No extra fragment PDBs generated for {acc} IDR {start}-{end}", file=sys.stderr)
            return []
        return align_fragment_pdbs_for_idr(
            acc,
            idr,
            full_sequence,
            template_atoms,
            args,
            pdbs,
            log_prefix=f"extra batch {os.path.basename(outdir)}",
        )


def junctions_ok(template_atoms: List[Atom], idr_atoms: List[Atom], start: int, end: int, dmin: float, dmax: float) -> bool:
    amap_t = get_atom_map(template_atoms)
    amap_i = get_atom_map(idr_atoms)
    # C(prev)-N(first)
    if (start - 1, "C") in amap_t and (start, "N") in amap_i:
        d = np.linalg.norm(amap_t[(start - 1, "C")].xyz - amap_i[(start, "N")].xyz)
        if not (dmin <= d <= dmax):
            return False
    # C(last)-N(next)
    if (end, "C") in amap_i and (end + 1, "N") in amap_t:
        d = np.linalg.norm(amap_i[(end, "C")].xyz - amap_t[(end + 1, "N")].xyz)
        if not (dmin <= d <= dmax):
            return False
    return True


def severe_clashes(atoms: List[Atom], clash_scale: float = 0.70, max_clashes: int = 0) -> Tuple[bool, int, float]:
    heavy = [a for a in atoms if a.element.upper() != "H"]
    if len(heavy) < 2:
        return False, 0, 999.0
    xyz = atom_xyz(heavy)
    tree = cKDTree(xyz)
    pairs = tree.query_pairs(r=2.7)
    nclash = 0
    mind = 999.0
    for i, j in pairs:
        a, b = heavy[i], heavy[j]
        if a.chain == b.chain and abs(a.resseq - b.resseq) <= 1 and {a.name, b.name} & BACKBONE:
            continue
        d = float(np.linalg.norm(a.xyz - b.xyz))
        mind = min(mind, d)
        ri = VDW.get(a.element.upper(), 1.7)
        rj = VDW.get(b.element.upper(), 1.7)
        if d < clash_scale * (ri + rj):
            nclash += 1
            if nclash > max_clashes:
                return True, nclash, mind
    return False, nclash, mind



def is_local_covalent_or_bonded_neighbor(a: Atom, b: Atom, seq_neighbor_window: int = 2) -> bool:
    """Exclude obvious bonded/local pairs from placement clash counting.

    The TM builder stitches IDR fragments into a fixed template.  Very local
    contacts across the stitch point can otherwise be mis-counted as clashes,
    even though restrained OpenMM cleanup is expected to regularize them.
    ``seq_neighbor_window`` should remain small; it is not a general clash bypass.
    """
    if a.chain != b.chain:
        return False
    sep = abs(int(a.resseq) - int(b.resseq))
    if sep == 0:
        return True
    if sep <= max(1, int(seq_neighbor_window)):
        # Always ignore backbone-local contacts; also ignore any atom pair within
        # the first two sequence neighbors by default because sidechains at the
        # stitched peptide junction can be transiently close before minimization.
        return True
    return False


def cross_clash_stats(
    atoms_a: List[Atom],
    atoms_b: List[Atom],
    clash_scale: float = 0.70,
    max_clashes: int = 0,
    query_radius: float = 3.2,
    seq_neighbor_window: int = 2,
    ) -> Tuple[bool, int, float]:
        """Count clashes between two atom groups only; do not count internal contacts."""
        heavy_a = [a for a in atoms_a if a.element.upper() != "H"]
        heavy_b = [b for b in atoms_b if b.element.upper() != "H"]
        if not heavy_a or not heavy_b:
            return False, 0, 999.0
        tree = cKDTree(atom_xyz(heavy_b))
        nclash = 0
        mind = 999.0
        for a in heavy_a:
            for j in tree.query_ball_point(a.xyz, query_radius):
                b = heavy_b[j]
                if is_local_covalent_or_bonded_neighbor(a, b, seq_neighbor_window=seq_neighbor_window):
                    continue
                d = float(np.linalg.norm(a.xyz - b.xyz))
                mind = min(mind, d)
                ri = VDW.get(a.element.upper(), 1.7)
                rj = VDW.get(b.element.upper(), 1.7)
                if d < clash_scale * (ri + rj):
                    nclash += 1
                    if nclash > max_clashes:
                        return True, nclash, mind
        return False, nclash, mind


def idr_placement_clashes(
    fixed_atoms: List[Atom],
    idr_atoms_by_region: List[Tuple[dict, List[Atom]]],
    clash_scale: float = 0.70,
    max_idr_fixed_clashes: int = 0,
    max_idr_idr_clashes: int = 0,
    seq_neighbor_window: int = 2,
    ) -> Tuple[bool, dict]:
        """Check only placement-relevant clashes.

        This intentionally does NOT run a global all-vs-all protein clash count,
        because that counts ordinary covalent geometry inside the fixed folded/TM
        template and inside generated IDR fragments. For TM-IDR assembly, the
        relevant rejection criteria are: inserted IDR atoms versus the fixed
        template, and separate IDR regions versus each other.
        """
        stats = {
            "idr_fixed_clashes": 0,
            "idr_idr_clashes": 0,
            "protein_clashes_total": 0,
            "min_idr_fixed_distance": 999.0,
            "min_idr_idr_distance": 999.0,
            "min_distance": 999.0,
        }

        for idr, atoms in idr_atoms_by_region:
            reject, nclash, mind = cross_clash_stats(
                atoms, fixed_atoms,
                clash_scale=clash_scale,
                max_clashes=max_idr_fixed_clashes,
                seq_neighbor_window=seq_neighbor_window,
            )
            stats["idr_fixed_clashes"] += int(nclash)
            stats["min_idr_fixed_distance"] = min(stats["min_idr_fixed_distance"], float(mind))
            stats["min_distance"] = min(stats["min_distance"], float(mind))
            if stats["idr_fixed_clashes"] > max_idr_fixed_clashes or reject:
                stats["protein_clashes_total"] = stats["idr_fixed_clashes"] + stats["idr_idr_clashes"]
                return True, stats

        for i in range(len(idr_atoms_by_region)):
            for j in range(i + 1, len(idr_atoms_by_region)):
                reject, nclash, mind = cross_clash_stats(
                    idr_atoms_by_region[i][1],
                    idr_atoms_by_region[j][1],
                    clash_scale=clash_scale,
                    max_clashes=max_idr_idr_clashes,
                    seq_neighbor_window=seq_neighbor_window,
                )
                stats["idr_idr_clashes"] += int(nclash)
                stats["min_idr_idr_distance"] = min(stats["min_idr_idr_distance"], float(mind))
                stats["min_distance"] = min(stats["min_distance"], float(mind))
                if stats["idr_idr_clashes"] > max_idr_idr_clashes or reject:
                    stats["protein_clashes_total"] = stats["idr_fixed_clashes"] + stats["idr_idr_clashes"]
                    return True, stats

        stats["protein_clashes_total"] = stats["idr_fixed_clashes"] + stats["idr_idr_clashes"]
        return False, stats


def idr_side_from_topology(topology: Optional[str], start: int, end: int) -> Optional[str]:
    if not topology:
        return None
    labs = []
    for pos in range(start, end + 1):
        idx = pos - 1
        if 0 <= idx < len(topology):
            lab = topology[idx].upper()
            if lab in {"I", "O"}:
                labs.append(lab)
    if not labs:
        # Try flanks.
        for pos in list(range(max(1, start - 8), start)) + list(range(end + 1, min(len(topology), end + 8) + 1)):
            lab = topology[pos - 1].upper()
            if lab in {"I", "O"}:
                labs.append(lab)
    if not labs:
        return None
    return "inside" if labs.count("I") >= labs.count("O") else "outside"


def is_anchor_excluded_residue(idr: dict, resseq: int, anchor_exclusion_residues: int) -> bool:
    """Return True for IDR residues close enough to a folded/TM anchor to skip slab filtering.

    This handles juxtamembrane residues immediately attached to a TM helix.  Those
    first one or two residues are often geometrically pinned at the membrane
    boundary by the template and should not make an otherwise usable test build
    fail before minimization.
    """
    n = max(0, int(anchor_exclusion_residues))
    if n <= 0:
        return False
    start = int(idr["start"])
    end = int(idr["end"])
    kind = str(idr.get("kind", "LINKER")).upper()
    if kind == "N":
        return resseq >= end - n + 1
    if kind == "C":
        return resseq <= start + n - 1
    if kind in {"LINKER", "LOOP"}:
        return (resseq <= start + n - 1) or (resseq >= end - n + 1)
    return False


def atom_is_checked_by_slab(a: Atom, mode: str) -> bool:
    mode = str(mode).lower()
    if mode == "ca":
        return a.name == "CA"
    if mode == "backbone":
        return a.name in BACKBONE
    return a.element.upper() != "H"


def membrane_slab_filter(
    idr_atoms_by_region: List[Tuple[dict, List[Atom]]],
    frame: dict,
    topology: Optional[str],
    core_margin: float = 0.0,
    allow_core_ca: int = 0,
    side_cross_margin: float = 4.0,
    interface_rejection_strength: float = 0.15,
    rng: Optional[random.Random] = None,
    slab_filter_atoms: str = "ca",
    slab_anchor_exclusion_residues: int = 2,
    ) -> Tuple[bool, dict]:
        """Probabilistic POPC slab filter.

        The hydrocarbon core is a hard-exclusion slab: IDR heavy atoms are not allowed
        inside |z| < core_half - core_margin.  The headgroup/interface region between
        core_half and head_half is allowed, but candidates that bury many IDR atoms
        deep in that surface zone are down-weighted probabilistically. This gives
        IDRs permission to touch either membrane surface without letting them pass
        through the hydrophobic core.
        """
        rng = rng or random
        core_half = float(frame.get("core_half_thickness", 14.4))
        head_half = float(frame.get("head_half_thickness", 19.55))
        mid = float(frame.get("midplane_z", 0.0))
        inside_sign = frame.get("inside_sign")
        outside_sign = frame.get("outside_sign")
        hard_core_limit = max(0.0, core_half - max(0.0, core_margin))
        interface_width = max(1e-6, head_half - core_half)

        stats = {
            "core_heavy_atoms": 0,
            "core_backbone_atoms": 0,
            "core_ca_atoms": 0,
            "interface_heavy_atoms": 0,
            "interface_backbone_atoms": 0,
            "wrong_side_regions": 0,
            "min_abs_z": 999.0,
            "mean_interface_depth": 0.0,
            "max_interface_depth": 0.0,
            "surface_accept_probability": 1.0,
            "popc_core_half_thickness": core_half,
            "popc_head_half_thickness": head_half,
            "slab_filter_atoms": str(slab_filter_atoms),
            "slab_anchor_exclusion_residues": int(slab_anchor_exclusion_residues),
            "anchor_excluded_atoms": 0,
        }
        interface_depths: List[float] = []

        for idr, atoms in idr_atoms_by_region:
            for a in atoms:
                if a.element.upper() == "H":
                    continue
                if is_anchor_excluded_residue(idr, int(a.resseq), slab_anchor_exclusion_residues):
                    stats["anchor_excluded_atoms"] += 1
                    continue
                if not atom_is_checked_by_slab(a, slab_filter_atoms):
                    continue
                zabs = abs(a.z - mid)
                stats["min_abs_z"] = min(stats["min_abs_z"], zabs)
                if zabs < hard_core_limit:
                    stats["core_heavy_atoms"] += 1
                    if a.name in BACKBONE:
                        stats["core_backbone_atoms"] += 1
                    if a.name == "CA":
                        stats["core_ca_atoms"] += 1
                elif core_half <= zabs <= head_half:
                    # 0 at the water-facing edge of DB, 1 at the hydrocarbon boundary.
                    depth = (head_half - zabs) / interface_width
                    depth = float(np.clip(depth, 0.0, 1.0))
                    interface_depths.append(depth)
                    stats["interface_heavy_atoms"] += 1
                    if a.name in BACKBONE:
                        stats["interface_backbone_atoms"] += 1

            side = idr_side_from_topology(topology, idr["start"], idr["end"])
            if side in {"inside", "outside"} and inside_sign is not None and outside_sign is not None:
                expected = inside_sign if side == "inside" else outside_sign
                ca_z = [a.z - mid for a in atoms if a.name == "CA"]
                if ca_z:
                    wrong = [z for z in ca_z if np.sign(z) == -expected and abs(z) > side_cross_margin]
                    if len(wrong) > max(2, 0.25 * len(ca_z)):
                        stats["wrong_side_regions"] += 1

        if interface_depths:
            stats["mean_interface_depth"] = float(np.mean(interface_depths))
            stats["max_interface_depth"] = float(np.max(interface_depths))
            # Mild stochastic rejection: touching the surface is usually accepted;
            # broad burial into the interface is penalized. Core penetration is never accepted.
            penalty = interface_rejection_strength * (
                float(np.sum(np.square(interface_depths))) / max(1.0, len(interface_depths))
            )
            stats["surface_accept_probability"] = float(np.exp(-penalty))

        checked_mode = str(slab_filter_atoms).lower()
        if checked_mode == "ca":
            core_checked_atoms = int(stats["core_ca_atoms"])
        elif checked_mode == "backbone":
            core_checked_atoms = int(stats["core_backbone_atoms"])
        else:
            core_checked_atoms = int(stats["core_heavy_atoms"])
        stats["core_checked_atoms"] = core_checked_atoms
        stats["allow_core_checked_atoms"] = int(allow_core_ca)

        hard_reject = (
            core_checked_atoms > int(allow_core_ca)
            or stats["wrong_side_regions"] > 0
        )
        if hard_reject:
            return True, stats

        if interface_rejection_strength > 0 and interface_depths:
            if rng.random() > stats["surface_accept_probability"]:
                stats["surface_probabilistic_reject"] = 1
                return True, stats
        stats["surface_probabilistic_reject"] = 0
        return False, stats


def build_one_protein(acc: str, pdata: dict, idrs: List[dict], args,
                      post_filter: Optional[Callable[[List[Atom], List[Tuple[dict, List[Atom]]], dict, dict], Tuple[bool, dict]]] = None) -> dict:
    seq = pdata.get("sequence")
    if not seq:
        return {"acc": acc, "status": "skipped_no_sequence"}
    tm_class = pdata.get("tm_classification", "UNKNOWN")
    if args.only_tm and not ("TM" in tm_class and not tm_class.startswith("NON")):
        return {"acc": acc, "status": f"skipped_class_{tm_class}"}
    tm_segments = parse_intervals(pdata.get("consensus_tm_segments", []))
    if not tm_segments:
        return {"acc": acc, "status": "skipped_no_tm_segments"}

    idrs = classify_idr_segments(
        idrs,
        len(seq),
        interactions=pdata.get("interactions", []),
        mean_pae=pdata.get("mean_pae", {}),
        use_pae_fallback=args.use_adjacent_pae_fallback_for_loops,
        pae_cutoff=args.adjacent_loop_pae_cutoff,
    )

    # Guard against IDR/TM overlap using the same edge-tolerance convention as tm02_3.
    bad = []
    for r in idrs:
        conflicts = idr_tm_conflicts(r["start"], r["end"], tm_segments, args.tm_edge_tolerance)
        if conflicts:
            rr = dict(r)
            rr["tm_conflicts"] = conflicts
            bad.append(rr)
    if bad and not args.allow_idr_tm_overlap:
        return {"acc": acc, "status": "skipped_idr_tm_overlap", "bad_idrs": bad}

    tpath = find_template_path(args.template_dir, acc)
    if not tpath:
        return {"acc": acc, "status": "skipped_no_template"}
    template_atoms = parse_pdb(tpath, chain=args.chain, include_hetatm=False)
    if not template_atoms:
        return {"acc": acc, "status": "skipped_template_parse_failed", "template": tpath}

    # Remove known IDR atoms from template. This lets you use full AlphaFold models directly.
    fixed_atoms = [a for a in template_atoms if not interval_contains(idrs, a.resseq)]
    fixed_atoms, frame = infer_membrane_frame(fixed_atoms, tm_segments, pdata.get("topology_labels"), args.core_half_thickness, args.head_half_thickness)
    out_prot = os.path.join(args.outdir, acc)
    Path(out_prot).mkdir(parents=True, exist_ok=True)
    with open(os.path.join(out_prot, f"{acc}_idr_segments.json"), "w") as segout:
        json.dump(idrs, segout, indent=2)
    write_pdb(fixed_atoms, os.path.join(out_prot, f"{acc}_fixed_oriented.pdb"), remarks=["Fixed oriented template used for TM-IDR building"])

    pools: List[Tuple[dict, List[List[Atom]]]] = []
    fixed_pdb = os.path.join(out_prot, f"{acc}_fixed_oriented.pdb")
    for idr in idrs:
        kind = str(idr.get("kind", "LINKER")).upper()
        is_internal = kind not in {"N", "C", "N+C"}
        use_hard_internal = (
            args.use_hard_loop_closure
            and (
                (args.hard_close_internal_idrs == "loop" and kind == "LOOP")
                or (args.hard_close_internal_idrs == "all" and is_internal)
            )
        )
        if use_hard_internal:
            pool = prepare_hard_loop_closures_for_idr(acc, idr, seq, fixed_pdb, args)
            failure_status = f"failed_no_hard_loop_closures_{idr['start']}_{idr['end']}"
        else:
            pool = prepare_fragments_for_idr(acc, idr, seq, fixed_atoms, args)
            failure_status = f"failed_no_fragments_{idr['start']}_{idr['end']}"
        if not pool:
            return {"acc": acc, "status": failure_status, "idr": idr}
        pools.append((idr, pool))

    # Diversity guard for the common easy case: one terminal IDR attached to a
    # fixed TM/folded scaffold.
    single_terminal_pool = (
        len(pools) == 1
        and str(pools[0][0].get("kind", "")).upper() in {"N", "C", "N+C"}
        and bool(args.unique_single_terminal_idr)
    )
    used_single_terminal_indices: set = set()
    rejected_single_terminal_indices: set = set()
    fragment_resample_batches = [0 for _idr, _pool in pools]
    if single_terminal_pool and len(pools[0][1]) < args.n_conformers:
        print(
            f"[INFO] {acc}: initial terminal IDR pool has {len(pools[0][1])} usable fragments "
            f"for {args.n_conformers} requested conformers; more batches will be sampled if needed.",
            file=sys.stderr,
        )

    summary_rows = []
    accepted = 0
    tries = 0
    rng = random.Random(args.seed)
    while accepted < args.n_conformers and tries < args.max_tries:
        if single_terminal_pool:
            unused = [
                i for i in range(len(pools[0][1]))
                if i not in used_single_terminal_indices and i not in rejected_single_terminal_indices
            ]
            while not unused and accepted < args.n_conformers:
                if fragment_resample_batches[0] >= args.max_fragment_resample_batches:
                    print(
                        f"[WARN] {acc}: exhausted unique terminal IDR fragments after "
                        f"{fragment_resample_batches[0]} extra batch(es); stopping at {accepted}/{args.n_conformers} "
                        f"(used={len(used_single_terminal_indices)}, rejected={len(rejected_single_terminal_indices)}).",
                        file=sys.stderr,
                    )
                    break
                new_pool = sample_additional_fragments_for_idr(
                    acc,
                    pools[0][0],
                    seq,
                    fixed_atoms,
                    args,
                    batch_size=args.fragment_resample_batch_size,
                )
                fragment_resample_batches[0] += 1
                if new_pool:
                    start_len = len(pools[0][1])
                    pools[0][1].extend(new_pool)
                    print(
                        f"[INFO] {acc}: terminal IDR pool extended "
                        f"{start_len} -> {len(pools[0][1])} usable fragments; "
                        f"accepted={accepted}/{args.n_conformers}",
                        file=sys.stderr,
                    )
                else:
                    print(
                        f"[WARN] {acc}: extra fragment batch {fragment_resample_batches[0]} yielded no usable terminal fragments",
                        file=sys.stderr,
                    )
                unused = [
                    i for i in range(len(pools[0][1]))
                    if i not in used_single_terminal_indices and i not in rejected_single_terminal_indices
                ]
            if not unused:
                break
            chosen_idx = rng.choice(unused)
            chosen_pool_indices = [chosen_idx]
            chosen: List[Tuple[dict, List[Atom]]] = [(pools[0][0], pools[0][1][chosen_idx])]
        else:
            chosen_pool_indices = None
            chosen = [(idr, rng.choice(pool)) for idr, pool in pools]

        tries += 1
        all_atoms = fixed_atoms[:]
        for _, atoms in chosen:
            all_atoms.extend(atoms)

        max_idr_fixed = args.max_idr_fixed_clashes
        if max_idr_fixed is None:
            max_idr_fixed = args.max_protein_clashes
        has_clash, clash_stats = idr_placement_clashes(
            fixed_atoms,
            chosen,
            clash_scale=args.protein_clash_scale,
            max_idr_fixed_clashes=max_idr_fixed,
            max_idr_idr_clashes=args.max_idr_idr_clashes,
            seq_neighbor_window=args.local_clash_ignore_window,
        )
        nclash = int(clash_stats.get("protein_clashes_total", 0))
        mind = float(clash_stats.get("min_distance", 999.0))
        if has_clash:
            if single_terminal_pool and chosen_pool_indices is not None:
                # Deterministic placement clash: this terminal fragment cannot contribute a valid unique model.
                rejected_single_terminal_indices.update(chosen_pool_indices)
            row = {"try": tries, "accepted": 0, "reason": "protein_clash", "nclash": nclash, "min_distance": mind}
            row.update(clash_stats)
            summary_rows.append(row)
            continue
        mem_reject, mem_stats = membrane_slab_filter(
            chosen,
            frame,
            pdata.get("topology_labels"),
            args.core_margin,
            args.allow_core_ca,
            args.side_cross_margin,
            args.interface_rejection_strength,
            rng,
            slab_filter_atoms=args.slab_filter_atoms,
            slab_anchor_exclusion_residues=args.slab_anchor_exclusion_residues,
        )
        if mem_reject:
            if single_terminal_pool and chosen_pool_indices is not None:
                # Retire rejected terminal fragments. This avoids repeatedly proposing the
                # same bad conformer and keeps the stochastic membrane filter as rejection sampling.
                rejected_single_terminal_indices.update(chosen_pool_indices)
            row = {"try": tries, "accepted": 0, "reason": "implicit_membrane", "nclash": nclash, "min_distance": mind}
            row.update(clash_stats)
            row.update(mem_stats)
            summary_rows.append(row)
            continue
        extra_stats = {}
        if post_filter is not None:
            reject, extra_stats = post_filter(all_atoms, chosen, frame, pdata)
            if reject:
                if single_terminal_pool and chosen_pool_indices is not None:
                    rejected_single_terminal_indices.update(chosen_pool_indices)
                row = {"try": tries, "accepted": 0, "reason": "post_filter", "nclash": nclash, "min_distance": mind}
                row.update(clash_stats)
                row.update(mem_stats)
                row.update(extra_stats)
                summary_rows.append(row)
                continue
        accepted += 1
        if single_terminal_pool and chosen_pool_indices is not None:
            used_single_terminal_indices.update(chosen_pool_indices)
        pdb_out = os.path.join(out_prot, f"{acc}_tmidr_{accepted:04d}.pdb")
        remarks = [
            f"AlphaFlex TM-IDR implicit membrane conformer {accepted}",
            f"membrane core_half={frame['core_half_thickness']} head_half={frame['head_half_thickness']}",
        ]
        write_pdb(sorted(all_atoms, key=lambda a: (a.chain, a.resseq, a.serial)), pdb_out, remarks=remarks)
        row = {"try": tries, "accepted": 1, "reason": "accepted", "pdb": pdb_out, "nclash": nclash, "min_distance": mind}
        row.update(clash_stats)
        row.update(mem_stats)
        row.update(extra_stats)
        summary_rows.append(row)

    csv_path = os.path.join(out_prot, f"{acc}_build_summary.csv")
    if summary_rows:
        keys = sorted({k for row in summary_rows for k in row.keys()})
        with open(csv_path, "w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=keys)
            writer.writeheader()
            writer.writerows(summary_rows)
    with open(os.path.join(out_prot, f"{acc}_membrane_frame.json"), "w") as handle:
        json.dump(frame, handle, indent=2)
    reject_counts: Dict[str, int] = {}
    for row in summary_rows:
        reason = str(row.get("reason", "unknown"))
        reject_counts[reason] = reject_counts.get(reason, 0) + 1

    ensemble_path = None
    if accepted > 0:
        ensemble_path = postprocess_and_ensemble(acc, out_prot, idrs, args)
        cleanup_protein_output(out_prot, acc, ensemble_path, args)
    return {
        "acc": acc,
        "status": "ok" if accepted == args.n_conformers else "partial",
        "accepted": accepted,
        "tries": tries,
        "reject_counts": reject_counts,
        "outdir": out_prot,
        "ensemble": ensemble_path,
    }


def build_all(args, post_filter: Optional[Callable[[List[Atom], List[Tuple[dict, List[Atom]]], dict, dict], Tuple[bool, dict]]] = None) -> List[dict]:
    Path(args.outdir).mkdir(parents=True, exist_ok=True)
    Path(args.workdir).mkdir(parents=True, exist_ok=True)
    tm = load_json(args.tm_json)
    idr_map = normalize_idr_json(load_json(args.idr_json))
    proteins = get_protein_map(tm)
    master_records = {}
    if args.master_db_json:
        master_records = get_protein_map(load_json(args.master_db_json))

    results = []
    if args.ids_file:
        ids = load_ids_file(args.ids_file)
    elif args.ids:
        ids = [x.strip() for x in args.ids.split(",") if x.strip()]
    else:
        ids = list(idr_map.keys())

    # Keep protein-level processing serial to avoid nested multiprocessing with IDPConfGen.
    for acc in ids:
        acc = acc.strip()
        if not acc:
            continue
        if acc not in idr_map:
            print(f"[WARN] {acc} not in IDR JSON; skipping", file=sys.stderr)
            results.append({"acc": acc, "status": "skipped_not_in_idr_json"})
            continue

        tm_record = proteins.get(acc)
        master_record = master_records.get(acc) if master_records else None
        if tm_record is None and master_record is None:
            print(f"[WARN] {acc} missing from TM JSON and master DB; skipping", file=sys.stderr)
            results.append({"acc": acc, "status": "skipped_not_in_tm_or_master_db"})
            continue

        merged = merge_protein_record(acc, tm_record, master_record)

        if args.only_tm and not is_tm_like(merged.get("tm_classification", "UNKNOWN")):
            print(f"[WARN] {acc} not TM-like after merge ({merged.get('tm_classification', 'UNKNOWN')}); skipping", file=sys.stderr)
            results.append({"acc": acc, "status": f"skipped_class_{merged.get('tm_classification', 'UNKNOWN')}"})
            continue

        print(f"[INFO] Building {acc}", file=sys.stderr)
        res = build_one_protein(acc, merged, idr_map[acc], args, post_filter=post_filter)
        print(f"[INFO] {acc}: {res}", file=sys.stderr)
        results.append(res)
    with open(os.path.join(args.outdir, "tmidr_build_results.json"), "w") as out:
        json.dump(results, out, indent=2)
    return results


def add_common_args(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--tm-json", required=True)
    ap.add_argument("--master-db-json", default=None, help="Optional master DB JSON used to fill missing fields for selected IDs")
    ap.add_argument("--idr-json", required=True)
    ap.add_argument("--template-dir", required=True)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--workdir", default="tmidr_work")
    ap.add_argument("--ids", default=None, help="Optional comma-separated subset of UniProt IDs")
    ap.add_argument("--ids-file", default=None, help="Optional txt file with one UniProt ID per line (e.g., bilayer1.txt)")
    ap.add_argument("--chain", default="A")
    ap.add_argument("--idpcg-db", required=True, help="IDPConformerGenerator torsion database JSON")
    ap.add_argument("--idpcg-cmd", default="idpconfgen", help="IDPConformerGenerator command")
    ap.add_argument("--idpcg-extra", default="", help="Extra args after -of OUTDIR. If -n/--n is omitted, --n-workers is passed automatically")
    ap.add_argument("--n-workers", type=int, default=max(1, (os.cpu_count() or 1) // 2), help="Worker count passed to IDPConformerGenerator build via -n")
    ap.add_argument("--n-conformers", type=int, default=100)
    ap.add_argument("--unique-single-terminal-idr", action=argparse.BooleanOptionalAction, default=True, help="For single-terminal-IDR cases, require each accepted conformer to use a distinct IDR fragment; rejected attempts do not consume fragments")
    ap.add_argument("--clean-final-output", action=argparse.BooleanOptionalAction, default=True, help="After a successful postprocessed build, keep only *_membrane_frame.json and the final multi-model ensemble PDB in each protein folder")
    ap.add_argument("--fragment-pool-size", type=int, default=500)
    ap.add_argument("--fragment-resample-batch-size", type=int, default=500, help="Raw IDPConfGen candidates per additional fragment batch when the usable single-terminal-IDR pool is exhausted before --n-conformers is reached")
    ap.add_argument("--max-fragment-resample-batches", type=int, default=20, help="Safety limit for additional single-terminal-IDR fragment batches per protein")
    ap.add_argument("--max-tries", type=int, default=5000)
    ap.add_argument("--use-hard-loop-closure", action=argparse.BooleanOptionalAction, default=True, help="Use build_hard_flex-style lower/upper anchor + next_seeker closure for internal IDRs selected by --hard-close-internal-idrs")
    ap.add_argument("--hard-close-internal-idrs", choices=["loop", "all", "none"], default="loop", help="Which internal IDRs use hard two-anchor closure: only interaction-defined LOOP IDRs, all internal IDRs, or none")
    ap.add_argument("--hard-loop-unique-target", type=int, default=3, help="Number of unique closed LOOP inserts to collect per LOOP-IDR before reuse")
    ap.add_argument("--min-hard-loop-unique-required", type=int, default=1, help="Minimum closed LOOP inserts required; if fewer are found the protein fails unless fallback is enabled")
    ap.add_argument("--hard-loop-batch-size", type=int, default=1000, help="Raw IDPConfGen candidates per hard LOOP closure batch")
    ap.add_argument("--hard-loop-max-batches", type=int, default=12, help="Maximum hard LOOP closure batches per LOOP-IDR")
    ap.add_argument("--loop-anchor-max-clash", type=int, default=160, help="count_clashes max_clash for lower/upper LOOP anchor alignment")
    ap.add_argument("--loop-anchor-tolerance", type=float, default=1.2, help="count_clashes tolerance for lower/upper LOOP anchor alignment")
    ap.add_argument("--loop-join-max-clash", type=int, default=120, help="next_seeker max_clash for joining lower/upper LOOP libraries")
    ap.add_argument("--loop-join-tolerance", type=float, default=0.8, help="next_seeker tolerance for joining lower/upper LOOP libraries")
    ap.add_argument("--loop-join-search-factor", type=int, default=20, help="Scale factor for lower/upper archive sampling during LOOP joining")
    ap.add_argument("--loop-join-cap-min", type=int, default=750, help="Minimum lower/upper archive sample size for next_seeker")
    ap.add_argument("--loop-join-archive-min", type=int, default=3000, help="Minimum archive cap for lower/upper aligned LOOP candidates")
    ap.add_argument("--loop-atom-clash-cutoff", type=float, default=1.35, help="Extra close-contact cutoff for accepted LOOP insert vs scaffold")
    ap.add_argument("--loop-max-atom-clashes", type=int, default=20, help="Allowed close contacts for accepted LOOP insert vs scaffold before rejecting")
    ap.add_argument("--reuse-loop-libraries", action="store_true", help="Reuse existing temp hard-loop library PDBs if present")
    ap.add_argument("--loop-closure-fallback-to-kabsch", action="store_true", help="If hard LOOP closure fails, fall back to old Kabsch flank-fragment mode")
    ap.add_argument("--use-adjacent-pae-fallback-for-loops", action="store_true", help="Classify adjacent internal IDRs as LOOP if mean PAE is below cutoff even without an interactions entry")
    ap.add_argument("--adjacent-loop-pae-cutoff", type=float, default=8.0)
    ap.add_argument("--anchor-flank", type=int, default=3)
    ap.add_argument("--anchor-rmsd-max", type=float, default=1.25)
    ap.add_argument("--junction-min", type=float, default=0.9)
    ap.add_argument("--junction-max", type=float, default=1.9)
    ap.add_argument("--core-half-thickness", type=float, default=14.4, help="POPC hydrocarbon core half-thickness in Å; default is 28.8/2 from scattering-derived 2DC at ~30 °C")
    ap.add_argument("--head-half-thickness", type=float, default=19.55, help="POPC bilayer/headgroup half-thickness in Å; default is 39.1/2 from scattering-derived DB at ~30 °C")
    ap.add_argument("--core-margin", type=float, default=0.0, help="Å subtracted from the hard POPC hydrocarbon-core exclusion boundary; keep 0.0 for strict core exclusion")
    ap.add_argument("--allow-core-ca", type=int, default=0, help="Normally keep at 0: no IDR CA atoms may enter the POPC hydrocarbon core")
    ap.add_argument("--side-cross-margin", type=float, default=4.0)
    ap.add_argument("--interface-rejection-strength", type=float, default=0.15, help="Strength of stochastic penalty for burying IDR atoms in the POPC headgroup/interface zone; 0 disables probabilistic surface rejection")
    ap.add_argument("--slab-filter-atoms", choices=["ca", "backbone", "heavy"], default="ca", help="Which IDR atoms are hard-filtered against the POPC core. Default ca is robust for juxtamembrane tests; use backbone/heavy for stricter production screening.")
    ap.add_argument("--slab-anchor-exclusion-residues", type=int, default=2, help="Ignore this many IDR residues next to folded/TM anchors during slab filtering; helps juxtamembrane stitch residues that sit at the core boundary.")
    ap.add_argument("--local-clash-ignore-window", type=int, default=2, help="Ignore IDR/fixed placement clash pairs within this residue separation, to avoid rejecting normal stitched junction geometry before OpenMM cleanup.")
    ap.add_argument("--protein-clash-scale", type=float, default=0.70, help="Scale applied to VDW radii for IDR-placement clash checks")
    ap.add_argument("--max-protein-clashes", type=int, default=0, help="Backward-compatible alias for --max-idr-fixed-clashes when that option is omitted")
    ap.add_argument("--max-idr-fixed-clashes", type=int, default=None, help="Maximum allowed clashes between inserted IDR atoms and the fixed folded/TM template; default uses --max-protein-clashes")
    ap.add_argument("--max-idr-idr-clashes", type=int, default=0, help="Maximum allowed clashes between separate inserted IDR regions")
    ap.add_argument("--tm-edge-tolerance", type=int, default=5, help="Ignore IDR/TM overlaps of this many residues or fewer when they occur only at a TM interval edge, matching tm02_3")
    ap.add_argument("--allow-idr-tm-overlap", action="store_true")
    ap.add_argument("--only-tm", action="store_true", help="Skip proteins not classified as TM-like")
    ap.add_argument("--seed", type=int, default=1)
    ap.set_defaults(run_postprocess=True)
    ap.add_argument("--run-postprocess", dest="run_postprocess", action="store_true", help="Run protonation, minimization, folded-region alignment, and multi-model assembly (default)")
    ap.add_argument("--skip-postprocess", dest="run_postprocess", action="store_false", help="Skip postprocessing and keep only built conformers")
    ap.add_argument("--postprocess-ph", type=float, default=7.4, help="pH for PDBFixer hydrogenation")
    ap.add_argument("--openmm-max-iterations", type=int, default=1000, help="Max iterations for restrained OpenMM minimization")
    ap.add_argument("--align-chain", default="A", help="Chain used for folded-region alignment matching")
    ap.add_argument("--align-min-common-atoms", type=int, default=20, help="Minimum common folded backbone atoms required for alignment")
    ap.add_argument("--keep-postprocess-intermediates", action="store_true", help="Keep *_pro.pdb and *_cr.pdb files after assembly")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    add_common_args(ap)
    args = ap.parse_args()

    # No explicit bilayer mode: all membrane filtering is the POPC probabilistic slab.
    build_all(args, post_filter=None)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
