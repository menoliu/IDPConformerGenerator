"""
Classify TM-IDR proteins by IDR layout case and IDR/TM conflict status, using
TMbed topology as the authoritative membrane annotation whenever available.
UniProt-derived TM intervals are used only as a fallback when no TMbed topology
or TMbed TM intervals can be found for a protein.

Main outputs
------------
classification_details.tsv
classification_summary.json
conflict_ids.txt
non_conflict_ids.txt
non_conflict_easy_ids.txt
non_conflict_difficult_ids.txt
case-specific *_ids.txt files
chunked TXT folders for all/easy/difficult non-conflict IDs

The easy/difficult split is intentionally build-oriented:
  easy      = non-conflicting terminal-only IDR cases with <= --easy-max-tm-segments
  difficult = all other non-conflicting TM-IDR cases

By default, easy is mostly single-pass TM proteins with only N/C terminal IDRs.
"""
import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


TM_LABELS = set("HhBbMmTt")  # TMbed canonical: H/h alpha helix, B/b beta strand. M/T are permissive fallbacks.
INSIDE_LABELS = set("Ii")
OUTSIDE_LABELS = set("Oo")
SIGNAL_LABELS = set("Ss")


def load_json(path: str) -> dict:
    with open(path) as handle:
        return json.load(handle)


def get_protein_map(db_obj: dict) -> Dict[str, dict]:
    if isinstance(db_obj, dict) and isinstance(db_obj.get("proteins"), dict):
        return db_obj["proteins"]
    if isinstance(db_obj, dict):
        return db_obj
    return {}


def load_ids_file(path: str) -> List[str]:
    ids: List[str] = []
    with open(path) as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            ids.append(line)
    return ids


def load_ids_dir(path: str) -> List[str]:
    folder = Path(path)
    if not folder.is_dir():
        raise FileNotFoundError(f"IDs directory not found: {path}")
    ids = set()
    for txt_path in sorted(folder.glob("*.txt")):
        ids.update(load_ids_file(str(txt_path)))
    return sorted(ids)


def first_non_empty(record: Optional[dict], keys: Sequence[str], default=None):
    if not isinstance(record, dict):
        return default
    for key in keys:
        value = record.get(key)
        if value not in (None, "", [], {}):
            return value
    return default


def normalize_idrs(value) -> List[Tuple[int, int]]:
    if isinstance(value, dict):
        ranges = value.get("idrs", [])
    else:
        ranges = value

    out: List[Tuple[int, int]] = []
    if not isinstance(ranges, list):
        return out

    for item in ranges:
        try:
            if isinstance(item, dict):
                start, end = int(item["start"]), int(item["end"])
            else:
                start, end = int(item[0]), int(item[1])
        except Exception:
            continue
        if start > end:
            start, end = end, start
        out.append((start, end))
    return sorted(out)


def normalize_interactions(value) -> List[List[str]]:
    if not isinstance(value, dict):
        return []
    interactions = value.get("interactions", [])
    out = []
    for pair in interactions:
        if isinstance(pair, list) and len(pair) == 2 and all(isinstance(x, str) for x in pair):
            out.append(pair)
    return out


def infer_sequence_length(tm_record: Optional[dict], idr_record: Optional[dict], idrs: List[Tuple[int, int]], topology: Optional[str] = None) -> Optional[int]:
    for record in (tm_record, idr_record):
        if not isinstance(record, dict):
            continue
        seq = first_non_empty(record, ["sequence", "full_sequence", "uniprot_sequence", "protein_sequence", "seq"], None)
        if isinstance(seq, str) and seq:
            return len(seq)
        topo = first_non_empty(record, ["topology_labels", "tmbed_topology", "topology", "labels"], None)
        topo_clean = clean_topology_string(topo)
        if topo_clean:
            return len(topo_clean)
        for key in ("num_residues", "num_res", "length"):
            value = record.get(key)
            if isinstance(value, int) and value > 0:
                return value
    if topology:
        return len(topology)
    if idrs:
        return max(end for _, end in idrs)
    return None


def clean_topology_string(value: Any) -> Optional[str]:
    """Return a compact residue-label string if value looks like TMbed topology."""
    if not isinstance(value, str):
        return None
    # Some tools write FASTA-style multi-line topology. Drop headers and whitespace.
    lines = [ln.strip() for ln in value.splitlines() if ln.strip() and not ln.startswith(">")]
    s = "".join(lines).strip()
    if not s:
        return None
    # If a record contains a key-value line, keep only plausible label characters.
    label_chars = [c for c in s if c in TM_LABELS or c in INSIDE_LABELS or c in OUTSIDE_LABELS or c in SIGNAL_LABELS or c in {".", "-"}]
    if len(label_chars) < max(5, 0.75 * len(s.replace(" ", ""))):
        return None
    return "".join(label_chars)


def intervals_from_label_string(labels: str, tm_chars: Iterable[str] = TM_LABELS) -> List[Tuple[int, int]]:
    intervals: List[Tuple[int, int]] = []
    tm_chars = set(tm_chars)
    start: Optional[int] = None
    for idx, ch in enumerate(labels, start=1):
        if ch in tm_chars:
            if start is None:
                start = idx
        else:
            if start is not None:
                intervals.append((start, idx - 1))
                start = None
    if start is not None:
        intervals.append((start, len(labels)))
    return intervals


def normalize_interval_list(items: Any) -> List[Tuple[int, int]]:
    out: List[Tuple[int, int]] = []
    if not isinstance(items, list):
        return out
    for item in items:
        try:
            if isinstance(item, dict):
                start = int(first_non_empty(item, ["start", "begin", "from", "first", "s"], None))
                end = int(first_non_empty(item, ["end", "stop", "to", "last", "e"], None))
            else:
                start, end = int(item[0]), int(item[1])
        except Exception:
            continue
        if start > end:
            start, end = end, start
        out.append((start, end))
    return sorted(set(out))


def tmbed_container(record: dict) -> dict:
    if isinstance(record.get("tmbed"), dict):
        return record["tmbed"]
    return {}


def extract_tmbed_topology(record: dict) -> Optional[str]:
    nested = tmbed_container(record)
    for source in (nested, record):
        topo = first_non_empty(
            source,
            [
                "topology_labels", "tmbed_topology", "topology", "topology_string", "labels",
                "prediction", "per_residue_labels", "description", "topology_description",
            ],
            None,
        )
        topo_clean = clean_topology_string(topo)
        if topo_clean:
            return topo_clean
    return None


def extract_tmbed_intervals(record: dict) -> List[Tuple[int, int]]:
    nested = tmbed_container(record)
    # Prefer intervals explicitly nested under TMbed. If absent, parse TMbed topology string.
    for key in ("tm_intervals", "tm_segments", "segments", "predicted_tm_segments"):
        intervals = normalize_interval_list(nested.get(key))
        if intervals:
            return intervals
    topo = extract_tmbed_topology(record)
    if topo:
        intervals = intervals_from_label_string(topo)
        if intervals:
            return intervals
    # Some step-2 outputs store the TMbed-derived segments at top level. Only use
    # these as TMbed if the classification/source explicitly mentions TMbed.
    src_text = " ".join(str(record.get(k, "")) for k in ("tm_classification", "tm_class", "classification", "source", "boundary_source"))
    if "TMBED" in src_text.upper():
        for key in ("tmbed_tm_segments", "predicted_tm_segments", "tm_segments"):
            intervals = normalize_interval_list(record.get(key))
            if intervals:
                return intervals
    return []


def extract_uniprot_intervals(record: dict) -> List[Tuple[int, int]]:
    # Only used when no TMbed prediction exists.
    for key in (
        "uniprot_tm_segments", "uniprot_transmembrane_segments", "uniprot_transmembrane",
        "uniprot_tm_intervals", "transmembrane", "transmembrane_regions", "tm_features",
    ):
        intervals = normalize_interval_list(record.get(key))
        if intervals:
            return intervals
    # Last resort: legacy consensus intervals. This is intentionally not used
    # while a TMbed topology/interval prediction exists.
    intervals = normalize_interval_list(record.get("consensus_tm_segments"))
    if intervals:
        return intervals
    return []


def preferred_tm_annotation(record: dict) -> dict:
    """Return TM intervals/topology with TMbed priority, UniProt only fallback."""
    topo = extract_tmbed_topology(record)
    tmbed_intervals = extract_tmbed_intervals(record)
    if topo or tmbed_intervals:
        return {
            "source": "TMBED_TOPOLOGY" if topo else "TMBED_INTERVALS",
            "topology_labels": topo,
            "tm_segments": tmbed_intervals,
            "used_uniprot_fallback": False,
        }
    uni_intervals = extract_uniprot_intervals(record)
    return {
        "source": "UNIPROT_FALLBACK" if uni_intervals else "NO_TM_ANNOTATION",
        "topology_labels": None,
        "tm_segments": uni_intervals,
        "used_uniprot_fallback": bool(uni_intervals),
    }


def get_segment_types(idrs: List[Tuple[int, int]], seq_len: Optional[int], interactions: List[List[str]]) -> List[str]:
    if not idrs:
        return []
    if seq_len is None:
        return ["UNKNOWN"]

    has_n = idrs[0][0] == 1
    has_c = idrs[-1][1] == seq_len
    same_idr = has_n and has_c and len(idrs) == 1

    if same_idr:
        return ["FULL_IDR"]

    segment_types: List[str] = []
    for idx, _idr in enumerate(idrs):
        if idx == 0 and has_n:
            segment_types.append("N")
            continue
        if idx == len(idrs) - 1 and has_c:
            segment_types.append("C")
            continue

        if has_n:
            left_dom, right_dom = idx, idx + 1
        else:
            left_dom, right_dom = idx + 1, idx + 2
        pair = [f"F{left_dom}", f"F{right_dom}"]
        rev_pair = [pair[1], pair[0]]
        segment_types.append("LOOP" if pair in interactions or rev_pair in interactions else "L")
    return segment_types


def classify_case(idrs: List[Tuple[int, int]], seq_len: Optional[int], interactions: List[List[str]]) -> str:
    segment_types = get_segment_types(idrs, seq_len, interactions)
    if not segment_types:
        return "NO_IDR"
    if segment_types == ["FULL_IDR"]:
        return "FULL_IDR"
    if segment_types == ["N"]:
        return "N_ONLY"
    if segment_types == ["C"]:
        return "C_ONLY"
    if all(x == "L" for x in segment_types):
        return "L_ONLY" if len(segment_types) == 1 else "_".join(segment_types)
    if all(x == "LOOP" for x in segment_types):
        return "LOOP_ONLY" if len(segment_types) == 1 else "_".join(segment_types)
    return "_".join(segment_types)


def overlap_interval(a: Tuple[int, int], b: Tuple[int, int]) -> Optional[Tuple[int, int]]:
    start = max(a[0], b[0])
    end = min(a[1], b[1])
    if start <= end:
        return (start, end)
    return None


def is_small_tm_edge_overlap(overlap: Tuple[int, int], tm: Tuple[int, int], edge_tolerance: int) -> bool:
    if edge_tolerance <= 0:
        return False
    overlap_len = overlap[1] - overlap[0] + 1
    if overlap_len > edge_tolerance:
        return False
    left_edge_limit = tm[0] + edge_tolerance - 1
    right_edge_limit = tm[1] - edge_tolerance + 1
    return overlap[1] <= left_edge_limit or overlap[0] >= right_edge_limit


def conflict_rows(acc: str, case_label: str, idrs: List[Tuple[int, int]], tm_segments: List[Tuple[int, int]], edge_tolerance: int) -> List[dict]:
    rows = []
    for idr_idx, idr in enumerate(idrs, start=1):
        for tm_idx, tm in enumerate(tm_segments, start=1):
            ov = overlap_interval(idr, tm)
            if ov is None:
                continue
            if is_small_tm_edge_overlap(ov, tm, edge_tolerance):
                continue
            rows.append(
                {
                    "accession": acc,
                    "case": case_label,
                    "idr_index": idr_idx,
                    "idr_start": idr[0],
                    "idr_end": idr[1],
                    "tm_index": tm_idx,
                    "tm_start": tm[0],
                    "tm_end": tm[1],
                    "overlap_start": ov[0],
                    "overlap_end": ov[1],
                    "overlap_length": ov[1] - ov[0] + 1,
                }
            )
    return rows


def write_id_list(path: Path, ids: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as handle:
        for acc in ids:
            handle.write(acc + "\n")


def write_chunked_id_lists(outdir: Path, ids: List[str], chunk_size: int, prefix: str) -> int:
    outdir.mkdir(parents=True, exist_ok=True)
    if chunk_size <= 0:
        raise ValueError("chunk_size must be > 0")
    if not ids:
        return 0
    n_files = 0
    for start in range(0, len(ids), chunk_size):
        n_files += 1
        out_path = outdir / f"{prefix}_{n_files:03d}.txt"
        write_id_list(out_path, ids[start:start + chunk_size])
    return n_files


def is_easy_build_case(
    segment_types: List[str],
    idrs: List[Tuple[int, int]],
    num_tm_segments: int,
    easy_max_tm_segments: int,
    easy_max_idr_length: int,
    ) -> bool:
        # Exclude FULL_IDR and any internal linker/loop from easy routing.
        # Also exclude very long terminal tails from the easy smoke-test bucket;
        # those can be valid biology but are not good candidates for fast TM tests.
        if not segment_types or "FULL_IDR" in segment_types:
            return False
        if any(x not in {"N", "C"} for x in segment_types):
            return False
        if num_tm_segments > easy_max_tm_segments:
            return False
        if easy_max_idr_length > 0:
            for start, end in idrs:
                if (int(end) - int(start) + 1) > int(easy_max_idr_length):
                    return False
        return True


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--tm-json", required=True, help="Step-2 TMbed JSON")
    ap.add_argument("--idr-json", required=True, help="min15 master DB JSON or known-IDR JSON")
    ap.add_argument("--outdir", required=True, help="Output folder for case and conflict reports")
    ap.add_argument("--ids-file", default=None, help="Optional subset txt file with one accession per line")
    ap.add_argument("--ids-dir", default=None, help="Optional folder of txt files; all IDs across *.txt are merged")
    ap.add_argument("--only-tm", action="store_true", help="Restrict to entries with preferred TM intervals")
    ap.add_argument("--tm-edge-tolerance", type=int, default=5, help="Ignore IDR/TM overlaps of this many residues or fewer when they occur only at a TM interval edge")
    ap.add_argument("--non-conflict-chunk-size", type=int, default=20, help="Number of non-conflict UniProt IDs per chunked output txt file")
    ap.add_argument("--easy-max-tm-segments", type=int, default=1, help="Maximum number of TM segments allowed in non_conflict_easy_ids.txt")
    ap.add_argument("--easy-max-idr-length", type=int, default=200, help="Maximum length of any terminal IDR allowed in non_conflict_easy_ids.txt; use 0 to disable")
    args = ap.parse_args()

    tm_data = load_json(args.tm_json)
    idr_data = load_json(args.idr_json)
    tm_map = get_protein_map(tm_data)
    idr_map = get_protein_map(idr_data)

    if args.ids_file and args.ids_dir:
        raise SystemExit("Use only one of --ids-file or --ids-dir")
    if args.ids_dir:
        ids = load_ids_dir(args.ids_dir)
    elif args.ids_file:
        ids = load_ids_file(args.ids_file)
    else:
        ids = sorted(set(tm_map.keys()).intersection(idr_map.keys()))

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    case_to_ids: Dict[str, List[str]] = defaultdict(list)
    conflict_ids: List[str] = []
    conflict_detail_rows: List[dict] = []
    classification_rows: List[dict] = []
    source_counts: Counter = Counter()
    build_class_counts: Counter = Counter()

    for acc in ids:
        tm_record = tm_map.get(acc)
        idr_record = idr_map.get(acc)
        if not isinstance(tm_record, dict) or idr_record is None:
            continue

        anno = preferred_tm_annotation(tm_record)
        tm_segments = anno["tm_segments"]
        topology_labels = anno["topology_labels"]
        if args.only_tm and not tm_segments:
            continue

        source_counts[anno["source"]] += 1

        idrs = normalize_idrs(idr_record)
        if not idrs:
            continue

        interactions = normalize_interactions(idr_record)
        seq_len = infer_sequence_length(tm_record, idr_record if isinstance(idr_record, dict) else None, idrs, topology=topology_labels)
        segment_types = get_segment_types(idrs, seq_len, interactions)
        case_label = classify_case(idrs, seq_len, interactions)
        case_to_ids[case_label].append(acc)

        rows = conflict_rows(acc, case_label, idrs, tm_segments, args.tm_edge_tolerance)
        has_conflict = bool(rows)
        if has_conflict:
            conflict_ids.append(acc)
            conflict_detail_rows.extend(rows)

        easy = (not has_conflict) and is_easy_build_case(
            segment_types,
            idrs,
            len(tm_segments),
            args.easy_max_tm_segments,
            args.easy_max_idr_length,
        )
        build_class = "easy" if easy else ("conflict" if has_conflict else "difficult")
        build_class_counts[build_class] += 1

        classification_rows.append(
            {
                "accession": acc,
                "case": case_label,
                "build_class": build_class,
                "tm_annotation_source": anno["source"],
                "used_uniprot_fallback": int(bool(anno["used_uniprot_fallback"])),
                "num_idrs": len(idrs),
                "num_tm_segments": len(tm_segments),
                "sequence_length": seq_len if seq_len is not None else "",
                "has_conflict": int(has_conflict),
                "segment_types": json.dumps(segment_types),
                "idrs": json.dumps(idrs),
                "interactions": json.dumps(interactions),
                "tm_segments": json.dumps(tm_segments),
                "topology_labels": topology_labels or "",
            }
        )

    for case_label, case_ids in sorted(case_to_ids.items()):
        write_id_list(outdir / f"{case_label.lower()}_ids.txt", sorted(case_ids))

    conflict_id_set = set(conflict_ids)
    classified_ids = sorted({row["accession"] for row in classification_rows})
    non_conflict_ids = sorted(acc for acc in classified_ids if acc not in conflict_id_set)
    easy_ids = sorted(row["accession"] for row in classification_rows if row["build_class"] == "easy")
    difficult_ids = sorted(row["accession"] for row in classification_rows if row["build_class"] == "difficult")

    write_id_list(outdir / "conflict_ids.txt", sorted(conflict_id_set))
    write_id_list(outdir / "non_conflict_ids.txt", non_conflict_ids)
    write_id_list(outdir / "non_conflict_easy_ids.txt", easy_ids)
    write_id_list(outdir / "non_conflict_difficult_ids.txt", difficult_ids)

    all_chunks = write_chunked_id_lists(outdir / "non_conflict_ids_chunks", non_conflict_ids, args.non_conflict_chunk_size, "non_conflict_ids")
    easy_chunks = write_chunked_id_lists(outdir / "non_conflict_easy_ids_chunks", easy_ids, args.non_conflict_chunk_size, "easy")
    difficult_chunks = write_chunked_id_lists(outdir / "non_conflict_difficult_ids_chunks", difficult_ids, args.non_conflict_chunk_size, "difficult")

    with open(outdir / "conflict_details.tsv", "w", newline="") as handle:
        fieldnames = [
            "accession", "case", "idr_index", "idr_start", "idr_end",
            "tm_index", "tm_start", "tm_end", "overlap_start", "overlap_end", "overlap_length",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t")
        writer.writeheader()
        writer.writerows(conflict_detail_rows)

    with open(outdir / "classification_details.tsv", "w", newline="") as handle:
        fieldnames = [
            "accession", "case", "build_class", "tm_annotation_source", "used_uniprot_fallback",
            "num_idrs", "num_tm_segments", "sequence_length", "has_conflict", "segment_types",
            "idrs", "interactions", "tm_segments", "topology_labels",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t")
        writer.writeheader()
        writer.writerows(classification_rows)

    summary = {
        "tm_json": args.tm_json,
        "idr_json": args.idr_json,
        "ids_file": args.ids_file,
        "ids_dir": args.ids_dir,
        "only_tm": bool(args.only_tm),
        "tm_edge_tolerance": int(args.tm_edge_tolerance),
        "easy_max_tm_segments": int(args.easy_max_tm_segments),
        "easy_max_idr_length": int(args.easy_max_idr_length),
        "n_ids_classified": len(classification_rows),
        "n_conflict_ids": len(conflict_id_set),
        "n_non_conflict_ids": len(non_conflict_ids),
        "n_non_conflict_easy_ids": len(easy_ids),
        "n_non_conflict_difficult_ids": len(difficult_ids),
        "n_non_conflict_files": int(all_chunks),
        "n_easy_files": int(easy_chunks),
        "n_difficult_files": int(difficult_chunks),
        "tm_annotation_source_counts": dict(sorted(source_counts.items())),
        "build_class_counts": dict(sorted(build_class_counts.items())),
        "case_counts": {case_label: len(ids_) for case_label, ids_ in sorted(case_to_ids.items())},
    }
    with open(outdir / "classification_summary.json", "w") as handle:
        json.dump(summary, handle, indent=2)

    print(f"Classified IDs: {len(classification_rows)}")
    print(f"Conflict IDs: {len(conflict_id_set)}")
    print(f"Non-conflict IDs: {len(non_conflict_ids)}")
    print(f"Easy non-conflict IDs: {len(easy_ids)}")
    print(f"Difficult non-conflict IDs: {len(difficult_ids)}")
    print(f"Annotation sources: {dict(sorted(source_counts.items()))}")
    print(f"Wrote: {outdir / 'non_conflict_easy_ids.txt'}")
    print(f"Wrote: {outdir / 'non_conflict_difficult_ids.txt'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
