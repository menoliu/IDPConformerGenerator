"""
Step 2 for an AlphaFlex TM-IDR workflow.

Input:  Step-1 JSON from tm01_uniprot_known_tm.py.
Action: Run TMbed locally on the UniProt-known TM subset and parse TMbed residue labels.
Output: JSON checkpoint containing TMbed-derived membrane boundaries/topology labels for use by
        the TM-IDR bilayer builder.

Coordinates are 1-based inclusive residue indices.

TMbed labels parsed:
  H/h  alpha-helical TM segment
  B/b  beta-barrel TM strand/segment
  S    signal peptide
  i/I  non-TM inside
  o/O  non-TM outside
  .    non-TM/no side label

By default this script runs TMbed with --out-format 4, because that preserves directed TM labels
and explicit inside/outside labels when available.

Example:
  python tm02_tmbed_boundaries.py \
    --step1-json step1_uniprot_known_tm.json \
    --out-json step2_tmbed_boundaries.json \
    --workdir tmbed_work \
    --tmbed-cmd tmbed \
    --use-gpu

If you installed TMbed but want to run as a module:
  python tm02_tmbed_boundaries.py \
    --step1-json step1_uniprot_known_tm.json \
    --out-json step2_tmbed_boundaries.json \
    --workdir tmbed_work \
    --tmbed-cmd "python -m tmbed" \
    --no-use-gpu

Requirements
------------
* Python environment with TMbed v1.0.2 installed and accessible via the command line (e.g. "tmbed" or "python -m tmbed")
https://github.com/BernhoferM/TMbed
"""
import argparse
import json
import os
import shlex
import subprocess
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional


@dataclass
class Interval:
    start: int
    end: int
    label: str
    source: str
    note: str = ""

    def as_dict(self) -> dict:
        return asdict(self)


def write_fasta(seqs: Dict[str, str], path: str) -> None:
    with open(path, "w") as out:
        for acc, seq in seqs.items():
            out.write(f">{acc}\n")
            for i in range(0, len(seq), 80):
                out.write(seq[i : i + 80] + "\n")


def contiguous_intervals(labels: str, wanted: Iterable[str], label_name: str, source: str, note_by_char: Optional[Dict[str, str]] = None) -> List[Interval]:
    wanted = set(wanted)
    out: List[Interval] = []
    i = 0
    n = len(labels)
    while i < n:
        if labels[i] not in wanted:
            i += 1
            continue
        j = i
        first = labels[i]
        # Keep adjacent H/h or B/b together, but do not merge helix and barrel labels together.
        if first in set("Hh"):
            group = set("Hh")
        elif first in set("Bb"):
            group = set("Bb")
        else:
            group = wanted
        while j < n and labels[j] in group:
            j += 1
        note = note_by_char.get(first, first) if note_by_char else first
        out.append(Interval(i + 1, j, label_name, source, note))
        i = j
    return out


def parse_tmbed_3line(path: str) -> Dict[str, dict]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    lines = [line.rstrip("\n") for line in open(p) if line.strip()]
    out: Dict[str, dict] = {}
    i = 0
    while i < len(lines):
        if not lines[i].startswith(">"):
            i += 1
            continue
        header = lines[i][1:].strip()
        seqid = header.split()[0]
        if "|" in seqid:
            toks = seqid.split("|")
            # Accept UniProt-style sp|P12345|NAME.
            if len(toks) >= 2 and toks[1]:
                seqid = toks[1]
        if i + 2 >= len(lines):
            break
        seq = lines[i + 1].strip().upper()
        labels = lines[i + 2].strip()
        if len(seq) != len(labels):
            print(f"[WARN] TMbed length mismatch for {seqid}: seq={len(seq)} labels={len(labels)}", file=sys.stderr)
        alpha = contiguous_intervals(labels, set("Hh"), "TM_ALPHA_HELIX", "TMbed", {"H": "IN_TO_OUT", "h": "OUT_TO_IN"})
        beta = contiguous_intervals(labels, set("Bb"), "TM_BETA_STRAND", "TMbed", {"B": "IN_TO_OUT", "b": "OUT_TO_IN"})
        all_tm = sorted(alpha + beta, key=lambda x: (x.start, x.end))
        signal = contiguous_intervals(labels, {"S"}, "SIGNAL", "TMbed", {"S": "signal_peptide"})
        inside = contiguous_intervals(labels, {"i", "I"}, "INSIDE", "TMbed")
        outside = contiguous_intervals(labels, {"o", "O"}, "OUTSIDE", "TMbed")
        out[seqid] = {
            "header": header,
            "sequence": seq,
            "labels": labels,
            "tm_intervals": [x.as_dict() for x in all_tm],
            "tm_alpha_intervals": [x.as_dict() for x in alpha],
            "tm_beta_intervals": [x.as_dict() for x in beta],
            "signal_intervals": [x.as_dict() for x in signal],
            "inside_intervals": [x.as_dict() for x in inside],
            "outside_intervals": [x.as_dict() for x in outside],
        }
        i += 3
    return out


def load_step1(path: str) -> dict:
    with open(path) as handle:
        return json.load(handle)


def chunk_seqs(seqs: Dict[str, str], batch_size: int) -> List[Dict[str, str]]:
    """Split an ordered dict of sequences into chunks of at most batch_size."""
    items = list(seqs.items())
    return [dict(items[i : i + batch_size]) for i in range(0, len(items), batch_size)]


def merge_pred_files(batch_paths: List[str], merged_path: str) -> None:
    """Concatenate batch prediction files into a single file."""
    with open(merged_path, "w") as out:
        for bp in batch_paths:
            with open(bp) as f:
                content = f.read()
            if content and not content.endswith("\n"):
                content += "\n"
            out.write(content)


def ensure_predict_subcommand(tokens: List[str]) -> List[str]:
    # Accept either "tmbed", "python -m tmbed", or "tmbed predict".
    if tokens and tokens[-1] == "predict":
        return tokens
    if "predict" in tokens:
        return tokens
    return tokens + ["predict"]


def run_tmbed(args, fasta: str, pred_out: str) -> None:
    tokens = ensure_predict_subcommand(shlex.split(args.tmbed_cmd))
    cmd = tokens + ["-f", fasta, "-p", pred_out, "--out-format", str(args.out_format)]
    if args.batch_size is not None:
        cmd += ["--batch-size", str(args.batch_size)]
    if args.threads is not None:
        cmd += ["--threads", str(args.threads)]
    if args.model_dir:
        cmd += ["--model-dir", args.model_dir]
    if args.use_gpu:
        cmd += ["--use-gpu"]
    if args.no_use_gpu:
        cmd += ["--no-use-gpu"]
    if args.cpu_fallback:
        cmd += ["--cpu-fallback"]
    if args.no_cpu_fallback:
        cmd += ["--no-cpu-fallback"]
    if args.extra_tmbed_args:
        cmd += shlex.split(args.extra_tmbed_args)
    print("[INFO] Running:", " ".join(shlex.quote(x) for x in cmd), file=sys.stderr)
    subprocess.run(cmd, check=True)


def interval_dicts(items: List[dict], source_filter: Optional[str] = None) -> List[dict]:
    out = []
    for x in items or []:
        try:
            if source_filter and x.get("source") != source_filter:
                continue
            out.append({"start": int(x["start"]), "end": int(x["end"]), "label": x.get("label", "TM"), "source": x.get("source", ""), "note": x.get("note", "")})
        except Exception:
            pass
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--step1-json", required=True, help="JSON from tm01_uniprot_known_tm.py")
    ap.add_argument("--out-json", required=True, help="Output Step-2 JSON with TMbed boundaries")
    ap.add_argument("--workdir", default="tmbed_work", help="Working directory")
    ap.add_argument("--tmbed-cmd", default="tmbed", help="TMbed command prefix, e.g. 'tmbed' or 'python -m tmbed'")
    ap.add_argument("--out-format", type=int, default=4, choices=[0, 1, 2, 3, 4], help="TMbed output format. This parser expects a 3-line output; use 4 by default.")
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--threads", type=int, default=None)
    ap.add_argument("--model-dir", default=None)
    ap.add_argument("--use-gpu", action="store_true")
    ap.add_argument("--no-use-gpu", action="store_true")
    ap.add_argument("--cpu-fallback", action="store_true")
    ap.add_argument("--no-cpu-fallback", action="store_true")
    ap.add_argument("--extra-tmbed-args", default="")
    ap.add_argument("--skip-run", action="store_true", help="Do not run TMbed; parse an existing --pred-file")
    ap.add_argument("--pred-file", default=None, help="Existing or target TMbed prediction file")
    ap.add_argument("--seq-batch-size", type=int, default=None, metavar="N",
                    help="Split input into batches of N sequences before calling TMbed. "
                         "Keeps VRAM usage bounded (e.g. 500 seqs/batch for a 24 GB GPU).")
    ap.add_argument("--resume", action="store_true",
                    help="Skip batches whose .pred file already exists in --workdir (useful after a crash).")
    args = ap.parse_args()

    step1 = load_step1(args.step1_json)
    proteins = step1.get("proteins", {})
    known_ids = step1.get("known_tm_ids") or [acc for acc, p in proteins.items() if p.get("known_tm_uniprot")]

    seqs: Dict[str, str] = {}
    for acc in known_ids:
        seq = (proteins.get(acc) or {}).get("sequence")
        if seq:
            seqs[acc] = seq.upper()
        else:
            print(f"[WARN] {acc} missing sequence; skipping TMbed", file=sys.stderr)

    Path(args.workdir).mkdir(parents=True, exist_ok=True)
    pred_out = args.pred_file or os.path.join(args.workdir, "tmbed_predictions.pred")

    if not args.skip_run:
        if args.seq_batch_size and len(seqs) > args.seq_batch_size:
            batches = chunk_seqs(seqs, args.seq_batch_size)
            n_batches = len(batches)
            print(f"[INFO] splitting {len(seqs)} sequences into {n_batches} batches of "
                  f"<={args.seq_batch_size}", file=sys.stderr)
            batch_pred_files: List[str] = []
            for idx, batch in enumerate(batches, start=1):
                batch_fasta = os.path.join(args.workdir, f"batch_{idx:04d}.fasta")
                batch_pred  = os.path.join(args.workdir, f"batch_{idx:04d}.pred")
                batch_pred_files.append(batch_pred)
                if args.resume and Path(batch_pred).exists():
                    print(f"[INFO] batch {idx}/{n_batches}: {batch_pred} exists, skipping",
                          file=sys.stderr)
                    continue
                write_fasta(batch, batch_fasta)
                print(f"[INFO] batch {idx}/{n_batches}: {len(batch)} sequences", file=sys.stderr)
                run_tmbed(args, batch_fasta, batch_pred)
            print(f"[INFO] merging {n_batches} prediction files -> {pred_out}", file=sys.stderr)
            merge_pred_files(batch_pred_files, pred_out)
        else:
            fasta = os.path.join(args.workdir, "step1_known_tm_for_tmbed.fasta")
            write_fasta(seqs, fasta)
            run_tmbed(args, fasta, pred_out)
    else:
        # --skip-run: still write the full FASTA for reference
        fasta = os.path.join(args.workdir, "step1_known_tm_for_tmbed.fasta")
        write_fasta(seqs, fasta)

    tmbed = parse_tmbed_3line(pred_out)

    result = {
        "schema": "alphaflex_tm_step2_tmbed_boundaries_v1",
        "created_by": "tm02_tmbed_boundaries.py",
        "inputs": {
            "step1_json": args.step1_json,
            "tmbed_prediction_file": pred_out,
            "tmbed_out_format": args.out_format,
            "seq_batch_size": args.seq_batch_size,
        },
        "counts": {"known_tm_from_step1": len(known_ids), "with_sequence": len(seqs), "with_tmbed_prediction": len(tmbed)},
        "proteins": {},
    }

    for acc in known_ids:
        p1 = proteins.get(acc, {})
        pred = tmbed.get(acc)
        if pred is None:
            # Fallback for headers that contain accession but not as exact id.
            matches = [v for k, v in tmbed.items() if k.startswith(acc) or acc in k]
            pred = matches[0] if matches else None
        tmbed_tm = pred.get("tm_intervals", []) if pred else []
        up_tm = p1.get("uniprot_tm_segments", []) or [x for x in p1.get("uniprot_features", []) if x.get("label") == "TRANSMEM"]
        # Use TMbed boundaries for builder because the user requested TMbed boundaries. Fall back to UniProt only if TMbed predicts no TM.
        if tmbed_tm:
            consensus = tmbed_tm
            classification = "KNOWN_TM_TMBED_BOUNDARIES"
            reasons = ["UniProt TRANSMEM subset from step1", "TMbed predicted TM boundaries"]
        elif up_tm:
            consensus = interval_dicts(up_tm)
            classification = "KNOWN_TM_UNIPROT_BOUNDARIES_ONLY"
            reasons = ["UniProt TRANSMEM subset from step1", "TMbed did not return TM labels; using UniProt TRANSMEM intervals"]
        else:
            consensus = []
            classification = "KNOWN_TM_NO_BOUNDARIES"
            reasons = ["In step1 known_tm_ids but no parseable TMbed/UniProt TM segment was found"]

        result["proteins"][acc] = {
            "accession": acc,
            "sequence": p1.get("sequence") or (pred.get("sequence") if pred else None),
            "length": p1.get("length") or (len(pred.get("sequence")) if pred else None),
            "tm_classification": classification,
            "classification_reasons": reasons,
            "uniprot_features": p1.get("uniprot_features", []),
            "uniprot_tm_segments": p1.get("uniprot_tm_segments", []),
            "uniprot_signal_segments": p1.get("uniprot_signal_segments", []),
            "uniprot_topology_domains": p1.get("uniprot_topology_domains", []),
            "tmbed": pred,
            "consensus_tm_segments": consensus,
            "signal_segments": (p1.get("uniprot_signal_segments", []) or []) + ((pred or {}).get("signal_intervals", []) if pred else []),
            "topology_labels": pred.get("labels") if pred else None,
        }

    with open(args.out_json, "w") as out:
        json.dump(result, out, indent=2)
    print(f"[OK] wrote {args.out_json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
