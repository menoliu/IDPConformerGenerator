"""
Create batched ID list files for TM-IDR building.

This script selects UniProt IDs that:
1) are present in the known-IDR JSON,
2) are present in the Step-2 TMbed boundaries JSON,
3) are TM-like by default (classification contains "TM" and does not start with "NON").

Output files are written as bilayerX.txt with one ID per line, up to 20 IDs per file
(or a custom --batch-size).

Examples:
    # default batching (20 IDs per file), TM-only filtering
    python tm02_2_extract_bilayer_ids.py \
        --tm-json ../databases/transmembrane/step2_tmbed_uniprot_full_boundaries.json \
        --idr-json ../databases/min15_updated_PAE_master_db_fixed.json \
        --outdir ../databases/bilayer_ids

    # custom batch size and prefix
    python tm02_2_extract_bilayer_ids.py \
        --tm-json ../databases/transmembrane/step2_tmbed_uniprot_full_boundaries.json \
        --idr-json ../databases/min15_updated_PAE_master_db_fixed.json \
        --outdir ../databases/bilayer_ids \
        --batch-size 10 \
        --prefix bilayer

    # include non-TM entries too
    python tm02_2_extract_bilayer_ids.py \
        --tm-json ../databases/transmembrane/step2_tmbed_uniprot_full_boundaries.json \
        --idr-json ../databases/min15_updated_PAE_master_db_fixed.json \
        --outdir ../databases/bilayer_ids_all \
        --include-non-tm
"""
import argparse
import json
from pathlib import Path
from typing import Dict, List


def load_json(path: str) -> dict:
    with open(path) as handle:
        return json.load(handle)


def get_protein_map(db_obj: dict) -> Dict[str, dict]:
    if isinstance(db_obj, dict) and isinstance(db_obj.get("proteins"), dict):
        return db_obj["proteins"]
    if isinstance(db_obj, dict):
        return db_obj
    return {}


def is_tm_like(tm_class: str) -> bool:
    cls = (tm_class or "UNKNOWN").upper()
    return "TM" in cls and not cls.startswith("NON")


def has_any_idr(value) -> bool:
    if isinstance(value, list):
        return len(value) > 0
    if isinstance(value, dict):
        ranges = value.get("idrs")
        return isinstance(ranges, list) and len(ranges) > 0
    return False


def chunked(items: List[str], n: int) -> List[List[str]]:
    return [items[i:i + n] for i in range(0, len(items), n)]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--tm-json", required=True, help="Step-2 TMbed boundaries JSON")
    ap.add_argument("--idr-json", required=True, help="Known-IDR JSON")
    ap.add_argument("--outdir", required=True, help="Directory for bilayerX.txt outputs")
    ap.add_argument("--batch-size", type=int, default=20, help="Max IDs per output txt file")
    ap.add_argument("--prefix", default="bilayer", help="Output file prefix")
    ap.add_argument("--include-non-tm", action="store_true", help="If set, keep non-TM classifications too")
    args = ap.parse_args()

    if args.batch_size < 1:
        raise SystemExit("--batch-size must be >= 1")

    tm = load_json(args.tm_json)
    idr = load_json(args.idr_json)

    proteins = get_protein_map(tm)
    idr_ids = {acc for acc, ranges in idr.items() if has_any_idr(ranges)}

    selected = []
    for acc in sorted(idr_ids):
        pdata = proteins.get(acc)
        if pdata is None:
            continue
        if not args.include_non_tm and not is_tm_like(pdata.get("tm_classification", "UNKNOWN")):
            continue
        selected.append(acc)

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    batches = chunked(selected, args.batch_size)
    for idx, batch in enumerate(batches, start=1):
        out_path = outdir / f"{args.prefix}{idx}.txt"
        with open(out_path, "w") as handle:
            for acc in batch:
                handle.write(acc + "\n")

    summary = {
        "tm_json": args.tm_json,
        "idr_json": args.idr_json,
        "include_non_tm": bool(args.include_non_tm),
        "batch_size": int(args.batch_size),
        "n_selected_ids": len(selected),
        "n_files": len(batches),
        "files": [f"{args.prefix}{i}.txt" for i in range(1, len(batches) + 1)],
    }
    with open(outdir / f"{args.prefix}_summary.json", "w") as handle:
        json.dump(summary, handle, indent=2)

    print(f"Selected IDs: {len(selected)}")
    print(f"Wrote files: {len(batches)} in {outdir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
